
MSBTProfiles_SavedVarsPerChar = {
	["currentProfileName"] = "Flidro-v3",
}
