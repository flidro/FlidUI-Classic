
TipTopPCDB = {
	["charSpec"] = false,
}
