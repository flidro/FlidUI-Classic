
AUCTIONATOR_SAVEDVARS = {
	["_50000"] = 500,
	["_2000"] = 100,
	["_200000"] = 1000,
	["_10000"] = 200,
	["_1000000"] = 2500,
	["_5000000"] = 10000,
	["STARTING_DISCOUNT"] = 1,
	["_500"] = 1,
	["LOG_DE_DATA_X"] = true,
}
AUCTIONATOR_PRICING_HISTORY = {
	["Mana Potion"] = {
		["is"] = "3827:0:0:0:0",
		["5835801"] = "308:2",
	},
	["Pattern: Tough Scorpid Helm"] = {
		["is"] = "8402:0:0:0:0",
		["5835708"] = "3200:1",
	},
	["Recipe: Limited Invulnerability Potion"] = {
		["is"] = "3395:0:0:0:0",
		["5841306"] = "24800:1",
		["5839970"] = "52000:1",
	},
	["Sage's Pants of the Eagle"] = {
		["is"] = "6616:0:0:860:0",
		["5828898"] = "9900:1",
		["5831442"] = "6399:1",
	},
	["Stormbringer Belt"] = {
		["is"] = "12978:0:0:0:0",
		["5827742"] = "10400:1",
		["5830402"] = "7800:1",
		["5828498"] = "10200:1",
	},
	["Heart of the Wild"] = {
		["is"] = "10286:0:0:0:0",
		["5844998"] = "768:10",
		["5847423"] = "729:10",
	},
	["Heavy Scorpid Scale"] = {
		["is"] = "15408:0:0:0:0",
		["5841306"] = "8800:3",
	},
	["Green Hills of Stranglethorn - Page 20"] = {
		["is"] = "2744:0:0:0:0",
		["5832977"] = "1445:1",
	},
	["Thick Leather"] = {
		["5844805"] = "649:20",
		["5836368"] = "1019:20",
		["is"] = "4304:0:0:0:0",
		["5844202"] = "698:20",
		["5841305"] = "569:15",
		["5840471"] = "648:20",
		["5846140"] = "633:15",
		["5843541"] = "609:8",
		["5835799"] = "610:3",
		["5842133"] = "599:20",
		["5845763"] = "669:20",
		["5834332"] = "473:2",
		["5842892"] = "670:20",
		["5839906"] = "639:20",
		["5835876"] = "595:20",
		["5847419"] = "699:20",
		["5835709"] = "620:10",
		["5836367"] = "1019:20",
		["5834586"] = "690:16",
		["5847423"] = "699:20",
		["5831186"] = "483:20",
	},
	["Felcloth"] = {
		["is"] = "14256:0:0:0:0",
		["5850105"] = "19200:1",
	},
	["Fadeleaf"] = {
		["is"] = "3818:0:0:0:0",
		["5827743"] = "344:7",
	},
	["Scarlet Belt"] = {
		["is"] = "10329:0:0:0:0",
		["5848587"] = "3800:1",
	},
	["Heart of Fire"] = {
		["is"] = "7077:0:0:0:0",
		["5846508"] = "1382:3",
	},
	["Elemental Fire"] = {
		["is"] = "7068:0:0:0:0",
		["5847420"] = "5300:1",
		["5841418"] = "6300:1",
		["5831683"] = "7400:1",
	},
	["Small Glowing Shard"] = {
		["is"] = "11138:0:0:0:0",
		["5828898"] = "8700:1",
	},
	["Aquamarine"] = {
		["is"] = "7909:0:0:0:0",
		["5831443"] = "1475:1",
		["5840471"] = "4900:1",
	},
	["Mithril Ore"] = {
		["is"] = "3858:0:0:0:0",
		["5843123"] = "2300:3",
	},
	["Heavy Hide"] = {
		["is"] = "4235:0:0:0:0",
		["5834587"] = "965:5",
	},
	["Giant Egg"] = {
		["is"] = "12207:0:0:0:0",
		["5847702"] = "2700:4",
		["5844202"] = "2800:1",
		["5841423"] = "2900:4",
	},
	["Soul Dust"] = {
		["is"] = "11083:0:0:0:0",
		["5828897"] = "493:4",
		["5831598"] = "1170:4",
		["5832961"] = "298:4",
	},
	["Thick Spider's Silk"] = {
		["is"] = "4337:0:0:0:0",
		["5836116"] = "1120:3",
		["5831442"] = "3500:2",
	},
	["Thick Armor Kit"] = {
		["is"] = "8173:0:0:0:0",
		["5834587"] = "2100:2",
	},
	["Vulture Gizzard"] = {
		["is"] = "8396:0:0:0:0",
		["5841422"] = "10199:1",
	},
	["Cat Carrier (White Kitten)"] = {
		["is"] = "8489:0:0:0:0",
		["5841420"] = "44600:1",
	},
	["Sage's Robe of the Owl"] = {
		["is"] = "6610:0:0:775:0",
		["5828898"] = "7400:1",
	},
	["Small Brilliant Shard"] = {
		["is"] = "14343:0:0:0:0",
		["5846140"] = "17400:1",
	},
	["Green Hills of Stranglethorn - Page 6"] = {
		["is"] = "2730:0:0:0:0",
		["5833106"] = "1105:1",
	},
	["Blue Pearl"] = {
		["is"] = "4611:0:0:0:0",
		["5832999"] = "5041:1",
	},
	["Mageweave Cloth"] = {
		["is"] = "4338:0:0:0:0",
		["5831684"] = "685:5",
	},
	["Rugged Hide"] = {
		["is"] = "8171:0:0:0:0",
		["5844203"] = "823:6",
		["5842133"] = "974:2",
	},
	["Truesilver Bar"] = {
		["is"] = "6037:0:0:0:0",
		["5841420"] = "2200:2",
		["5840473"] = "2700:2",
	},
	["Citrine"] = {
		["5828782"] = "1495:1",
		["5830403"] = "935:1",
		["is"] = "3864:0:0:0:0",
	},
	["Combatant Claymore"] = {
		["5840477"] = "19800:1",
		["5834588"] = "74000:1",
		["5830402"] = "99500:1",
		["5831196"] = "42400:1",
		["is"] = "2877:0:0:0:0",
		["5827741"] = "149500:1",
		["5835708"] = "37400:1",
		["5828498"] = "99500:1",
	},
	["Ravasaur Scale Boots"] = {
		["5830403"] = "49800:1",
		["5827742"] = "99500:1",
		["is"] = "13124:0:0:0:0",
		["5835800"] = "13400:1",
		["5831196"] = "29000:1",
		["5834588"] = "28800:1",
		["5828498"] = "99500:1",
	},
	["Truesilver Ore"] = {
		["is"] = "7911:0:0:0:0",
		["5833316"] = "3096:1",
		["5835541"] = "2900:1",
	},
	["Jet Black Feather"] = {
		["is"] = "8168:0:0:0:0",
		["5836368"] = "575:12",
	},
	["Forgotten Wraps"] = {
		["is"] = "9433:0:0:0:0",
		["5841419"] = "29800:1",
	},
	["Stoneraven"] = {
		["is"] = "13059:0:0:0:0",
		["5836369"] = "300559:1",
		["5837238"] = "249999:1",
	},
	["Scorpid Scale"] = {
		["is"] = "8154:0:0:0:0",
		["5841420"] = "1114:19",
		["5836368"] = "1399:19",
		["5841418"] = "1114:2",
	},
	["Green Hills of Stranglethorn - Page 26"] = {
		["5832977"] = "1390:1",
		["is"] = "2750:0:0:0:0",
		["5833105"] = "990:1",
	},
	["Major Mana Potion"] = {
		["is"] = "13444:0:0:0:0",
		["5849794"] = "17600:1",
		["5850105"] = "15400:2",
	},
	["Jouster's Pauldrons"] = {
		["is"] = "8163:0:0:0:0",
		["5834584"] = "23000:1",
		["5835877"] = "20616:1",
	},
	["Recipe: Lesser Stoneshield Potion"] = {
		["5833113"] = "8300:1",
		["is"] = "4624:0:0:0:0",
		["5835541"] = "6300:1",
	},
	["Recipe: Elixir of the Mongoose"] = {
		["is"] = "13491:0:0:0:0",
		["5839970"] = "39800:1",
	},
	["Iron Ore"] = {
		["is"] = "2772:0:0:0:0",
		["5835801"] = "485:7",
		["5831684"] = "449:2",
		["5833315"] = "496:3",
	},
	["Tender Wolf Meat"] = {
		["is"] = "12208:0:0:0:0",
		["5841606"] = "639:7",
	},
	["Long Redwood Bow"] = {
		["is"] = "15286:0:0:0:0",
		["5828897"] = "17200:1",
	},
	["Rugged Leather"] = {
		["5847701"] = "1214:3",
		["5844805"] = "1236:20",
		["5836116"] = "1494:9",
		["5847141"] = "1107:20",
		["is"] = "8170:0:0:0:0",
		["5845763"] = "1294:20",
		["5835709"] = "2400:1",
		["5845862"] = "1236:15",
		["5839906"] = "1224:17",
		["5836367"] = "1419:17",
		["5847419"] = "999:6",
		["5842892"] = "1894:20",
		["5840471"] = "994:9",
		["5841305"] = "3000:20",
		["5847423"] = "999:13",
		["5842132"] = "1824:19",
	},
	["Thorium Bar"] = {
		["is"] = "12359:0:0:0:0",
		["5845766"] = "7400:4",
	},
	["Worn Dragonscale"] = {
		["is"] = "8165:0:0:0:0",
		["5835876"] = "1245:1",
		["5834587"] = "1455:1",
	},
	["Mountain Silversage"] = {
		["is"] = "13465:0:0:0:0",
		["5844202"] = "4700:2",
	},
	["Pattern: Runecloth Bag"] = {
		["is"] = "14468:0:0:0:0",
		["5843541"] = "189000:1",
	},
	["Shadow Silk"] = {
		["is"] = "10285:0:0:0:0",
		["5832960"] = "2100:1",
		["5831597"] = "3400:1",
		["5835541"] = "1890:1",
	},
	["Wildvine"] = {
		["is"] = "8153:0:0:0:0",
		["5833314"] = "19400:1",
		["5835799"] = "7800:2",
	},
	["Red Wolf Meat"] = {
		["is"] = "12203:0:0:0:0",
		["5841607"] = "293:6",
	},
	["Ichor of Undeath"] = {
		["is"] = "7972:0:0:0:0",
		["5841306"] = "994:1",
	},
	["Elemental Water"] = {
		["is"] = "7070:0:0:0:0",
		["5828783"] = "675:1",
	},
	["Plans: Thorium Armor"] = {
		["is"] = "12682:0:0:0:0",
		["5843541"] = "9900:1",
	},
	["Lightforge Gauntlets"] = {
		["is"] = "16724:0:0:0:0",
		["5846506"] = "59500:1",
	},
	["Cold Basilisk Eye"] = {
		["is"] = "5079:0:0:0:0",
		["5831441"] = "11400:1",
	},
	["Strange Dust"] = {
		["is"] = "10940:0:0:0:0",
		["5827750"] = "81:4",
	},
	["Renegade Chestguard of the Bear"] = {
		["is"] = "9866:0:0:1204:0",
		["5831444"] = "17307:1",
	},
	["Topaz Ring of Fire Resistance"] = {
		["is"] = "11975:0:0:1413:0",
		["5847156"] = "14900:1",
	},
	["Heavy Leather"] = {
		["5827746"] = "249:20",
		["5828897"] = "249:12",
		["5831187"] = "240:20",
		["5835709"] = "210:12",
		["5831597"] = "229:20",
		["5827747"] = "249:20",
		["is"] = "4234:0:0:0:0",
	},
	["Green Dragonscale"] = {
		["is"] = "15412:0:0:0:0",
		["5834587"] = "1460:8",
	},
	["Superior Mana Potion"] = {
		["5847420"] = "33600:1",
		["5849794"] = "7300:1",
		["is"] = "13443:0:0:0:0",
	},
	["Moss Agate"] = {
		["is"] = "1206:0:0:0:0",
		["5826270"] = "670:1",
	},
	["Star Ruby"] = {
		["is"] = "7910:0:0:0:0",
		["5847420"] = "5700:1",
	},
	["Ebon Scimitar of the Bear"] = {
		["is"] = "8196:0:0:1191:0",
		["5834332"] = "36000:1",
	},
	["Green Hills of Stranglethorn - Page 21"] = {
		["is"] = "2745:0:0:0:0",
		["5833105"] = "1790:1",
	},
	["Snickerfang Jowl"] = {
		["is"] = "8391:0:0:0:0",
		["5841422"] = "1193:2",
	},
	["Black Pearl"] = {
		["is"] = "7971:0:0:0:0",
		["5833316"] = "1490:1",
	},
	["Swiftthistle"] = {
		["is"] = "2452:0:0:0:0",
		["5827743"] = "44:3",
	},
	["Bolt of Silk Cloth"] = {
		["is"] = "4305:0:0:0:0",
		["5841306"] = "1238:1",
	},
	["Chromite Greaves"] = {
		["is"] = "8141:0:0:0:0",
		["5835876"] = "20000:1",
		["5834332"] = "19800:1",
	},
	["Green Hills of Stranglethorn - Page 4"] = {
		["is"] = "2728:0:0:0:0",
		["5832977"] = "1990:1",
	},
	["Lesser Mystic Essence"] = {
		["is"] = "11134:0:0:0:0",
		["5830403"] = "1745:2",
		["5831196"] = "3300:2",
		["5827749"] = "3100:2",
	},
	["Libram of Voracity"] = {
		["is"] = "11737:0:0:0:0",
		["5847405"] = "243000:1",
	},
	["Brigade Breastplate of Power"] = {
		["is"] = "9928:0:0:1565:0",
		["5841419"] = "25648:1",
	},
	["Witchfury"] = {
		["is"] = "13051:0:0:0:0",
		["5837238"] = "128500:1",
		["5835708"] = "149500:1",
		["5838744"] = "69500:1",
	},
	["Ironweb Spider Silk"] = {
		["is"] = "14227:0:0:0:0",
		["5836116"] = "5200:1",
	},
	["Long Elegant Feather"] = {
		["is"] = "4589:0:0:0:0",
		["5835801"] = "5700:1",
	},
	["Gold Ore"] = {
		["5833113"] = "825:2",
		["is"] = "2776:0:0:0:0",
		["5835541"] = "1890:2",
	},
	["Green Hills of Stranglethorn - Page 10"] = {
		["5832977"] = "1995:1",
		["is"] = "2734:0:0:0:0",
		["5833106"] = "995:1",
		["5833316"] = "2300:1",
	},
	["Green Hills of Stranglethorn - Page 1"] = {
		["is"] = "2725:0:0:0:0",
		["5833105"] = "1990:1",
	},
	["Solid Stone"] = {
		["5833113"] = "461:19",
		["5836116"] = "378:7",
		["is"] = "7912:0:0:0:0",
		["5835541"] = "499:19",
	},
	["Liferoot"] = {
		["is"] = "3357:0:0:0:0",
		["5830403"] = "1995:1",
		["5827743"] = "945:3",
	},
	["Plans: Wildthorn Mail"] = {
		["is"] = "12691:0:0:0:0",
		["5841305"] = "148000:1",
	},
	["Nightsky Armor"] = {
		["is"] = "7111:0:0:0:0",
		["5832005"] = "12200:1",
	},
	["Deeprock Salt"] = {
		["is"] = "8150:0:0:0:0",
		["5836116"] = "2700:6",
	},
	["White Spider Meat"] = {
		["is"] = "12205:0:0:0:0",
		["5836116"] = "930:10",
	},
	["Quartz Ring of Shadow Resistance"] = {
		["is"] = "11965:0:0:1448:0",
		["5826270"] = "5600:1",
	},
	["Chimera Leather"] = {
		["is"] = "15423:0:0:0:0",
		["5843532"] = "1584:4",
	},
	["Tusker Sword of the Tiger"] = {
		["is"] = "15252:0:0:706:0",
		["5844203"] = "89999:1",
	},
	["Overlord's Gauntlets of the Bear"] = {
		["is"] = "10205:0:0:1208:0",
		["5841420"] = "20000:1",
	},
	["Fused Wiring"] = {
		["is"] = "7191:0:0:0:0",
		["5847423"] = "5300:1",
	},
	["Obsidian Pendant of the Bear"] = {
		["is"] = "12035:0:0:1203:0",
		["5849793"] = "50000:1",
	},
	["Recipe: Major Healing Potion"] = {
		["is"] = "13480:0:0:0:0",
		["5843541"] = "47400:1",
	},
}
AUCTIONATOR_SHOPPING_LISTS = {
	{
		["items"] = {
			"Felcloth", -- [1]
			"Stoneshield", -- [2]
			"Stonegrip", -- [3]
			"Steelskin", -- [4]
			"cook", -- [5]
			"cooking", -- [6]
			"Runecloth", -- [7]
			"journey", -- [8]
			"Icecap", -- [9]
			"Dreamfoil", -- [10]
			"Golden san", -- [11]
			"Silversage", -- [12]
			"Sungrass", -- [13]
			"Groms", -- [14]
			"Thorium tube", -- [15]
			"Masterwork targ", -- [16]
			"Gyrofre", -- [17]
			"Powerful sea", -- [18]
			"Delicate arc", -- [19]
			"Silk cloth", -- [20]
			"Mageweave cloth", -- [21]
			"wool", -- [22]
			"Fire res", -- [23]
			"Rage", -- [24]
			"Devout", -- [25]
			"Valor", -- [26]
			"Elixir ", -- [27]
			"Major healing", -- [28]
			"Runecloth gloves", -- [29]
			"Golden pearl", -- [30]
			"Thorium bar", -- [31]
			"weapon chain", -- [32]
			"Morrow", -- [33]
			"Fiery wrath", -- [34]
			"Brain", -- [35]
			"Demonslaying", -- [36]
			"Mithril casing", -- [37]
			"Map frag", -- [38]
			"Bandage", -- [39]
			"Thick Armor Kit", -- [40]
			"Truesilver", -- [41]
			"Elixir of water", -- [42]
			"waterbreathing", -- [43]
			"Truesilver bar", -- [44]
			"Truesilver rod", -- [45]
			"Black pearl", -- [46]
			"Linen cloth", -- [47]
			"Healing Potion", -- [48]
			"wintersbite", -- [49]
			"Gyro", -- [50]
		},
		["isRecents"] = 1,
		["name"] = "Recent Searches",
	}, -- [1]
	{
		["items"] = {
			"Greater Cosmic Essence", -- [1]
			"Infinite Dust", -- [2]
			"Dream Shard", -- [3]
			"Abyss Crystal", -- [4]
		},
		["name"] = "Sample Shopping List #1",
		["isSorted"] = false,
	}, -- [2]
}
AUCTIONATOR_SHOPPING_LISTS_MIGRATED_V2 = true
AUCTIONATOR_PRICE_DATABASE = {
	["__dbversion"] = 4,
	["Stalagg_Horde"] = {
	},
	["Pagle_Alliance"] = {
		["Aurora Pants"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Battleforge Wristguards of the Bear"] = {
			["mr"] = 5999,
			["H3219"] = 5999,
		},
		["Shadowhide Maul"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Oak Mallet of the Tiger"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Sorcerer Slippers of the Whale"] = {
			["mr"] = 6800,
			["H3219"] = 6800,
		},
		["Twin-bladed Axe of Power"] = {
			["mr"] = 1960,
			["H3219"] = 1960,
		},
		["Bandit Jerkin of Stamina"] = {
			["mr"] = 4338,
			["H3219"] = 4338,
		},
		["Sage's Boots of the Whale"] = {
			["mr"] = 5519,
			["H3219"] = 5519,
		},
		["Durable Bracers of the Whale"] = {
			["mr"] = 4967,
			["H3219"] = 4967,
		},
		["The Ziggler"] = {
			["mr"] = 68999,
			["H3219"] = 68999,
		},
		["Warbringer's Legguards of the Boar"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Ballast Maul of Spirit"] = {
			["mr"] = 27500,
			["H3219"] = 27500,
		},
		["Scaled Leather Bracers of Power"] = {
			["mr"] = 4599,
			["H3219"] = 4599,
		},
		["Dense Sharpening Stone"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Rust-covered Blunderbuss"] = {
			["mr"] = 45,
			["H3219"] = 45,
		},
		["Banded Cloak of the Bear"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Ivycloth Robe of the Whale"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Lesser Mana Potion"] = {
			["mr"] = 56,
			["sc"] = 0,
			["id"] = "3385:0:0:0:0",
			["H3219"] = 56,
			["cc"] = 0,
		},
		["Willow Gloves of Healing"] = {
			["mr"] = 2212,
			["H3219"] = 2212,
		},
		["Dervish Leggings of the Owl"] = {
			["mr"] = 5800,
			["H3219"] = 5800,
		},
		["Cadet Leggings of the Whale"] = {
			["mr"] = 989,
			["H3219"] = 989,
		},
		["Conjurer's Cinch of Intellect"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Blush Ember Ring"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Disciple's Vest of Frozen Wrath"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Infantry Bracers"] = {
			["mr"] = 199,
			["H3219"] = 199,
		},
		["Medicine Staff of the Wolf"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Black Metal Greatsword"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Notched Shortsword of Stamina"] = {
			["mr"] = 525,
			["H3219"] = 525,
		},
		["Pathfinder Guard of Spirit"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Raw Sagefish"] = {
			["mr"] = 210,
			["H3219"] = 210,
		},
		["Shadowcat Hide"] = {
			["mr"] = 284,
			["H3219"] = 284,
		},
		["Goblin Nutcracker of Power"] = {
			["mr"] = 44999,
			["H3219"] = 44999,
		},
		["Fortified Boots of the Bear"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Phalanx Breastplate of the Whale"] = {
			["mr"] = 15034,
			["H3219"] = 15034,
		},
		["Pioneer Trousers of the Monkey"] = {
			["mr"] = 601,
			["H3219"] = 601,
		},
		["Superior Bracers of the Monkey"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Green Hills of Stranglethorn - Page 18"] = {
			["mr"] = 990,
			["sc"] = 0,
			["id"] = "2742:0:0:0:0",
			["H3219"] = 990,
			["cc"] = 15,
		},
		["Underworld Band"] = {
			["mr"] = 3902217,
			["H3219"] = 3902217,
		},
		["Solid Blasting Powder"] = {
			["mr"] = 1072,
			["H3219"] = 1072,
		},
		["Bloodwoven Bracers of Shadow Wrath"] = {
			["mr"] = 200000,
			["H3219"] = 200000,
		},
		["Renegade Leggings of the Monkey"] = {
			["mr"] = 11500,
			["H3219"] = 11500,
		},
		["Scouting Gloves of the Wolf"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Polished Zweihander of the Tiger"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Standard Scope"] = {
			["mr"] = 855,
			["H3219"] = 855,
		},
		["Felcloth Hood"] = {
			["mr"] = 212498,
			["cc"] = 4,
			["id"] = "14111:0:0:0:0",
			["sc"] = 1,
			["H3226"] = 212498,
		},
		["Black Mageweave Gloves"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Fine Leather Gloves"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Weak Troll's Blood Potion"] = {
			["mr"] = 13,
			["sc"] = 0,
			["id"] = "3382:0:0:0:0",
			["H3219"] = 13,
			["cc"] = 0,
		},
		["Pattern: Orange Martial Shirt"] = {
			["mr"] = 38562,
			["H3219"] = 38562,
		},
		["Mageweave Bandage"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sanguine Star"] = {
			["mr"] = 5408,
			["H3219"] = 5408,
		},
		["Honed Stiletto of the Tiger"] = {
			["mr"] = 12499,
			["H3219"] = 12499,
		},
		["Battleforge Legguards of the Whale"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Battering Hammer of the Whale"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Native Vest of the Whale"] = {
			["mr"] = 1141,
			["H3219"] = 1141,
		},
		["Lightforge Gauntlets"] = {
			["mr"] = 60000,
			["cc"] = 4,
			["id"] = "16724:0:0:0:0",
			["sc"] = 4,
			["H3224"] = 60000,
		},
		["Elder's Padded Armor of the Whale"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Bard's Tunic of Agility"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Bronze Bar"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Buccaneer's Boots of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Raider's Gauntlets of the Eagle"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Naga Scale"] = {
			["mr"] = 221,
			["H3219"] = 221,
		},
		["Simple Branch of the Falcon"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Coarse Gorilla Hair"] = {
			["mr"] = 695,
			["H3219"] = 695,
		},
		["Deadly Kris of the Monkey"] = {
			["mr"] = 24182,
			["H3219"] = 24182,
		},
		["Embossed Plate Gauntlets of the Monkey"] = {
			["mr"] = 15405,
			["H3219"] = 15405,
		},
		["Bandit Pants of Spirit"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Runed Copper Pants"] = {
			["mr"] = 498,
			["H3219"] = 498,
		},
		["Hillman's Cloak"] = {
			["mr"] = 2450,
			["H3219"] = 2450,
		},
		["Hacking Cleaver of the Tiger"] = {
			["mr"] = 9600,
			["H3219"] = 9600,
		},
		["Conjurer's Shoes of Stamina"] = {
			["mr"] = 12079,
			["H3219"] = 12079,
		},
		["Copper Chain Belt"] = {
			["mr"] = 74,
			["H3219"] = 74,
		},
		["Azora's Will"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Barbaric Battle Axe of the Eagle"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Schematic: Parachute Cloak"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Sorcerer Mantle of the Eagle"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Dusky Leather Leggings"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Pioneer Trousers of the Falcon"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Pattern: Spider Belt"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Jouster's Crest"] = {
			["mr"] = 14200,
			["H3219"] = 14200,
		},
		["Ritual Sandals of Arcane Wrath"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Barbed Club of Shadow Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Fortified Bracers of Power"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Barbarian War Axe of the Wolf"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Recipe: Shadow Protection Potion"] = {
			["mr"] = 6999,
			["sc"] = 6,
			["id"] = "6054:0:0:0:0",
			["H3219"] = 6999,
			["cc"] = 9,
		},
		["Blue Firework"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Mail Combat Armor"] = {
			["mr"] = 5400,
			["H3219"] = 5400,
		},
		["Sentinel Cap of Stamina"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Cavalier Two-hander of the Wolf"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Raider's Chestpiece of Stamina"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Recipe: Frost Protection Potion"] = {
			["mr"] = 3900,
			["sc"] = 6,
			["id"] = "6056:0:0:0:0",
			["H3219"] = 3900,
			["cc"] = 9,
		},
		["Twin-bladed Axe of Strength"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Plans: Iridescent Hammer"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Goldenbark Apple"] = {
			["mr"] = 240,
			["H3219"] = 240,
		},
		["Sacrificial Kris of Nature's Wrath"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Ritual Leggings of the Owl"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Buccaneer's Vest of Shadow Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Stonemason Trousers"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bandit Pants of the Wolf"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Dervish Gloves of the Bear"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Schematic: Small Seaforium Charge"] = {
			["mr"] = 290,
			["H3219"] = 290,
		},
		["Knight's Cloak of Healing"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Disciple's Pants of Healing"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Strong Troll's Blood Potion"] = {
			["mr"] = 198,
			["sc"] = 0,
			["id"] = "3388:0:0:0:0",
			["H3219"] = 198,
			["cc"] = 0,
		},
		["Green Lens of Regeneration"] = {
			["mr"] = 430391,
			["H3219"] = 430391,
		},
		["Brigade Defender of the Bear"] = {
			["mr"] = 30636,
			["H3219"] = 30636,
		},
		["Bandit Gloves of the Whale"] = {
			["mr"] = 1290,
			["H3219"] = 1290,
		},
		["Pattern: Hillman's Leather Vest"] = {
			["mr"] = 268,
			["H3219"] = 268,
		},
		["Infantry Tunic of the Boar"] = {
			["mr"] = 1212,
			["H3219"] = 1212,
		},
		["Ruthless Shiv"] = {
			["mr"] = 79999,
			["H3219"] = 79999,
		},
		["Deckhand's Shirt"] = {
			["mr"] = 3906,
			["H3219"] = 3906,
		},
		["Edged Bastard Sword of the Bear"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Bloodpike"] = {
			["mr"] = 17600,
			["H3219"] = 17600,
		},
		["Conjurer's Hood of the Whale"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Prospector's Mitts"] = {
			["mr"] = 1250,
			["H3219"] = 1250,
		},
		["Recipe: Smoked Sagefish"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Fortified Cloak of the Bear"] = {
			["mr"] = 2222,
			["H3219"] = 2222,
		},
		["Crocolisk Steak"] = {
			["mr"] = 57,
			["H3219"] = 57,
		},
		["Insignia Cloak"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Azure Silk Gloves"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Soldier's Armor of the Bear"] = {
			["mr"] = 989,
			["H3219"] = 989,
		},
		["Seer's Cape"] = {
			["mr"] = 590,
			["H3219"] = 590,
		},
		["Infiltrator Cloak of the Whale"] = {
			["mr"] = 7786,
			["H3219"] = 7786,
		},
		["Simple Linen Pants"] = {
			["mr"] = 30,
			["H3219"] = 30,
		},
		["Scouting Trousers of the Eagle"] = {
			["mr"] = 1463,
			["H3219"] = 1463,
		},
		["Red Linen Shirt"] = {
			["mr"] = 71,
			["H3219"] = 71,
		},
		["Disciple's Stein of Arcane Wrath"] = {
			["mr"] = 1035,
			["H3219"] = 1035,
		},
		["Jagged Star of Strength"] = {
			["mr"] = 8598,
			["H3219"] = 8598,
		},
		["Light Leather Pants"] = {
			["mr"] = 1298,
			["H3219"] = 1298,
		},
		["Nocturnal Wristbands of Power"] = {
			["mr"] = 29160,
			["H3219"] = 29160,
		},
		["Scroll of Spirit"] = {
			["mr"] = 25,
			["H3219"] = 25,
		},
		["Conjurer's Cinch of the Wolf"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Guardian Pants"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Defender Cloak of the Gorilla"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Scaled Leather Shoulders of the Whale"] = {
			["mr"] = 7050,
			["H3219"] = 7050,
		},
		["Journeyman's Stave"] = {
			["H3225"] = 486,
			["sc"] = 0,
			["id"] = "15925:0:0:0:0",
			["mr"] = 486,
			["cc"] = 4,
		},
		["Plans: Hardened Iron Shortsword"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Spiked Club of Power"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Goblin Mail Leggings"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Kobold Mining Mallet"] = {
			["mr"] = 97,
			["H3219"] = 97,
		},
		["Ivy Orb of the Falcon"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Firemane Leggings"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Simple Branch of the Whale"] = {
			["mr"] = 755,
			["H3219"] = 755,
		},
		["Black Metal Axe"] = {
			["mr"] = 2990,
			["H3219"] = 2990,
		},
		["Buccaneer's Pants of Healing"] = {
			["mr"] = 2214,
			["H3219"] = 2214,
		},
		["Disciple's Stein of the Owl"] = {
			["mr"] = 1965,
			["H3219"] = 1965,
		},
		["Mechanical Squirrel Box"] = {
			["mr"] = 1199,
			["H3219"] = 1199,
		},
		["Dwarven Magestaff of Fiery Wrath"] = {
			["mr"] = 12999,
			["cc"] = 2,
			["id"] = "2072:0:0:1883:0",
			["sc"] = 10,
			["H3220"] = 12999,
		},
		["Heavy Quiver"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Banded Bracers of the Bear"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Bloodspattered Loincloth of the Bear"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Medicine Staff of Nature's Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Phalanx Spaulders of the Bear"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Skeletal Club"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Buccaneer's Cape of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Willow Branch of the Falcon"] = {
			["mr"] = 1207,
			["H3219"] = 1207,
		},
		["Twilight Gloves of the Whale"] = {
			["mr"] = 7066,
			["H3219"] = 7066,
		},
		["Iridium Chain of Concentration"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Mystic's Sphere"] = {
			["mr"] = 1799,
			["sc"] = 0,
			["id"] = "15946:0:0:0:0",
			["H3219"] = 1799,
			["cc"] = 4,
		},
		["Willow Boots of Spirit"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Bronze Mace"] = {
			["mr"] = 3357,
			["H3219"] = 3357,
		},
		["Ritual Belt of the Whale"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Bright Pants"] = {
			["mr"] = 1695,
			["H3219"] = 1695,
		},
		["Greater Scythe of the Wolf"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Decapitating Sword of the Bear"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Elder's Boots of the Eagle"] = {
			["mr"] = 5600,
			["H3219"] = 5600,
		},
		["Gift of Arthas"] = {
			["mr"] = 16993,
			["H3219"] = 16993,
		},
		["Swim Speed Potion"] = {
			["mr"] = 93,
			["sc"] = 0,
			["id"] = "6372:0:0:0:0",
			["H3219"] = 93,
			["cc"] = 0,
		},
		["Decapitating Sword of Strength"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Native Pants of Fiery Wrath"] = {
			["mr"] = 569,
			["H3219"] = 569,
		},
		["Disciple's Stein of the Eagle"] = {
			["mr"] = 750,
			["H3219"] = 750,
		},
		["Bandit Gloves of Spirit"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Bard's Trousers of the Bear"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Burnished Girdle"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Soldier's Leggings of the Monkey"] = {
			["mr"] = 1070,
			["H3219"] = 1070,
		},
		["Gothic Plate Helmet of the Bear"] = {
			["mr"] = 29500,
			["H3219"] = 29500,
		},
		["Felcloth"] = {
			["mr"] = 19403,
			["sc"] = 0,
			["id"] = "14256:0:0:0:0",
			["cc"] = 7,
			["H3226"] = 19403,
		},
		["Pattern: Fine Leather Boots"] = {
			["mr"] = 98,
			["H3219"] = 98,
		},
		["Elixir of Giant Growth"] = {
			["H3223"] = 1225,
			["mr"] = 1225,
			["cc"] = 0,
			["id"] = "6662:0:0:0:0",
			["sc"] = 0,
		},
		["Frog Leg Stew"] = {
			["mr"] = 460,
			["H3219"] = 460,
		},
		["Edged Bastard Sword of Strength"] = {
			["mr"] = 2075,
			["H3219"] = 2075,
		},
		["Phalanx Leggings of the Bear"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Scouting Belt of the Boar"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Edged Bastard Sword of the Eagle"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Conjurer's Breeches of Fiery Wrath"] = {
			["mr"] = 9800,
			["cc"] = 4,
			["id"] = "9851:0:0:1889:0",
			["sc"] = 1,
			["H3220"] = 9800,
		},
		["Gloom Reaper of the Whale"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Wicked Blackjack"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Rageclaw Gloves of the Falcon"] = {
			["mr"] = 30000,
			["sc"] = 2,
			["id"] = "15383:0:0:441:0",
			["H3224"] = 30000,
			["cc"] = 4,
		},
		["Battlesmasher of the Monkey"] = {
			["mr"] = 4949,
			["H3219"] = 4949,
		},
		["Short Bastard Sword of the Whale"] = {
			["mr"] = 715,
			["H3219"] = 715,
		},
		["Bandit Jerkin of Spirit"] = {
			["mr"] = 2898,
			["H3219"] = 2898,
		},
		["Bandit Pants of the Eagle"] = {
			["mr"] = 1559,
			["H3219"] = 1559,
		},
		["Willow Gloves of Fiery Wrath"] = {
			["mr"] = 1728,
			["cc"] = 4,
			["id"] = "6541:0:0:1878:0",
			["sc"] = 1,
			["H3220"] = 1728,
		},
		["Prospector's Buckler"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Recipe: Great Rage Potion"] = {
			["mr"] = 5642,
			["sc"] = 6,
			["id"] = "5643:0:0:0:0",
			["cc"] = 9,
			["H3224"] = 5642,
		},
		["Conjurer's Cloak of Stamina"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Buccaneer's Cape of Arcane Wrath"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Dwarven Magestaff of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Infantry Leggings of the Monkey"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Vulture Talon"] = {
			["mr"] = 90,
			["H3219"] = 90,
		},
		["Rageclaw Cloak of Spirit"] = {
			["mr"] = 25000,
			["sc"] = 1,
			["id"] = "15382:0:0:181:0",
			["H3224"] = 25000,
			["cc"] = 4,
		},
		["Craftsman's Monocle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Mooncloth"] = {
			["mr"] = 670000,
			["H3219"] = 670000,
		},
		["Sergeant's Warhammer of Shadow Wrath"] = {
			["mr"] = 1998,
			["H3219"] = 1998,
		},
		["Lesser Bloodstone Ore"] = {
			["mr"] = 1212,
			["H3219"] = 1212,
		},
		["Glyphed Cloak"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Simple Robe of Arcane Wrath"] = {
			["mr"] = 620,
			["H3219"] = 620,
		},
		["Dwarven Hatchet of Stamina"] = {
			["mr"] = 940,
			["H3219"] = 940,
		},
		["Superior Tunic of Power"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Hook Dagger of Healing"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Phalanx Cloak of the Bear"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Scaled Leather Belt of the Whale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Hunting Bow"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Defender Shield of Agility"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Brutal War Axe of the Tiger"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Recipe: Elixir of Giant Growth"] = {
			["H3223"] = 150000,
			["mr"] = 150000,
			["sc"] = 6,
			["id"] = "6663:0:0:0:0",
			["cc"] = 9,
		},
		["Powerful Mojo"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Mo'grosh Can Opener"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Oily Blackmouth"] = {
			["mr"] = 40,
			["H3219"] = 40,
		},
		["Fiery War Axe"] = {
			["mr"] = 975000,
			["H3219"] = 975000,
		},
		["Durable Robe of the Whale"] = {
			["mr"] = 10051,
			["H3219"] = 10051,
		},
		["Legionnaire's Leggings"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Jagged Star of Stamina"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Hillman's Leather Gloves"] = {
			["mr"] = 1049,
			["H3219"] = 1049,
		},
		["Curved Dagger of Power"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Knight's Headguard of the Bear"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Formula: Enchant 2H Weapon - Lesser Spirit"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Raider's Boots of Stamina"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Stonerender Gauntlets"] = {
			["mr"] = 800000,
			["H3219"] = 800000,
		},
		["Shimmering Trousers of Spirit"] = {
			["mr"] = 1567,
			["H3219"] = 1567,
		},
		["Stone Hammer of the Tiger"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Evocator's Blade"] = {
			["mr"] = 19500,
			["H3219"] = 19500,
		},
		["Banded Girdle of Strength"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["War Paint Shield"] = {
			["mr"] = 3899,
			["H3219"] = 3899,
		},
		["Recipe: Slitherskin Mackerel"] = {
			["mr"] = 150,
			["H3219"] = 150,
		},
		["Small Green Pouch"] = {
			["mr"] = 326,
			["H3219"] = 326,
		},
		["Robust Leggings of the Gorilla"] = {
			["mr"] = 5650,
			["H3219"] = 5650,
		},
		["Calico Pants"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Twilight Boots of the Owl"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Skinning Knife"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Scaled Leather Bracers of Nature's Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Myrmidon's Pauldrons"] = {
			["mr"] = 20500,
			["H3219"] = 20500,
		},
		["Wicked Chain Legguards of the Monkey"] = {
			["mr"] = 6267,
			["H3219"] = 6267,
		},
		["Dark Silk Shirt"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Bandit Buckler of Agility"] = {
			["mr"] = 1299,
			["H3219"] = 1299,
		},
		["Bard's Boots of Power"] = {
			["mr"] = 3624,
			["H3219"] = 3624,
		},
		["Durable Pants of the Whale"] = {
			["mr"] = 3568,
			["H3219"] = 3568,
		},
		["Flimsy Chain Vest"] = {
			["mr"] = 65,
			["H3219"] = 65,
		},
		["Chief Brigadier Shield"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Cutthroat's Boots of the Gorilla"] = {
			["mr"] = 8525,
			["H3219"] = 8525,
		},
		["Jazeraint Boots of the Falcon"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Lunar Slippers of the Eagle"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Buccaneer's Cape of Stamina"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Conjurer's Breeches of the Owl"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Star Ruby"] = {
			["mr"] = 5752,
			["sc"] = 0,
			["id"] = "7910:0:0:0:0",
			["H3224"] = 5752,
			["cc"] = 7,
		},
		["Raider's Bracers of the Boar"] = {
			["mr"] = 2037,
			["H3219"] = 2037,
		},
		["Coarse Sharpening Stone"] = {
			["mr"] = 50,
			["H3219"] = 50,
		},
		["Outrunner's Chestguard of Power"] = {
			["mr"] = 5600,
			["H3219"] = 5600,
		},
		["Dwarven Magestaff of Healing"] = {
			["mr"] = 10800,
			["H3219"] = 10800,
		},
		["Bard's Trousers of the Eagle"] = {
			["mr"] = 623,
			["H3219"] = 623,
		},
		["Soldier's Girdle of the Boar"] = {
			["mr"] = 1607,
			["H3219"] = 1607,
		},
		["Recipe: Elixir of Fortitude"] = {
			["H3223"] = 2000,
			["mr"] = 2000,
			["sc"] = 6,
			["id"] = "3830:0:0:0:0",
			["cc"] = 9,
		},
		["Salt Shaker"] = {
			["mr"] = 149000,
			["H3219"] = 149000,
		},
		["Pattern: Felcloth Hood"] = {
			["mr"] = 160000,
			["cc"] = 9,
			["id"] = "14496:0:0:0:0",
			["sc"] = 2,
			["H3226"] = 160000,
		},
		["Hook Dagger of Fiery Wrath"] = {
			["mr"] = 3899,
			["cc"] = 2,
			["id"] = "3184:0:0:1876:0",
			["sc"] = 15,
			["H3220"] = 3899,
		},
		["Ridge Cleaver of the Whale"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Captain's Circlet of the Monkey"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Deadly Kris of the Bear"] = {
			["mr"] = 19599,
			["H3219"] = 19599,
		},
		["Twilight Gloves of Fiery Wrath"] = {
			["mr"] = 10752,
			["cc"] = 4,
			["id"] = "7433:0:0:1885:0",
			["sc"] = 1,
			["H3220"] = 10752,
		},
		["White Woolen Dress"] = {
			["mr"] = 830,
			["cc"] = 4,
			["id"] = "6787:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 830,
		},
		["Barbaric Loincloth"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Conjurer's Breeches of the Eagle"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Searing Blade"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Sentry's Leggings of the Gorilla"] = {
			["mr"] = 6851,
			["H3219"] = 6851,
		},
		["Knight's Pauldrons of the Whale"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Redbeard Crest"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Edged Bastard Sword of the Monkey"] = {
			["mr"] = 2375,
			["H3219"] = 2375,
		},
		["Raider's Bracers of the Gorilla"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Green Iron Leggings"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Bandit Boots of the Owl"] = {
			["mr"] = 798,
			["H3219"] = 798,
		},
		["Plans: Heavy Mithril Pants"] = {
			["mr"] = 4778,
			["H3219"] = 4778,
		},
		["Brown Leather Satchel"] = {
			["mr"] = 1258,
			["H3219"] = 1258,
		},
		["Recipe: Murloc Fin Soup"] = {
			["mr"] = 476,
			["H3219"] = 476,
		},
		["Raider's Legguards of Strength"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Elder's Padded Armor of Shadow Wrath"] = {
			["mr"] = 29999,
			["H3219"] = 29999,
		},
		["Native Pants of the Eagle"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Formula: Enchant Bracer - Minor Spirit"] = {
			["mr"] = 197,
			["H3219"] = 197,
		},
		["Band of Thorns"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Dreamless Sleep Potion"] = {
			["mr"] = 3396,
			["H3219"] = 3396,
		},
		["Red Wolf Meat"] = {
			["mr"] = 294,
			["cc"] = 7,
			["id"] = "12203:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 294,
		},
		["The Green Tower"] = {
			["mr"] = 250000,
			["H3219"] = 250000,
		},
		["Zircon Band of Shadow Resistance"] = {
			["mr"] = 4752,
			["H3219"] = 4752,
		},
		["Raider's Boots of the Eagle"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Gold Power Core"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Runecloth"] = {
			["mr"] = 749,
			["cc"] = 7,
			["H3224"] = 754,
			["H3226"] = 749,
			["sc"] = 0,
			["H3225"] = 750,
			["id"] = "14047:0:0:0:0",
		},
		["Pagan Shoes of Spirit"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Raider's Chestpiece of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Pattern: Barbaric Leggings"] = {
			["mr"] = 1847,
			["H3219"] = 1847,
		},
		["Brutal War Axe of the Boar"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Meaty Bat Wing"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Aboriginal Rod of Arcane Wrath"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Stonecloth Circlet"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Inscribed Leather Belt"] = {
			["mr"] = 398,
			["H3219"] = 398,
		},
		["Birchwood Maul of Strength"] = {
			["mr"] = 2867,
			["H3219"] = 2867,
		},
		["Buccaneer's Gloves of the Owl"] = {
			["mr"] = 2150,
			["H3219"] = 2150,
		},
		["Copper Shortsword"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Crystalpine Stinger"] = {
			["mr"] = 34400,
			["H3219"] = 34400,
		},
		["Dervish Buckler of the Monkey"] = {
			["mr"] = 5476,
			["H3219"] = 5476,
		},
		["Bard's Bracers of Intellect"] = {
			["mr"] = 1399,
			["H3219"] = 1399,
		},
		["Spiked Club of the Eagle"] = {
			["mr"] = 916,
			["H3219"] = 916,
		},
		["Flask of Big Mojo"] = {
			["mr"] = 595,
			["cc"] = 7,
			["id"] = "8152:0:0:0:0",
			["H3219"] = 595,
			["sc"] = 0,
		},
		["Disciple's Pants of Fiery Wrath"] = {
			["mr"] = 1493,
			["cc"] = 4,
			["id"] = "6267:0:0:1876:0",
			["sc"] = 1,
			["H3220"] = 1493,
		},
		["Defender Shield of Strength"] = {
			["mr"] = 3695,
			["H3219"] = 3695,
		},
		["Sentry Cloak"] = {
			["mr"] = 41999,
			["H3219"] = 41999,
		},
		["Elemental Air"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Basalt Ring of the Boar"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Plans: Dazzling Mithril Rapier"] = {
			["mr"] = 9701,
			["H3219"] = 9701,
		},
		["Raw Loch Frenzy"] = {
			["mr"] = 14,
			["H3219"] = 14,
		},
		["Archer's Buckler of the Monkey"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Okra"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Simple Branch of the Wolf"] = {
			["mr"] = 850,
			["H3219"] = 850,
		},
		["Elixir of Detect Demon"] = {
			["H3223"] = 4000,
			["mr"] = 4000,
			["sc"] = 0,
			["id"] = "9233:0:0:0:0",
			["cc"] = 0,
		},
		["Monstrous War Axe of the Whale"] = {
			["mr"] = 24000,
			["H3219"] = 24000,
		},
		["Hulking Cloak"] = {
			["mr"] = 940,
			["H3219"] = 940,
		},
		["Blackened Defias Leggings"] = {
			["mr"] = 1920,
			["H3219"] = 1920,
		},
		["Raider's Gauntlets of Power"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Runed Copper Belt"] = {
			["mr"] = 297,
			["H3219"] = 297,
		},
		["Bandit Jerkin of Power"] = {
			["mr"] = 3164,
			["H3219"] = 3164,
		},
		["Arcane Elixir"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Gypsy Trousers of the Gorilla"] = {
			["mr"] = 485,
			["H3219"] = 485,
		},
		["Ravager's Woolies"] = {
			["H3224"] = 20000,
			["cc"] = 4,
			["id"] = "14775:0:0:0:0",
			["sc"] = 3,
			["mr"] = 20000,
		},
		["Birchwood Maul of the Bear"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Wicked Chain Shield of Stamina"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Knight's Pauldrons of the Bear"] = {
			["mr"] = 9445,
			["H3219"] = 9445,
		},
		["Long Silken Cloak"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Laced Mail Shoulderpads"] = {
			["mr"] = 1990,
			["H3219"] = 1990,
		},
		["Greater Scythe of Strength"] = {
			["mr"] = 24750,
			["H3219"] = 24750,
		},
		["Mithril Bar"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Superior Belt of the Boar"] = {
			["mr"] = 8496,
			["H3219"] = 8496,
		},
		["Greenweave Sandals of the Falcon"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Scouting Trousers of the Owl"] = {
			["mr"] = 1595,
			["H3219"] = 1595,
		},
		["Burnished Pauldrons"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Ivycloth Gloves of the Whale"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Robes of Arcana"] = {
			["mr"] = 11800,
			["H3219"] = 11800,
		},
		["Knight's Headguard of the Whale"] = {
			["mr"] = 10900,
			["H3219"] = 10900,
		},
		["Pattern: Dark Silk Shirt"] = {
			["mr"] = 5800,
			["H3219"] = 5800,
		},
		["Phalanx Girdle of Power"] = {
			["mr"] = 3466,
			["H3219"] = 3466,
		},
		["Battering Hammer of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Sharp Claw"] = {
			["mr"] = 67,
			["cc"] = 7,
			["id"] = "5635:0:0:0:0",
			["H3219"] = 67,
			["sc"] = 0,
		},
		["Native Pants of Spirit"] = {
			["mr"] = 2832,
			["H3219"] = 2832,
		},
		["Mystic's Cape"] = {
			["mr"] = 590,
			["sc"] = 1,
			["id"] = "14365:0:0:0:0",
			["H3219"] = 590,
			["cc"] = 4,
		},
		["Wastewander Water Pouch"] = {
			["mr"] = 867,
			["H3219"] = 867,
		},
		["Mail Combat Leggings"] = {
			["mr"] = 5558,
			["H3219"] = 5558,
		},
		["Bard's Tunic of the Owl"] = {
			["mr"] = 1050,
			["H3219"] = 1050,
		},
		["Ritual Cape of Spirit"] = {
			["mr"] = 1090,
			["H3219"] = 1090,
		},
		["Dervish Tunic of Nature's Wrath"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Archer's Trousers of the Monkey"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Ornate Mithril Helm"] = {
			["mr"] = 36768,
			["H3219"] = 36768,
		},
		["Pattern: Rugged Leather Pants"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Knight's Crest of the Bear"] = {
			["mr"] = 20241,
			["H3219"] = 20241,
		},
		["Formula: Enchant Gloves - Advanced Herbalism"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Bandit Buckler of the Bear"] = {
			["mr"] = 2498,
			["H3219"] = 2498,
		},
		["Banded Shield of Blocking"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Imperial Cloak"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Sage's Boots of Arcane Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Scaled Leather Shoulders of the Monkey"] = {
			["mr"] = 18750,
			["H3219"] = 18750,
		},
		["Scouting Cloak of Nature's Wrath"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Skull Splitting Crossbow"] = {
			["mr"] = 136565,
			["H3219"] = 136565,
		},
		["Healing Potion"] = {
			["mr"] = 220,
			["cc"] = 0,
			["id"] = "929:0:0:0:0",
			["H3219"] = 220,
			["sc"] = 0,
		},
		["Bard's Belt of the Whale"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Pattern: Azure Shoulders"] = {
			["mr"] = 8775,
			["H3219"] = 8775,
		},
		["Schematic: World Enlarger"] = {
			["mr"] = 44400,
			["H3219"] = 44400,
		},
		["Forest Tracker Epaulets"] = {
			["mr"] = 57000,
			["H3219"] = 57000,
		},
		["Plans: Mithril Shield Spike"] = {
			["mr"] = 39800,
			["H3219"] = 39800,
		},
		["Greater Mystic Essence"] = {
			["mr"] = 1475,
			["sc"] = 0,
			["id"] = "11135:0:0:0:0",
			["H3219"] = 1475,
			["cc"] = 7,
		},
		["Spiritchaser Staff of the Boar"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Soothing Turtle Bisque"] = {
			["mr"] = 497,
			["H3219"] = 497,
		},
		["Ivy Orb of the Eagle"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Recipe: Redridge Goulash"] = {
			["mr"] = 325,
			["H3219"] = 325,
		},
		["Sage's Cloak of Arcane Wrath"] = {
			["mr"] = 2618,
			["H3219"] = 2618,
		},
		["Mystic's Belt"] = {
			["H3210"] = 4000,
			["mr"] = 4000,
			["sc"] = 1,
			["id"] = "14025:0:0:0:0",
			["cc"] = 4,
		},
		["Decapitating Sword of the Monkey"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Aboriginal Footwraps of the Eagle"] = {
			["mr"] = 1390,
			["H3219"] = 1390,
		},
		["Murphstar of Strength"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Conjurer's Shoes of the Whale"] = {
			["mr"] = 17061,
			["H3219"] = 17061,
		},
		["Mighty Troll's Blood Potion"] = {
			["mr"] = 2066,
			["H3219"] = 2066,
		},
		["Schematic: Gnomish Cloaking Device"] = {
			["mr"] = 36500,
			["H3219"] = 36500,
		},
		["Night Watch Shortsword"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Battleforge Cloak of Defense"] = {
			["mr"] = 2984,
			["H3219"] = 2984,
		},
		["Rough Dynamite"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Silver Contact"] = {
			["mr"] = 38,
			["H3219"] = 38,
		},
		["Willow Cape of Fiery Wrath"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Conjurer's Cinch of Fiery Wrath"] = {
			["mr"] = 12200,
			["cc"] = 4,
			["id"] = "9853:0:0:1885:0",
			["sc"] = 1,
			["H3220"] = 12200,
		},
		["Medium Armor Kit"] = {
			["mr"] = 200,
			["H3219"] = 200,
		},
		["Fused Wiring"] = {
			["mr"] = 5400,
			["cc"] = 7,
			["id"] = "7191:0:0:0:0",
			["H3224"] = 5400,
			["sc"] = 1,
		},
		["Wicked Chain Bracers of the Bear"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Ritual Sandals of the Owl"] = {
			["mr"] = 2149,
			["H3219"] = 2149,
		},
		["Fortified Cloak of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Recipe: Elixir of Ogre's Strength"] = {
			["H3223"] = 1564,
			["mr"] = 1564,
			["sc"] = 6,
			["id"] = "6211:0:0:0:0",
			["cc"] = 9,
		},
		["Cross Dagger of Arcane Wrath"] = {
			["mr"] = 42069,
			["H3219"] = 42069,
		},
		["Warmonger's Bracers of the Wolf"] = {
			["mr"] = 14444,
			["H3219"] = 14444,
		},
		["Twilight Cape of Fiery Wrath"] = {
			["mr"] = 20500,
			["cc"] = 4,
			["L3220"] = 20500,
			["id"] = "7436:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 25331,
		},
		["Sage's Circlet of the Owl"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Mo'grosh Toothpick"] = {
			["mr"] = 2799,
			["H3219"] = 2799,
		},
		["Conjurer's Gloves of Healing"] = {
			["mr"] = 8026,
			["H3219"] = 8026,
		},
		["Twilight Pants of the Eagle"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Barbaric Battle Axe of the Bear"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Glyphed Leggings"] = {
			["mr"] = 5699,
			["H3219"] = 5699,
		},
		["Greenweave Cloak of the Whale"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Chrome Ring of Concentration"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Bandit Boots of Spirit"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sturdy Quarterstaff of the Monkey"] = {
			["mr"] = 1320,
			["H3219"] = 1320,
		},
		["Willow Pants of the Owl"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Barbaric Battle Axe of the Wolf"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Dervish Bracers of Agility"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Pillager's Gloves of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Black Lotus"] = {
			["mr"] = 662000,
			["H3219"] = 662000,
		},
		["Sage's Gloves of the Owl"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Moon Cleaver of Power"] = {
			["mr"] = 200000,
			["H3219"] = 200000,
		},
		["Pioneer Tunic of Power"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Ivycloth Sash of the Wolf"] = {
			["mr"] = 6580,
			["H3219"] = 6580,
		},
		["Archer's Longbow"] = {
			["mr"] = 4388,
			["H3219"] = 4388,
		},
		["Bandit Cloak of the Falcon"] = {
			["mr"] = 816,
			["H3219"] = 816,
		},
		["Shimmering Trousers of the Whale"] = {
			["mr"] = 1295,
			["H3219"] = 1295,
		},
		["Brackwater Vest"] = {
			["mr"] = 1450,
			["H3219"] = 1450,
		},
		["Knight's Legguards of the Eagle"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Infantry Leggings of Power"] = {
			["mr"] = 390,
			["H3219"] = 390,
		},
		["Conjurer's Breeches of the Whale"] = {
			["mr"] = 8175,
			["H3219"] = 8175,
		},
		["Jagged Star of the Bear"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Light Armor Kit"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Schematic: Goblin Jumper Cables"] = {
			["mr"] = 6200,
			["H3219"] = 6200,
		},
		["Shimmering Boots of the Falcon"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Elixir of Water Breathing"] = {
			["H3223"] = 724,
			["mr"] = 724,
			["sc"] = 0,
			["id"] = "5996:0:0:0:0",
			["cc"] = 0,
		},
		["War Paint Anklewraps"] = {
			["mr"] = 1272,
			["H3219"] = 1272,
		},
		["Rat Cloth Cloak"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Recipe: Crocolisk Gumbo"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Raider's Belt of Strength"] = {
			["mr"] = 1027,
			["H3219"] = 1027,
		},
		["Geomancer's Gloves of the Whale"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Sage's Cloak of Fiery Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Pattern: Earthen Leather Shoulders"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Forester's Axe of the Eagle"] = {
			["mr"] = 3594,
			["H3219"] = 3594,
		},
		["Elixir of Firepower"] = {
			["H3223"] = 72,
			["mr"] = 72,
			["sc"] = 0,
			["id"] = "6373:0:0:0:0",
			["cc"] = 0,
		},
		["Schematic: Goblin Land Mine"] = {
			["mr"] = 2496,
			["H3219"] = 2496,
		},
		["Scouting Belt of the Eagle"] = {
			["mr"] = 1260,
			["H3219"] = 1260,
		},
		["Cavalier Two-hander of the Eagle"] = {
			["mr"] = 13746,
			["H3219"] = 13746,
		},
		["Shadow Weaver Leggings"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Leaded Vial"] = {
			["mr"] = 1220,
			["H3219"] = 1220,
		},
		["Parrot Cage (Green Wing Macaw)"] = {
			["mr"] = 1089,
			["H3219"] = 1089,
		},
		["Hefty Battlehammer of the Gorilla"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Buccaneer's Orb of Arcane Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Small Silk Pack"] = {
			["mr"] = 2500,
			["cc"] = 1,
			["id"] = "4245:0:0:0:0",
			["H3219"] = 2500,
			["sc"] = 0,
		},
		["Hefty Battlehammer of the Boar"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Heavy Scorpid Scale"] = {
			["mr"] = 8900,
			["cc"] = 15,
			["id"] = "15408:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 8900,
		},
		["Rageclaw Shoulder Pads of Stamina"] = {
			["mr"] = 16209,
			["sc"] = 2,
			["id"] = "15386:0:0:218:0",
			["H3224"] = 16209,
			["cc"] = 4,
		},
		["Willow Boots of the Whale"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Copper Dagger"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Raider's Legguards of the Whale"] = {
			["mr"] = 1045,
			["H3219"] = 1045,
		},
		["Lesser Belt of the Spire"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Greenweave Sash of Fiery Wrath"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Dwarven Magestaff of Intellect"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Phalanx Boots of the Boar"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Notched Shortsword of Power"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Medium Leather"] = {
			["mr"] = 70,
			["sc"] = 0,
			["id"] = "2319:0:0:0:0",
			["H3219"] = 70,
			["cc"] = 7,
		},
		["Renegade Shield of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Elder's Sash of the Whale"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Wizbang's Special Brew"] = {
			["mr"] = 45,
			["H3219"] = 45,
		},
		["Blood Shard"] = {
			["mr"] = 43,
			["sc"] = 0,
			["id"] = "5075:0:0:0:0",
			["H3219"] = 43,
			["cc"] = 12,
		},
		["Superior Tunic of the Owl"] = {
			["mr"] = 12010,
			["H3219"] = 12010,
		},
		["Outrunner's Cuffs of the Bear"] = {
			["mr"] = 7368,
			["H3219"] = 7368,
		},
		["Wolf Rider's Leggings of the Eagle"] = {
			["mr"] = 20134,
			["H3219"] = 20134,
		},
		["Silvered Bronze Gauntlets"] = {
			["mr"] = 1498,
			["H3219"] = 1498,
		},
		["Light Leather"] = {
			["mr"] = 26,
			["H3219"] = 26,
		},
		["Insignia Chestguard"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Heavy Linen Gloves"] = {
			["mr"] = 30,
			["H3219"] = 30,
		},
		["Tender Wolf Steak"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Book: Gift of the Wild"] = {
			["mr"] = 59500,
			["H3219"] = 59500,
		},
		["Greater Astral Essence"] = {
			["mr"] = 1500,
			["sc"] = 0,
			["id"] = "11082:0:0:0:0",
			["H3219"] = 1500,
			["cc"] = 7,
		},
		["Hardened Iron Shortsword"] = {
			["mr"] = 10999,
			["H3219"] = 10999,
		},
		["Fine Thread"] = {
			["mr"] = 996,
			["H3219"] = 996,
		},
		["Magician Staff of the Wolf"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Scorpid Scale"] = {
			["mr"] = 1114,
			["cc"] = 15,
			["L3220"] = 1114,
			["id"] = "8154:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 1115,
		},
		["Recipe: Lesser Stoneshield Potion"] = {
			["H3223"] = 900,
			["H3225"] = 16999,
			["cc"] = 9,
			["id"] = "4624:0:0:0:0",
			["sc"] = 6,
			["H3221"] = 919,
			["mr"] = 16999,
		},
		["Bard's Trousers of the Whale"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Pioneer Tunic of the Whale"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Green Hills of Stranglethorn - Page 27"] = {
			["mr"] = 620,
			["sc"] = 0,
			["id"] = "2751:0:0:0:0",
			["H3219"] = 620,
			["cc"] = 15,
		},
		["Bronze Tube"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Chimera Leather"] = {
			["mr"] = 1585,
			["cc"] = 7,
			["id"] = "15423:0:0:0:0",
			["H3221"] = 1585,
			["sc"] = 0,
		},
		["Lodestone Necklace of the Bear"] = {
			["mr"] = 23400,
			["H3219"] = 23400,
		},
		["Valorous Chestguard"] = {
			["H3224"] = 60000,
			["cc"] = 4,
			["id"] = "8274:0:0:0:0",
			["sc"] = 4,
			["mr"] = 60000,
		},
		["Dervish Gloves of Defense"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Mark of the Syndicate"] = {
			["mr"] = 685,
			["H3219"] = 685,
		},
		["Willow Cape of the Whale"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Plans: Silvered Bronze Breastplate"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Stormbringer Belt"] = {
			["mr"] = 9900,
			["sc"] = 3,
			["id"] = "12978:0:0:0:0",
			["H3219"] = 9900,
			["cc"] = 4,
		},
		["Willow Boots of Shadow Wrath"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Bard's Belt of Intellect"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Buccaneer's Gloves of the Falcon"] = {
			["mr"] = 1257,
			["H3219"] = 1257,
		},
		["Massive Iron Axe"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Durable Pants of Fiery Wrath"] = {
			["mr"] = 5000,
			["cc"] = 4,
			["id"] = "9825:0:0:1887:0",
			["sc"] = 1,
			["H3220"] = 5000,
		},
		["Fortified Chain of Stamina"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Twilight Boots of Spirit"] = {
			["mr"] = 7800,
			["H3219"] = 7800,
		},
		["Battleforge Legguards of the Gorilla"] = {
			["mr"] = 4030,
			["H3219"] = 4030,
		},
		["Dreadblade of the Tiger"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Dervish Boots of the Owl"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Banded Bracers of the Gorilla"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Frost Oil"] = {
			["mr"] = 7999,
			["sc"] = 0,
			["id"] = "3829:0:0:0:0",
			["H3219"] = 7999,
			["cc"] = 0,
		},
		["Widowmaker"] = {
			["mr"] = 399999,
			["H3219"] = 399999,
		},
		["Cadet Vest of the Whale"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Medium Quiver"] = {
			["mr"] = 2799,
			["H3219"] = 2799,
		},
		["Thick Scale Breastplate of the Bear"] = {
			["mr"] = 14422,
			["H3219"] = 14422,
		},
		["Dervish Belt of the Eagle"] = {
			["mr"] = 2772,
			["H3219"] = 2772,
		},
		["Training Sword of the Boar"] = {
			["mr"] = 665,
			["H3219"] = 665,
		},
		["Conjurer's Vest of the Owl"] = {
			["mr"] = 11126,
			["H3219"] = 11126,
		},
		["Arctic Ring of the Tiger"] = {
			["mr"] = 49900,
			["H3219"] = 49900,
		},
		["Recipe: Blood Sausage"] = {
			["mr"] = 296,
			["H3219"] = 296,
		},
		["Pattern: Red Mageweave Vest"] = {
			["mr"] = 6300,
			["H3219"] = 6300,
		},
		["Ebon Scimitar of the Monkey"] = {
			["mr"] = 29700,
			["H3219"] = 29700,
		},
		["Training Sword of the Monkey"] = {
			["mr"] = 550,
			["H3219"] = 550,
		},
		["Greenweave Sandals of the Owl"] = {
			["mr"] = 7119,
			["H3219"] = 7119,
		},
		["Lupine Buckler of the Falcon"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Renegade Circlet of the Eagle"] = {
			["mr"] = 44232,
			["H3219"] = 44232,
		},
		["Sniper Rifle of the Falcon"] = {
			["mr"] = 27900,
			["H3219"] = 27900,
		},
		["Watcher's Cinch of Fiery Wrath"] = {
			["mr"] = 4500,
			["cc"] = 4,
			["id"] = "14185:0:0:1881:0",
			["sc"] = 1,
			["H3220"] = 4500,
		},
		["Pattern: Volcanic Leggings"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Boar Intestines"] = {
			["mr"] = 18,
			["H3219"] = 18,
		},
		["Double-stitched Woolen Shoulders"] = {
			["mr"] = 340,
			["cc"] = 4,
			["id"] = "4314:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 340,
		},
		["Bloodspattered Shield of the Tiger"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Raider's Shield of Blocking"] = {
			["mr"] = 2382,
			["H3219"] = 2382,
		},
		["Glimmering Mail Bracers"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Elder's Hat of the Wolf"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Rage Potion"] = {
			["mr"] = 12400,
			["sc"] = 0,
			["id"] = "5631:0:0:0:0",
			["cc"] = 0,
			["H3224"] = 12400,
		},
		["Earthen Vest"] = {
			["mr"] = 4343,
			["H3219"] = 4343,
		},
		["Sturdy Quarterstaff of the Bear"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Sanguine Cape"] = {
			["mr"] = 1893,
			["H3219"] = 1893,
		},
		["Soldier's Gauntlets of Power"] = {
			["mr"] = 780,
			["H3219"] = 780,
		},
		["Trueshot Bow of the Wolf"] = {
			["mr"] = 36099,
			["H3219"] = 36099,
		},
		["Scaled Leather Tunic of the Monkey"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Middle Map Fragment"] = {
			["mr"] = 2300,
			["sc"] = 0,
			["id"] = "9253:0:0:0:0",
			["H3219"] = 2300,
			["cc"] = 12,
		},
		["Bard's Tunic of Stamina"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Devilsaur Leather"] = {
			["H3223"] = 86775,
			["H3224"] = 87000,
			["cc"] = 7,
			["id"] = "15417:0:0:0:0",
			["L3224"] = 82875,
			["sc"] = 0,
			["mr"] = 82875,
		},
		["Birchwood Maul of the Gorilla"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Oak Mallet of the Bear"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Stonesplinter Mace"] = {
			["mr"] = 943,
			["H3219"] = 943,
		},
		["Ornate Mithril Gloves"] = {
			["mr"] = 19900,
			["H3219"] = 19900,
		},
		["Bandit Cloak of Intellect"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Beaded Britches of the Monkey"] = {
			["mr"] = 480,
			["H3219"] = 480,
		},
		["Buccaneer's Robes of Arcane Wrath"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Regal Boots of the Eagle"] = {
			["mr"] = 19000,
			["H3219"] = 19000,
		},
		["Grizzly Jerkin of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Massive Battle Axe of the Tiger"] = {
			["mr"] = 4973,
			["H3219"] = 4973,
		},
		["Quickdraw Quiver"] = {
			["mr"] = 29199,
			["H3219"] = 29199,
		},
		["Goretusk Snout"] = {
			["mr"] = 27,
			["H3219"] = 27,
		},
		["Scouting Spaulders"] = {
			["mr"] = 2985,
			["H3219"] = 2985,
		},
		["Handstitched Leather Boots"] = {
			["mr"] = 35,
			["H3219"] = 35,
		},
		["Sprouted Frond"] = {
			["mr"] = 86,
			["H3219"] = 86,
		},
		["Crafted Light Shot"] = {
			["mr"] = 1,
			["H3219"] = 1,
		},
		["Ranger Cloak of Intellect"] = {
			["mr"] = 11500,
			["H3219"] = 11500,
		},
		["Archer's Gloves of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Pattern: Dusky Leather Leggings"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Disciple's Robe of Stamina"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Charred Wolf Meat"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Scalping Tomahawk of Stamina"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Prairie Ring of Eluding"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Tin Ore"] = {
			["mr"] = 198,
			["H3219"] = 198,
		},
		["Soldier's Armor of the Monkey"] = {
			["mr"] = 8100,
			["H3219"] = 8100,
		},
		["Massive Battle Axe of Strength"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Huntsman's Boots of the Monkey"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Goblin Deviled Clams"] = {
			["mr"] = 125,
			["H3219"] = 125,
		},
		["Red Linen Robe"] = {
			["mr"] = 199,
			["H3219"] = 199,
		},
		["Sentry's Cape of the Monkey"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Nightsky Armor"] = {
			["mr"] = 9900,
			["sc"] = 1,
			["id"] = "7111:0:0:0:0",
			["H3219"] = 9900,
			["cc"] = 4,
		},
		["Troll's Bane Leggings"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Bandit Jerkin of the Eagle"] = {
			["mr"] = 1895,
			["H3219"] = 1895,
		},
		["Bubbling Water"] = {
			["mr"] = 439,
			["H3219"] = 439,
		},
		["Oak Mallet of the Monkey"] = {
			["mr"] = 2673,
			["H3219"] = 2673,
		},
		["Greenweave Bracers of the Whale"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Emblazoned Hat"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Jet Chain of the Bear"] = {
			["mr"] = 27500,
			["H3219"] = 27500,
		},
		["Rough Sharpening Stone"] = {
			["mr"] = 3,
			["H3219"] = 3,
		},
		["Magician Staff of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Knightly Longsword of the Tiger"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Magician Staff of the Monkey"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["War Knife of Frozen Wrath"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Recipe: Superior Mana Potion"] = {
			["H3210"] = 24500,
			["mr"] = 24500,
			["sc"] = 6,
			["id"] = "13477:0:0:0:0",
			["cc"] = 9,
		},
		["Ivycloth Boots of the Falcon"] = {
			["mr"] = 2469,
			["H3219"] = 2469,
		},
		["Sparkleshell Gauntlets of the Eagle"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Pagan Shoes of Arcane Wrath"] = {
			["mr"] = 2914,
			["H3219"] = 2914,
		},
		["Ivycloth Tunic of Shadow Wrath"] = {
			["mr"] = 24900,
			["H3219"] = 24900,
		},
		["Goblin Nutcracker of the Bear"] = {
			["mr"] = 29800,
			["H3219"] = 29800,
		},
		["Azure Silk Vest"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Spongy Morel"] = {
			["mr"] = 32,
			["H3219"] = 32,
		},
		["Plans: Wildthorn Mail"] = {
			["mr"] = 148500,
			["cc"] = 9,
			["id"] = "12691:0:0:0:0",
			["sc"] = 4,
			["H3220"] = 148500,
		},
		["Buccaneer's Robes of the Whale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Iron Counterweight"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Murphstar of the Bear"] = {
			["mr"] = 11500,
			["H3219"] = 11500,
		},
		["Forester's Axe of the Whale"] = {
			["mr"] = 2437,
			["H3219"] = 2437,
		},
		["Huntsman's Gloves of Spirit"] = {
			["mr"] = 7600,
			["H3219"] = 7600,
		},
		["Elder's Amber Stave of the Whale"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Willow Vest of Shadow Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Practice Sword"] = {
			["mr"] = 495,
			["H3219"] = 495,
		},
		["Pioneer Trousers of the Eagle"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Ritual Bands of Fiery Wrath"] = {
			["mr"] = 2800,
			["cc"] = 4,
			["id"] = "14122:0:0:1877:0",
			["sc"] = 1,
			["H3220"] = 2800,
		},
		["Handstitched Leather Pants"] = {
			["mr"] = 80,
			["H3219"] = 80,
		},
		["Recipe: Elixir of Detect Lesser Invisibility"] = {
			["H3223"] = 3299,
			["mr"] = 3299,
			["sc"] = 6,
			["id"] = "3832:0:0:0:0",
			["cc"] = 9,
		},
		["Icecap"] = {
			["H3224"] = 3460,
			["cc"] = 7,
			["id"] = "13467:0:0:0:0",
			["sc"] = 0,
			["mr"] = 3460,
		},
		["Gold Ore"] = {
			["mr"] = 1599,
			["cc"] = 7,
			["id"] = "2776:0:0:0:0",
			["H3219"] = 1599,
			["sc"] = 0,
		},
		["Crusader Bow of the Monkey"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Captain's Cloak of Stamina"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Archer's Boots of Nature's Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Small Radiant Shard"] = {
			["mr"] = 8500,
			["sc"] = 0,
			["id"] = "11177:0:0:0:0",
			["H3219"] = 8500,
			["cc"] = 7,
		},
		["Bandit Buckler of the Monkey"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Banded Boots of Stamina"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Regal Cloak of Fiery Wrath"] = {
			["mr"] = 13000,
			["cc"] = 4,
			["id"] = "7474:0:0:1883:0",
			["sc"] = 1,
			["H3220"] = 13000,
		},
		["Merc Sword of the Bear"] = {
			["mr"] = 2597,
			["H3219"] = 2597,
		},
		["Pattern: Red Linen Vest"] = {
			["mr"] = 300,
			["H3219"] = 300,
		},
		["Chipped Quarterstaff"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Bandit Cloak of the Whale"] = {
			["mr"] = 501,
			["H3219"] = 501,
		},
		["Copper Mace"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Giant Club of Stamina"] = {
			["mr"] = 105060,
			["H3219"] = 105060,
		},
		["Sequoia Branch of Stamina"] = {
			["mr"] = 26526,
			["H3219"] = 26526,
		},
		["Wrangler's Buckler of Fiery Wrath"] = {
			["mr"] = 3900,
			["cc"] = 4,
			["id"] = "15332:0:0:1879:0",
			["sc"] = 6,
			["H3220"] = 3900,
		},
		["Sage's Pants of Healing"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Scouting Boots of the Eagle"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Small Venom Sac"] = {
			["mr"] = 105,
			["H3219"] = 105,
		},
		["Defender Spaulders"] = {
			["mr"] = 1590,
			["H3219"] = 1590,
		},
		["Archer's Cloak of the Wolf"] = {
			["mr"] = 3850,
			["H3219"] = 3850,
		},
		["Umbral Crystal"] = {
			["mr"] = 39999,
			["H3219"] = 39999,
		},
		["Superior Belt of the Bear"] = {
			["mr"] = 4388,
			["H3219"] = 4388,
		},
		["Hillborne Axe of the Wolf"] = {
			["mr"] = 14600,
			["H3219"] = 14600,
		},
		["Raider's Chestpiece of the Bear"] = {
			["mr"] = 1475,
			["H3219"] = 1475,
		},
		["Crag Boar Rib"] = {
			["mr"] = 9,
			["H3219"] = 9,
		},
		["Hacking Cleaver of the Wolf"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Ebonclaw Reaver of the Boar"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Wand of Eventide"] = {
			["mr"] = 4200,
			["sc"] = 19,
			["id"] = "5214:0:0:0:0",
			["H3219"] = 4200,
			["cc"] = 2,
		},
		["Soldier's Girdle of the Monkey"] = {
			["mr"] = 1299,
			["H3219"] = 1299,
		},
		["Wicked Chain Gauntlets of Strength"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Superior Buckler of Blocking"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Twilight Gloves of the Monkey"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Banded Shield of Stamina"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Pathfinder Belt of Defense"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Cerulean Talisman of Strength"] = {
			["mr"] = 20101,
			["H3219"] = 20101,
		},
		["Tough Jerky"] = {
			["mr"] = 39,
			["H3219"] = 39,
		},
		["Robust Cloak of the Wolf"] = {
			["mr"] = 2541,
			["H3219"] = 2541,
		},
		["Willow Gloves of the Whale"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Scroll of Protection"] = {
			["mr"] = 30,
			["H3219"] = 30,
		},
		["Elixir of Fortitude"] = {
			["H3223"] = 1346,
			["mr"] = 1599,
			["cc"] = 0,
			["id"] = "3825:0:0:0:0",
			["sc"] = 0,
			["H3226"] = 1599,
		},
		["Wicked Leather Gauntlets"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Pattern: Red Whelp Gloves"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Ebonclaw Reaver of the Eagle"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Gypsy Tunic of Intellect"] = {
			["mr"] = 620,
			["H3219"] = 620,
		},
		["Bard's Boots of the Wolf"] = {
			["mr"] = 794,
			["H3219"] = 794,
		},
		["Silk Cloth"] = {
			["mr"] = 188,
			["sc"] = 0,
			["id"] = "4306:0:0:0:0",
			["H3224"] = 188,
			["cc"] = 7,
		},
		["Plans: Polished Steel Boots"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Burnished Cloak"] = {
			["mr"] = 440,
			["H3219"] = 440,
		},
		["Glimmering Cloak"] = {
			["mr"] = 1215,
			["H3219"] = 1215,
		},
		["Heavy Silk Bandage"] = {
			["mr"] = 555,
			["sc"] = 0,
			["id"] = "6451:0:0:0:0",
			["H3219"] = 555,
			["cc"] = 0,
		},
		["Banded Gauntlets of the Bear"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Core of Earth"] = {
			["mr"] = 765,
			["H3219"] = 765,
		},
		["Renegade Pauldrons of the Eagle"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Mithril Ore"] = {
			["mr"] = 2400,
			["cc"] = 7,
			["id"] = "3858:0:0:0:0",
			["H3221"] = 2400,
			["sc"] = 0,
		},
		["Toughened Leather Armor"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Potent Helmet of the Monkey"] = {
			["mr"] = 25580,
			["H3219"] = 25580,
		},
		["Magician Staff of Spirit"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Twin-bladed Axe of Stamina"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Fen Ring of the Monkey"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Superior Mana Potion"] = {
			["H3224"] = 33800,
			["cc"] = 0,
			["H3226"] = 7400,
			["sc"] = 0,
			["mr"] = 7400,
			["id"] = "13443:0:0:0:0",
		},
		["Sentinel Gloves of the Wolf"] = {
			["mr"] = 11386,
			["H3219"] = 11386,
		},
		["Seasoned Wolf Kabob"] = {
			["mr"] = 137,
			["H3219"] = 137,
		},
		["Severing Axe of the Bear"] = {
			["mr"] = 595,
			["H3219"] = 595,
		},
		["Sanguine Mantle"] = {
			["mr"] = 9750,
			["H3219"] = 9750,
		},
		["Fortified Gauntlets of Strength"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Outrunner's Cuffs of Strength"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Polished Zweihander of the Bear"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Inscribed Leather Gloves"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Golden Sansam"] = {
			["mr"] = 514,
			["cc"] = 7,
			["id"] = "13464:0:0:0:0",
			["H3224"] = 514,
			["sc"] = 0,
		},
		["Crystal Basilisk Spine"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Renegade Belt of the Whale"] = {
			["mr"] = 6947,
			["H3219"] = 6947,
		},
		["Shiny Red Apple"] = {
			["mr"] = 29,
			["H3219"] = 29,
		},
		["Magician Staff of Arcane Wrath"] = {
			["mr"] = 12404,
			["H3219"] = 12404,
		},
		["Ivycloth Cloak of Arcane Wrath"] = {
			["mr"] = 3197,
			["H3219"] = 3197,
		},
		["Ritual Leggings of Fiery Wrath"] = {
			["mr"] = 2000,
			["cc"] = 4,
			["id"] = "14125:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 2000,
		},
		["Shadowhide Battle Axe"] = {
			["mr"] = 3366,
			["H3219"] = 3366,
		},
		["Ivycloth Boots of the Owl"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Bard's Trousers of the Owl"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Buccaneer's Cape of Spirit"] = {
			["mr"] = 950,
			["H3219"] = 950,
		},
		["Turtle Scale"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Raw Mithril Head Trout"] = {
			["mr"] = 102,
			["H3219"] = 102,
		},
		["Buccaneer's Cord of the Wolf"] = {
			["mr"] = 2061,
			["H3219"] = 2061,
		},
		["Ivy Orb of Arcane Wrath"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Pattern: Felcloth Boots"] = {
			["mr"] = 140000,
			["cc"] = 9,
			["id"] = "14492:0:0:0:0",
			["sc"] = 2,
			["H3226"] = 140000,
		},
		["Pattern: Stylish Green Shirt"] = {
			["mr"] = 595,
			["H3219"] = 595,
		},
		["Handstitched Leather Vest"] = {
			["mr"] = 49,
			["H3219"] = 49,
		},
		["Scouting Cloak of the Eagle"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Durable Pants of the Falcon"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Conjurer's Shoes of the Eagle"] = {
			["mr"] = 6800,
			["H3219"] = 6800,
		},
		["Simple Branch of Fiery Wrath"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Combat Shield"] = {
			["mr"] = 8400,
			["H3219"] = 8400,
		},
		["Seer's Belt"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Heavy Leather Ammo Pouch"] = {
			["mr"] = 4001,
			["cc"] = 11,
			["id"] = "7372:0:0:0:0",
			["H3219"] = 4001,
			["sc"] = 3,
		},
		["Simple Blouse of the Whale"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Chief Brigadier Coif"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Shimmering Boots of Frozen Wrath"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Hefty Battlehammer of the Bear"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Raider's Belt of the Boar"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Hook Dagger of Nature's Wrath"] = {
			["mr"] = 2199,
			["H3219"] = 2199,
		},
		["Nightsky Cowl"] = {
			["mr"] = 9599,
			["H3219"] = 9599,
		},
		["Battleforge Shield of Agility"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Raider's Chestpiece of Strength"] = {
			["mr"] = 1908,
			["H3219"] = 1908,
		},
		["Blazing Wand"] = {
			["mr"] = 1449,
			["H3219"] = 1449,
		},
		["Pattern: Living Shoulders"] = {
			["mr"] = 29800,
			["H3219"] = 29800,
		},
		["Fortified Belt of the Bear"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Greenstone Circle of the Bear"] = {
			["mr"] = 15500,
			["H3219"] = 15500,
		},
		["Battle Knife of the Monkey"] = {
			["mr"] = 4799,
			["H3219"] = 4799,
		},
		["Phalanx Gauntlets of the Bear"] = {
			["mr"] = 4055,
			["H3219"] = 4055,
		},
		["Forester's Axe of the Bear"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Rigid Cape of the Monkey"] = {
			["mr"] = 1944,
			["H3219"] = 1944,
		},
		["Banded Girdle of the Eagle"] = {
			["mr"] = 8126,
			["H3219"] = 8126,
		},
		["Plans: Jade Serpentblade"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Grunt's Cape of Stamina"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Stonecloth Epaulets"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Wicked Chain Waistband of the Bear"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Beer Basted Boar Ribs"] = {
			["mr"] = 60,
			["H3219"] = 60,
		},
		["Pattern: Tough Scorpid Breastplate"] = {
			["mr"] = 7100,
			["H3219"] = 7100,
		},
		["Gnoll Skull Basher"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Dervish Leggings of the Whale"] = {
			["mr"] = 3833,
			["H3219"] = 3833,
		},
		["Willow Gloves of Spirit"] = {
			["mr"] = 762,
			["H3219"] = 762,
		},
		["Pattern: Blue Overalls"] = {
			["mr"] = 873,
			["H3219"] = 873,
		},
		["Bard's Buckler of the Tiger"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Beazel's Basher"] = {
			["mr"] = 27398,
			["H3219"] = 27398,
		},
		["Bandit Cloak of Arcane Wrath"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Runecloth Belt"] = {
			["H3225"] = 15028,
			["cc"] = 4,
			["id"] = "13856:0:0:0:0",
			["sc"] = 1,
			["mr"] = 15028,
			["H3224"] = 23999,
		},
		["Glimmering Mail Gauntlets"] = {
			["mr"] = 2925,
			["H3219"] = 2925,
		},
		["Wood Chopper"] = {
			["mr"] = 246,
			["H3219"] = 246,
		},
		["Hacking Cleaver of Agility"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Spiked Club of Spirit"] = {
			["mr"] = 960,
			["H3219"] = 960,
		},
		["Bard's Trousers of Arcane Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Sage's Mantle of the Wolf"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Pioneer Tunic of Stamina"] = {
			["mr"] = 560,
			["H3219"] = 560,
		},
		["Elemental Fire"] = {
			["mr"] = 5400,
			["sc"] = 0,
			["id"] = "7068:0:0:0:0",
			["cc"] = 5,
			["H3224"] = 5400,
		},
		["Buccaneer's Cord of Healing"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Hillborne Axe of the Tiger"] = {
			["mr"] = 12499,
			["H3219"] = 12499,
		},
		["Battleforge Shoulderguards of the Bear"] = {
			["mr"] = 10798,
			["H3219"] = 10798,
		},
		["Scouting Tunic of Power"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Simple Robe of the Whale"] = {
			["mr"] = 430,
			["H3219"] = 430,
		},
		["Wicked Chain Waistband of the Gorilla"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Warrior's Pants"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Willow Bracers of Spirit"] = {
			["mr"] = 2258,
			["H3219"] = 2258,
		},
		["Greenstone Circle of the Boar"] = {
			["mr"] = 10900,
			["H3219"] = 10900,
		},
		["Cured Medium Hide"] = {
			["mr"] = 585,
			["H3219"] = 585,
		},
		["Pattern: Colorful Kilt"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Battlesmasher of Arcane Wrath"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Priest's Mace of Arcane Wrath"] = {
			["mr"] = 580,
			["H3219"] = 580,
		},
		["Durable Pants of Spirit"] = {
			["mr"] = 3700,
			["H3219"] = 3700,
		},
		["Formula: Enchant Gloves - Skinning"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Scaled Leather Tunic of Power"] = {
			["mr"] = 35000,
			["H3219"] = 35000,
		},
		["Crusader's Cloak of Agility"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Headhunting Spear"] = {
			["mr"] = 19900,
			["H3219"] = 19900,
		},
		["Breath of Wind"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Stranglekelp"] = {
			["mr"] = 150,
			["sc"] = 0,
			["id"] = "3820:0:0:0:0",
			["H3219"] = 150,
			["cc"] = 7,
		},
		["Aquamarine Ring of Fire Resistance"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Infantry Shield of the Gorilla"] = {
			["mr"] = 1045,
			["H3219"] = 1045,
		},
		["Defender Tunic of Power"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Cadet Shield of Strength"] = {
			["mr"] = 2081,
			["H3219"] = 2081,
		},
		["Gleaming Claymore of the Wolf"] = {
			["mr"] = 1979,
			["H3219"] = 1979,
		},
		["Pattern: Runecloth Gloves"] = {
			["H3223"] = 72500,
			["mr"] = 62500,
			["sc"] = 2,
			["id"] = "14481:0:0:0:0",
			["H3224"] = 30000,
			["cc"] = 9,
			["H3225"] = 62500,
		},
		["Raider Shortsword of Power"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Codex: Prayer of Fortitude"] = {
			["mr"] = 66500,
			["H3219"] = 66500,
		},
		["Burning Charm"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Emblazoned Chestpiece"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Gnarled Ash Staff"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Sage's Sash of the Wolf"] = {
			["mr"] = 3850,
			["H3219"] = 3850,
		},
		["Gloves of Old"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Aboriginal Vest of Stamina"] = {
			["mr"] = 1743,
			["H3219"] = 1743,
		},
		["Volatile Rum"] = {
			["mr"] = 491,
			["sc"] = 0,
			["id"] = "9260:0:0:0:0",
			["H3219"] = 491,
			["cc"] = 0,
		},
		["Emblazoned Cloak"] = {
			["mr"] = 1395,
			["H3219"] = 1395,
		},
		["Infiltrator Cloak of the Monkey"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Sutarn's Ring"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Ritual Bands of Spirit"] = {
			["mr"] = 1690,
			["H3219"] = 1690,
		},
		["Raider Shortsword of Strength"] = {
			["mr"] = 1599,
			["H3219"] = 1599,
		},
		["Lil Timmy's Peashooter"] = {
			["mr"] = 20087,
			["H3219"] = 20087,
		},
		["Defender Tunic of Stamina"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Forest Buckler"] = {
			["mr"] = 2296,
			["H3219"] = 2296,
		},
		["Feral Leggings of the Eagle"] = {
			["mr"] = 1360,
			["H3219"] = 1360,
		},
		["Gigantic War Axe of the Wolf"] = {
			["mr"] = 44527,
			["H3219"] = 44527,
		},
		["Royal Cape of the Whale"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Scouting Tunic of Agility"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Blackfang"] = {
			["mr"] = 9750,
			["H3219"] = 9750,
		},
		["Raider's Cloak of Strength"] = {
			["mr"] = 730,
			["H3219"] = 730,
		},
		["Falcon's Hook"] = {
			["mr"] = 18400,
			["H3219"] = 18400,
		},
		["Quartz Ring of Shadow Resistance"] = {
			["mr"] = 8900,
			["cc"] = 4,
			["H3209"] = 8900,
			["id"] = "11965:0:0:1449:0",
			["sc"] = 0,
		},
		["Hefty Battlehammer of Spirit"] = {
			["mr"] = 3830,
			["H3219"] = 3830,
		},
		["Gypsy Buckler of Blocking"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Scouting Buckler of the Tiger"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Yellow Power Crystal"] = {
			["mr"] = 654,
			["H3219"] = 654,
		},
		["Orb of Mistmantle"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Rumsey Rum Light"] = {
			["mr"] = 72,
			["H3219"] = 72,
		},
		["Chief Brigadier Girdle"] = {
			["mr"] = 5998,
			["H3219"] = 5998,
		},
		["Durable Cape of the Whale"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Recipe: Westfall Stew"] = {
			["mr"] = 99,
			["H3219"] = 99,
		},
		["Battleforge Girdle of Strength"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Sentinel Trousers of the Monkey"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Edged Bastard Sword of Stamina"] = {
			["mr"] = 2457,
			["H3219"] = 2457,
		},
		["Recipe: Major Healing Potion"] = {
			["H3223"] = 49975,
			["mr"] = 49975,
			["sc"] = 6,
			["id"] = "13480:0:0:0:0",
			["H3221"] = 47500,
			["cc"] = 9,
		},
		["Aurora Cloak"] = {
			["mr"] = 4388,
			["H3219"] = 4388,
		},
		["Ceremonial Leather Harness"] = {
			["mr"] = 760,
			["H3219"] = 760,
		},
		["Curved Dagger of Healing"] = {
			["mr"] = 7260,
			["H3219"] = 7260,
		},
		["Ivycloth Pants of the Eagle"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Greater Scythe of the Monkey"] = {
			["mr"] = 85155,
			["H3219"] = 85155,
		},
		["Bard's Gloves of the Falcon"] = {
			["mr"] = 998,
			["H3219"] = 998,
		},
		["Ritual Belt of Fiery Wrath"] = {
			["mr"] = 1499,
			["cc"] = 4,
			["id"] = "14131:0:0:1878:0",
			["sc"] = 1,
			["H3220"] = 1499,
		},
		["Disciple's Vest of Arcane Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Redridge Goulash"] = {
			["mr"] = 233,
			["H3219"] = 233,
		},
		["Brilliant Smallfish"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["Green Hills of Stranglethorn - Page 24"] = {
			["mr"] = 1053,
			["H3219"] = 1053,
		},
		["Journeyman's Vest"] = {
			["H3225"] = 300,
			["sc"] = 1,
			["id"] = "2957:0:0:0:0",
			["mr"] = 300,
			["cc"] = 4,
		},
		["Pattern: Runecloth Pants"] = {
			["H3224"] = 50000,
			["cc"] = 9,
			["id"] = "14491:0:0:0:0",
			["sc"] = 2,
			["mr"] = 50000,
		},
		["Deadly Scope"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Superior Gloves of the Owl"] = {
			["mr"] = 4899,
			["H3219"] = 4899,
		},
		["Buccaneer's Robes of the Owl"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Simple Britches of Spirit"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Pattern: Runecloth Robe"] = {
			["H3225"] = 52500,
			["cc"] = 9,
			["id"] = "14469:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 44500,
			["mr"] = 52500,
		},
		["Pattern: Living Leggings"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Red Whelp Gloves"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Red Woolen Boots"] = {
			["H3224"] = 2370,
			["cc"] = 4,
			["id"] = "4313:0:0:0:0",
			["sc"] = 1,
			["mr"] = 2370,
		},
		["Big Bear Meat"] = {
			["mr"] = 102,
			["H3219"] = 102,
		},
		["Soldier's Gauntlets of the Monkey"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Ankh of Life"] = {
			["mr"] = 63375,
			["H3219"] = 63375,
		},
		["Huntsman's Boots of the Gorilla"] = {
			["mr"] = 8473,
			["H3219"] = 8473,
		},
		["Elixir of Superior Defense"] = {
			["H3223"] = 9097,
			["mr"] = 9097,
			["sc"] = 0,
			["id"] = "13445:0:0:0:0",
			["cc"] = 0,
		},
		["Inscribed Leather Spaulders"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Sequoia Branch of the Boar"] = {
			["mr"] = 24000,
			["H3219"] = 24000,
		},
		["Shimmering Robe of the Whale"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Recipe: Fire Protection Potion"] = {
			["mr"] = 6999,
			["sc"] = 6,
			["id"] = "6055:0:0:0:0",
			["H3219"] = 6999,
			["cc"] = 9,
		},
		["Bandit Cloak of Stamina"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Thick Spider's Silk"] = {
			["mr"] = 1061,
			["cc"] = 7,
			["id"] = "4337:0:0:0:0",
			["H3219"] = 1061,
			["sc"] = 0,
		},
		["Pathfinder Belt of the Owl"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Glimmering Flamberge of the Wolf"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Raider's Shield of Defense"] = {
			["mr"] = 2309,
			["H3219"] = 2309,
		},
		["Phalanx Gauntlets of Strength"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Battlesmasher of the Bear"] = {
			["mr"] = 3967,
			["H3219"] = 3967,
		},
		["Native Branch of the Owl"] = {
			["mr"] = 1050,
			["H3219"] = 1050,
		},
		["Rigid Belt of the Monkey"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Hefty Battlehammer of Power"] = {
			["mr"] = 5628,
			["H3219"] = 5628,
		},
		["Green Hills of Stranglethorn - Page 14"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Barbecued Buzzard Wing"] = {
			["mr"] = 955,
			["H3219"] = 955,
		},
		["Scorching Wand"] = {
			["mr"] = 6200,
			["H3219"] = 6200,
		},
		["War Paint Chestpiece"] = {
			["mr"] = 4449,
			["H3219"] = 4449,
		},
		["Infantry Tunic of Power"] = {
			["mr"] = 792,
			["H3219"] = 792,
		},
		["Blackened Defias Gloves"] = {
			["mr"] = 498,
			["H3219"] = 498,
		},
		["Twilight Cowl of Arcane Wrath"] = {
			["mr"] = 10547,
			["H3219"] = 10547,
		},
		["Geomancer's Spaulders of the Owl"] = {
			["mr"] = 7499,
			["H3219"] = 7499,
		},
		["Rugged Hide"] = {
			["mr"] = 824,
			["cc"] = 7,
			["id"] = "8171:0:0:0:0",
			["sc"] = 0,
			["H3222"] = 824,
		},
		["Warbringer's Spaulders of the Bear"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Tyrant's Shield"] = {
			["mr"] = 35999,
			["H3219"] = 35999,
		},
		["Raider's Chestpiece of the Eagle"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Deanship Claymore"] = {
			["mr"] = 19900,
			["H3219"] = 19900,
		},
		["Scaled Leather Tunic of Spirit"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Twilight Cowl of Intellect"] = {
			["mr"] = 9899,
			["H3219"] = 9899,
		},
		["Archer's Boots of the Whale"] = {
			["mr"] = 7499,
			["H3219"] = 7499,
		},
		["Ravasaur Scale Boots"] = {
			["mr"] = 44399,
			["sc"] = 3,
			["id"] = "13124:0:0:0:0",
			["H3219"] = 44399,
			["cc"] = 4,
		},
		["Jagged Star of Shadow Wrath"] = {
			["mr"] = 4388,
			["H3219"] = 4388,
		},
		["Jet Black Feather"] = {
			["mr"] = 292,
			["cc"] = 5,
			["id"] = "8168:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 292,
		},
		["Bard's Belt of the Owl"] = {
			["mr"] = 599,
			["H3219"] = 599,
		},
		["Huntsman's Gloves of the Owl"] = {
			["mr"] = 6400,
			["H3219"] = 6400,
		},
		["Northern Shortsword of Stamina"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Splitting Hatchet of the Wolf"] = {
			["mr"] = 8562,
			["H3219"] = 8562,
		},
		["Dwarven Hatchet of Strength"] = {
			["mr"] = 765,
			["H3219"] = 765,
		},
		["Sage's Pants of the Falcon"] = {
			["mr"] = 3798,
			["H3219"] = 3798,
		},
		["Sturdy Quarterstaff of the Whale"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Bard's Gloves of the Owl"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Ballast Maul of Strength"] = {
			["mr"] = 10999,
			["H3219"] = 10999,
		},
		["Sentry's Surcoat of Stamina"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Recipe: Holy Protection Potion"] = {
			["mr"] = 2424,
			["sc"] = 6,
			["id"] = "6053:0:0:0:0",
			["H3219"] = 2424,
			["cc"] = 9,
		},
		["Hard Crawler Carapace"] = {
			["mr"] = 444,
			["H3219"] = 444,
		},
		["Polished Jazeraint Armor"] = {
			["mr"] = 95000,
			["H3219"] = 95000,
		},
		["Severing Axe of the Wolf"] = {
			["mr"] = 855,
			["H3219"] = 855,
		},
		["Cavalier Two-hander of the Tiger"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Twin-bladed Axe of the Boar"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Rumsey Rum Black Label"] = {
			["mr"] = 298,
			["H3219"] = 298,
		},
		["Globe of Water"] = {
			["mr"] = 990,
			["H3219"] = 990,
		},
		["Razor's Edge"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Raincaller Mitts of the Eagle"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Aboriginal Rod of Frozen Wrath"] = {
			["mr"] = 8040,
			["H3219"] = 8040,
		},
		["Arthas' Tears"] = {
			["mr"] = 1994,
			["H3219"] = 1994,
		},
		["Dokebi Chestguard"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Buccaneer's Cape of Intellect"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sage's Gloves of Spirit"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Buccaneer's Gloves of the Monkey"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Cadet Boots"] = {
			["mr"] = 300,
			["H3219"] = 300,
		},
		["Ebon Scimitar of Power"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Ivycloth Bracelets of Fiery Wrath"] = {
			["mr"] = 4400,
			["cc"] = 4,
			["id"] = "9793:0:0:1879:0",
			["sc"] = 1,
			["H3220"] = 4400,
		},
		["Sacrificial Kris of the Bear"] = {
			["mr"] = 178440,
			["H3219"] = 178440,
		},
		["Twilight Gloves of Spirit"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Native Pants of the Owl"] = {
			["mr"] = 313,
			["H3219"] = 313,
		},
		["Conjurer's Sphere of Fiery Wrath"] = {
			["mr"] = 12999,
			["cc"] = 4,
			["id"] = "15918:0:0:1883:0",
			["sc"] = 0,
			["H3220"] = 12999,
		},
		["Banded Girdle of the Bear"] = {
			["mr"] = 4874,
			["H3219"] = 4874,
		},
		["Robust Cloak of Spirit"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Khadgar's Whisker"] = {
			["mr"] = 265,
			["H3219"] = 265,
		},
		["Scouting Gloves of the Eagle"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Native Pants of the Monkey"] = {
			["mr"] = 2832,
			["H3219"] = 2832,
		},
		["Bandit Cinch of the Boar"] = {
			["mr"] = 1684,
			["H3219"] = 1684,
		},
		["Bloodwoven Bracers of Healing"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Giant Club of Nature's Wrath"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Twilight Pants of the Monkey"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Goblin Nutcracker of the Tiger"] = {
			["mr"] = 23999,
			["H3219"] = 23999,
		},
		["Gigantic War Axe of the Whale"] = {
			["mr"] = 39506,
			["H3219"] = 39506,
		},
		["Fortified Bracers of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Raw Rainbow Fin Albacore"] = {
			["mr"] = 2,
			["H3219"] = 2,
		},
		["Superior Cloak of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Long Battle Bow"] = {
			["mr"] = 4100,
			["H3219"] = 4100,
		},
		["Spiritchaser Staff of Power"] = {
			["mr"] = 229668,
			["H3219"] = 229668,
		},
		["Dwarven Hatchet of Agility"] = {
			["mr"] = 795,
			["H3219"] = 795,
		},
		["Ivycloth Gloves of Fiery Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Jet Loop of the Bear"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Gleaming Claymore of the Tiger"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Outrunner's Cloak of the Whale"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Durable Tunic of the Whale"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Forest Pendant of the Wolf"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Lesser Magic Essence"] = {
			["mr"] = 497,
			["sc"] = 0,
			["id"] = "10938:0:0:0:0",
			["H3219"] = 497,
			["cc"] = 7,
		},
		["Guardian Blade"] = {
			["mr"] = 32900,
			["H3219"] = 32900,
		},
		["Spiked Club of the Monkey"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Scorpok Pincer"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Staff of Conjuring"] = {
			["mr"] = 5792,
			["H3219"] = 5792,
		},
		["Magician Staff of the Boar"] = {
			["mr"] = 60708,
			["H3219"] = 60708,
		},
		["Infantry Leggings of the Eagle"] = {
			["mr"] = 362,
			["H3219"] = 362,
		},
		["Sorcerer Hat of Intellect"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Jagged Star of the Tiger"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Plans: Thorium Armor"] = {
			["mr"] = 10000,
			["cc"] = 9,
			["id"] = "12682:0:0:0:0",
			["H3221"] = 10000,
			["sc"] = 4,
		},
		["Willow Pants of Fiery Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Ironweb Spider Silk"] = {
			["mr"] = 6000,
			["sc"] = 0,
			["id"] = "14227:0:0:0:0",
			["H3219"] = 6000,
			["cc"] = 7,
		},
		["Conjurer's Mantle of the Whale"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Rough Boomstick"] = {
			["mr"] = 498,
			["H3219"] = 498,
		},
		["Ritual Belt of the Monkey"] = {
			["mr"] = 407,
			["H3219"] = 407,
		},
		["Nightscape Pants"] = {
			["mr"] = 13200,
			["H3219"] = 13200,
		},
		["Freshly Baked Bread"] = {
			["mr"] = 12,
			["H3219"] = 12,
		},
		["Archer's Jerkin of Power"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Goldthorn"] = {
			["mr"] = 449,
			["H3219"] = 449,
		},
		["Bandit Cinch of the Eagle"] = {
			["mr"] = 1037,
			["H3219"] = 1037,
		},
		["Hefty Battlehammer of Strength"] = {
			["mr"] = 4100,
			["H3219"] = 4100,
		},
		["Blackmouth Oil"] = {
			["mr"] = 194,
			["H3219"] = 194,
		},
		["Shimmering Stave of Healing"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Phalanx Headguard of the Tiger"] = {
			["mr"] = 10500,
			["H3219"] = 10500,
		},
		["Prairie Ring of the Wolf"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Spiritchaser Staff of the Wolf"] = {
			["mr"] = 57000,
			["H3219"] = 57000,
		},
		["Soldier's Leggings of the Whale"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Black Mageweave Vest"] = {
			["mr"] = 7299,
			["H3219"] = 7299,
		},
		["Recipe: Elixir of the Mongoose"] = {
			["H3223"] = 19498,
			["mr"] = 19498,
			["cc"] = 9,
			["id"] = "13491:0:0:0:0",
			["sc"] = 6,
		},
		["Stout Battlehammer of Stamina"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Greater Magic Wand"] = {
			["mr"] = 1690,
			["H3219"] = 1690,
		},
		["Disciple's Robe of the Eagle"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Twin-bladed Axe of Agility"] = {
			["mr"] = 1920,
			["H3219"] = 1920,
		},
		["Bard's Trousers of the Wolf"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Battle Slayer of the Monkey"] = {
			["mr"] = 2700,
			["H3219"] = 2700,
		},
		["Cavalier Two-hander of Stamina"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Healing Herb"] = {
			["mr"] = 23,
			["H3219"] = 23,
		},
		["Viridian Band of the Whale"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Buccaneer's Orb of Spirit"] = {
			["mr"] = 2299,
			["H3219"] = 2299,
		},
		["Resilient Cap"] = {
			["mr"] = 11111,
			["H3219"] = 11111,
		},
		["Wild Hog Shank"] = {
			["mr"] = 773,
			["H3219"] = 773,
		},
		["Leaden Mace of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Huntsman's Boots of the Eagle"] = {
			["mr"] = 8365,
			["H3219"] = 8365,
		},
		["War Knife of Power"] = {
			["mr"] = 1795,
			["H3219"] = 1795,
		},
		["Champion's Bracers of the Falcon"] = {
			["mr"] = 39500,
			["H3219"] = 39500,
		},
		["Ghostwalker Legguards of the Owl"] = {
			["mr"] = 15690,
			["H3219"] = 15690,
		},
		["Deeprun Rat Kabob"] = {
			["mr"] = 17,
			["H3219"] = 17,
		},
		["Viscous Hammer"] = {
			["mr"] = 49799,
			["H3219"] = 49799,
		},
		["Recipe: Swiftness Potion"] = {
			["mr"] = 1299,
			["sc"] = 6,
			["id"] = "2555:0:0:0:0",
			["H3219"] = 1299,
			["cc"] = 9,
		},
		["Skycaller"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Blackrock Mace"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Superior Cloak of Agility"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Fortified Leggings of the Tiger"] = {
			["mr"] = 4992,
			["H3219"] = 4992,
		},
		["Cadet Shield of Agility"] = {
			["mr"] = 598,
			["H3219"] = 598,
		},
		["Ivycloth Cloak of the Whale"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bard's Belt of Healing"] = {
			["mr"] = 5075,
			["H3219"] = 5075,
		},
		["Embossed Leather Pants"] = {
			["mr"] = 488,
			["H3219"] = 488,
		},
		["Ogremage Staff"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Dragonbreath Chili"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Cutthroat's Belt of Healing"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Wolfshead Helm"] = {
			["mr"] = 56500,
			["H3219"] = 56500,
		},
		["Scroll of Protection III"] = {
			["mr"] = 147,
			["H3219"] = 147,
		},
		["Embersilk Cloak of Fiery Wrath"] = {
			["mr"] = 8562,
			["cc"] = 4,
			["id"] = "14229:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 8562,
		},
		["Raider's Legguards of the Eagle"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Elder's Pants of the Eagle"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Shimmering Bracers of Arcane Wrath"] = {
			["mr"] = 1549,
			["H3219"] = 1549,
		},
		["Phalanx Shield of the Gorilla"] = {
			["mr"] = 9600,
			["H3219"] = 9600,
		},
		["Dalaran Sharp"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["War Torn Shield of the Tiger"] = {
			["mr"] = 895,
			["H3219"] = 895,
		},
		["Soldier's Gauntlets of the Whale"] = {
			["mr"] = 2963,
			["H3219"] = 2963,
		},
		["Willow Robe of Stamina"] = {
			["mr"] = 795,
			["H3219"] = 795,
		},
		["Scaled Cloak of Agility"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Soldier's Boots of Defense"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Phalanx Headguard of the Bear"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Darnassian Bleu"] = {
			["mr"] = 5,
			["H3219"] = 5,
		},
		["Grunt's Cape of Defense"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Shimmering Cloak of the Whale"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Light Crossbow"] = {
			["mr"] = 715,
			["H3219"] = 715,
		},
		["Durable Boots of the Whale"] = {
			["mr"] = 10669,
			["H3219"] = 10669,
		},
		["Inferno Cloak"] = {
			["mr"] = 4270,
			["H3219"] = 4270,
		},
		["Durable Pants of the Monkey"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Curved Dagger of Agility"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Scaled Leather Bracers of the Owl"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Hunting Rifle"] = {
			["mr"] = 209,
			["H3219"] = 209,
		},
		["Royal Gloves of Healing"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Rageclaw Shoulder Pads of the Owl"] = {
			["mr"] = 15000,
			["sc"] = 2,
			["id"] = "15386:0:0:781:0",
			["H3224"] = 15000,
			["cc"] = 4,
		},
		["Infantry Shield of the Tiger"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Greater Eternal Essence"] = {
			["H3223"] = 19999,
			["mr"] = 15000,
			["cc"] = 7,
			["id"] = "16203:0:0:0:0",
			["H3224"] = 15000,
			["sc"] = 0,
		},
		["Minor Mana Potion"] = {
			["mr"] = 20,
			["sc"] = 0,
			["id"] = "2455:0:0:0:0",
			["H3219"] = 20,
			["cc"] = 0,
		},
		["Savage Axe of the Tiger"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Scroll of Spirit III"] = {
			["mr"] = 423,
			["H3219"] = 423,
		},
		["Frost Protection Potion"] = {
			["mr"] = 33444,
			["H3219"] = 33444,
		},
		["Gloom Reaper of the Eagle"] = {
			["mr"] = 18000,
			["H3219"] = 18000,
		},
		["Obsidian Greaves"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Journeyman's Robe"] = {
			["H3225"] = 1018,
			["sc"] = 1,
			["id"] = "6511:0:0:0:0",
			["mr"] = 1018,
			["cc"] = 4,
		},
		["Copper Ore"] = {
			["mr"] = 48,
			["H3219"] = 48,
		},
		["Banded Helm of Stamina"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Renegade Chestguard of the Bear"] = {
			["mr"] = 20000,
			["cc"] = 4,
			["id"] = "9866:0:0:1205:0",
			["H3213"] = 20000,
			["sc"] = 3,
		},
		["Massive Battle Axe of the Monkey"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Ballast Maul of the Eagle"] = {
			["mr"] = 19899,
			["H3219"] = 19899,
		},
		["Durable Bracers of Fiery Wrath"] = {
			["mr"] = 5999,
			["cc"] = 4,
			["id"] = "9821:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 5999,
		},
		["Rageclaw Bracers of the Monkey"] = {
			["mr"] = 14900,
			["sc"] = 2,
			["id"] = "15380:0:0:604:0",
			["H3224"] = 14900,
			["cc"] = 4,
		},
		["Pioneer Tunic of Intellect"] = {
			["mr"] = 464,
			["H3219"] = 464,
		},
		["Shadoweave Shoulders"] = {
			["mr"] = 59013,
			["H3219"] = 59013,
		},
		["Simple Branch of Holy Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Shadow Protection Potion"] = {
			["mr"] = 1305,
			["H3219"] = 1305,
		},
		["Black Whelp Tunic"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Crisp Spider Meat"] = {
			["mr"] = 50,
			["H3219"] = 50,
		},
		["Knight's Crest of Strength"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Ballast Maul of Stamina"] = {
			["mr"] = 13996,
			["H3219"] = 13996,
		},
		["Dark Leather Boots"] = {
			["mr"] = 493,
			["H3219"] = 493,
		},
		["Lupine Buckler of the Wolf"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Schematic: Goblin Jumper Cables XL"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Libram of Voracity"] = {
			["H3224"] = 243750,
			["cc"] = 9,
			["id"] = "11737:0:0:0:0",
			["sc"] = 0,
			["mr"] = 243750,
		},
		["Bard's Buckler of the Boar"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Feathered Arrow"] = {
			["H3225"] = 49,
			["cc"] = 6,
			["id"] = "3464:0:0:0:0",
			["sc"] = 2,
			["mr"] = 49,
		},
		["Bloodspattered Shield of Stamina"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Aboriginal Loincloth of the Owl"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Gossamer Cape of Healing"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Plans: Green Iron Gauntlets"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Burnished Gloves"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Large Radiant Shard"] = {
			["mr"] = 10000,
			["sc"] = 0,
			["id"] = "11178:0:0:0:0",
			["H3219"] = 10000,
			["cc"] = 7,
		},
		["Willow Bracers of Fiery Wrath"] = {
			["mr"] = 5000,
			["cc"] = 4,
			["id"] = "6543:0:0:1876:0",
			["sc"] = 1,
			["H3220"] = 5000,
		},
		["Ivycloth Robe of the Owl"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Razor Blade of Power"] = {
			["mr"] = 22499,
			["H3219"] = 22499,
		},
		["Stonesplinter Blade"] = {
			["mr"] = 424,
			["H3219"] = 424,
		},
		["Willow Cape of Arcane Wrath"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Green Hills of Stranglethorn - Page 8"] = {
			["mr"] = 540,
			["H3219"] = 540,
		},
		["Toughened Leather Gloves"] = {
			["mr"] = 4850,
			["H3219"] = 4850,
		},
		["Sentinel Bracers of the Falcon"] = {
			["mr"] = 6204,
			["H3219"] = 6204,
		},
		["Scouting Gloves of the Monkey"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Priest's Mace of Nature's Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Sergeant's Warhammer of Stamina"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Glimmering Flamberge of Stamina"] = {
			["mr"] = 17499,
			["H3219"] = 17499,
		},
		["Infantry Leggings of the Whale"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Fortified Leggings of the Gorilla"] = {
			["mr"] = 3168,
			["H3219"] = 3168,
		},
		["Curved Dagger of Frozen Wrath"] = {
			["mr"] = 1815,
			["H3219"] = 1815,
		},
		["Elder's Mantle of the Eagle"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Defender Leggings of the Monkey"] = {
			["mr"] = 4458,
			["H3219"] = 4458,
		},
		["Chrome Ring of Intellect"] = {
			["mr"] = 16000,
			["H3219"] = 16000,
		},
		["Archer's Bracers of Stamina"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Swampchill Fetish"] = {
			["mr"] = 89500,
			["H3219"] = 89500,
		},
		["Dark Leather Belt"] = {
			["mr"] = 735,
			["H3219"] = 735,
		},
		["Stonecloth Belt"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Fortified Leggings of the Boar"] = {
			["mr"] = 19968,
			["H3219"] = 19968,
		},
		["Calico Tunic"] = {
			["mr"] = 130,
			["H3219"] = 130,
		},
		["Scaled Shield of the Eagle"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Renegade Boots of the Bear"] = {
			["mr"] = 8400,
			["H3219"] = 8400,
		},
		["Executioner's Cleaver"] = {
			["mr"] = 900000,
			["H3219"] = 900000,
		},
		["Heaven's Light"] = {
			["mr"] = 99999,
			["H3219"] = 99999,
		},
		["Green Hills of Stranglethorn - Page 10"] = {
			["mr"] = 599,
			["cc"] = 15,
			["id"] = "2734:0:0:0:0",
			["H3219"] = 599,
			["sc"] = 0,
		},
		["Wolf Rider's Gloves of the Whale"] = {
			["mr"] = 7300,
			["H3219"] = 7300,
		},
		["Runecloth Pants"] = {
			["mr"] = 70872,
			["sc"] = 1,
			["id"] = "13865:0:0:0:0",
			["H3225"] = 70872,
			["cc"] = 4,
		},
		["Willow Branch of Healing"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Disciple's Pants of Spirit"] = {
			["mr"] = 378,
			["H3219"] = 378,
		},
		["Soldier's Gauntlets of the Bear"] = {
			["mr"] = 787,
			["H3219"] = 787,
		},
		["The Butcher"] = {
			["mr"] = 200000,
			["H3219"] = 200000,
		},
		["Simple Robe of Shadow Wrath"] = {
			["mr"] = 822,
			["H3219"] = 822,
		},
		["Bloodspattered Surcoat of the Bear"] = {
			["mr"] = 1699,
			["H3219"] = 1699,
		},
		["Silver-thread Amice"] = {
			["mr"] = 8473,
			["H3219"] = 8473,
		},
		["Ivy Orb of the Owl"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Scalping Tomahawk of Agility"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Dark Iron Ore"] = {
			["mr"] = 3749,
			["H3219"] = 3749,
		},
		["Medicine Staff of the Bear"] = {
			["mr"] = 2185,
			["H3219"] = 2185,
		},
		["Scouting Belt of the Owl"] = {
			["mr"] = 1045,
			["H3219"] = 1045,
		},
		["Leaden Mace of Strength"] = {
			["mr"] = 13199,
			["H3219"] = 13199,
		},
		["Stringy Vulture Meat"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Ivycloth Cloak of Intellect"] = {
			["mr"] = 2899,
			["H3219"] = 2899,
		},
		["Veteran Armor"] = {
			["mr"] = 590,
			["H3219"] = 590,
		},
		["Gypsy Trousers of the Bear"] = {
			["mr"] = 725,
			["H3219"] = 725,
		},
		["Gromsblood"] = {
			["mr"] = 3700,
			["cc"] = 7,
			["id"] = "8846:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 3700,
		},
		["Cross Dagger of the Monkey"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Acrobatic Staff of the Wolf"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Stout Battlehammer of the Monkey"] = {
			["mr"] = 2394,
			["H3219"] = 2394,
		},
		["Ritual Cape of Intellect"] = {
			["mr"] = 1145,
			["H3219"] = 1145,
		},
		["Iron Buckle"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Gemmed Copper Gauntlets of the Whale"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Ivycloth Boots of the Whale"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Simple Blouse of Shadow Wrath"] = {
			["mr"] = 1058,
			["H3219"] = 1058,
		},
		["Stonecutter Claymore of the Tiger"] = {
			["mr"] = 14000,
			["H3219"] = 14000,
		},
		["Oil of Olaf"] = {
			["mr"] = 49,
			["H3219"] = 49,
		},
		["Turtle Meat"] = {
			["mr"] = 595,
			["sc"] = 0,
			["id"] = "3712:0:0:0:0",
			["H3219"] = 595,
			["cc"] = 7,
		},
		["Defender Girdle of Strength"] = {
			["mr"] = 6864,
			["H3219"] = 6864,
		},
		["Defender Gauntlets of the Bear"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Priest's Mace of Healing"] = {
			["mr"] = 10569,
			["H3219"] = 10569,
		},
		["Copper Claymore"] = {
			["mr"] = 520,
			["H3219"] = 520,
		},
		["Chrome Ring of the Eagle"] = {
			["mr"] = 24800,
			["H3219"] = 24800,
		},
		["Scouting Buckler of the Boar"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Beaded Wraps of the Whale"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Gaea's Cloak of the Owl"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Spinel Ring of Shadow Resistance"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Superior Tunic of Agility"] = {
			["mr"] = 12325,
			["H3219"] = 12325,
		},
		["Soldier's Leggings of the Eagle"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Ballast Maul of the Whale"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Enchanter's Cowl"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Splitting Hatchet of Agility"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Twilight Boots of Stamina"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Conjurer's Cloak of Fiery Wrath"] = {
			["mr"] = 2500,
			["cc"] = 4,
			["id"] = "9847:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 2500,
		},
		["Truesilver Ore"] = {
			["mr"] = 1900,
			["sc"] = 0,
			["id"] = "7911:0:0:0:0",
			["H3221"] = 1900,
			["cc"] = 7,
		},
		["Sage's Boots of Stamina"] = {
			["mr"] = 7068,
			["H3219"] = 7068,
		},
		["Bard's Boots of Agility"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Mystic's Slippers"] = {
			["mr"] = 1073,
			["sc"] = 1,
			["id"] = "14364:0:0:0:0",
			["H3219"] = 1073,
			["cc"] = 4,
		},
		["Pioneer Tunic of the Owl"] = {
			["mr"] = 949,
			["H3219"] = 949,
		},
		["Bandit Buckler of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Ghost Dye"] = {
			["mr"] = 32500,
			["H3219"] = 32500,
		},
		["Aquadynamic Fish Attractor"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Ritual Gloves of the Falcon"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Gooey Spider Cake"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Archer's Buckler of the Tiger"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Grunt's Shield of Strength"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Imposing Shoulders of the Bear"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Soldier's Shield of Agility"] = {
			["mr"] = 875,
			["H3219"] = 875,
		},
		["Twilight Belt of Fiery Wrath"] = {
			["mr"] = 39800,
			["H3219"] = 39800,
		},
		["Glimmering Flamberge of the Tiger"] = {
			["mr"] = 13200,
			["H3219"] = 13200,
		},
		["Renegade Belt of the Bear"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Beaded Britches of the Owl"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Lesser Invisibility Potion"] = {
			["mr"] = 710,
			["sc"] = 0,
			["id"] = "3823:0:0:0:0",
			["H3219"] = 710,
			["cc"] = 0,
		},
		["Shimmering Sash of Fiery Wrath"] = {
			["mr"] = 3411,
			["cc"] = 4,
			["id"] = "6570:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 3411,
		},
		["Willow Pants of the Monkey"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Fighter Broadsword of the Monkey"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Chromite Chestplate"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Training Sword of Agility"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Thick Leather"] = {
			["H3223"] = 665,
			["H3224"] = 700,
			["L3221"] = 610,
			["id"] = "4304:0:0:0:0",
			["L3222"] = 599,
			["mr"] = 695,
			["cc"] = 7,
			["H3222"] = 699,
			["L3223"] = 634,
			["L3224"] = 695,
			["H3221"] = 660,
			["sc"] = 0,
		},
		["Pattern: Runecloth Tunic"] = {
			["H3225"] = 31123,
			["cc"] = 9,
			["id"] = "14470:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 34125,
			["mr"] = 31123,
		},
		["Shimmering Armor of Frozen Wrath"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Sentinel Girdle of the Eagle"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Journeyman's Cloak"] = {
			["mr"] = 155,
			["sc"] = 1,
			["id"] = "4662:0:0:0:0",
			["H3225"] = 155,
			["cc"] = 4,
		},
		["Ranger Leggings of the Falcon"] = {
			["mr"] = 15599,
			["H3219"] = 15599,
		},
		["Green Dragonscale"] = {
			["H3223"] = 595,
			["mr"] = 595,
			["cc"] = 15,
			["id"] = "15412:0:0:0:0",
			["sc"] = 0,
		},
		["Stonesplinter Dagger"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Splitting Hatchet of the Boar"] = {
			["mr"] = 7100,
			["H3219"] = 7100,
		},
		["Ivycloth Mantle of the Whale"] = {
			["mr"] = 4522,
			["H3219"] = 4522,
		},
		["Ivy Orb of the Wolf"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Furen's Boots"] = {
			["mr"] = 29600,
			["H3219"] = 29600,
		},
		["Buccaneer's Cape of Fiery Wrath"] = {
			["mr"] = 400,
			["cc"] = 4,
			["L3220"] = 400,
			["id"] = "14167:0:0:1877:0",
			["sc"] = 1,
			["H3220"] = 574,
		},
		["Blue Linen Shirt"] = {
			["mr"] = 223,
			["H3219"] = 223,
		},
		["Deviate Scale Belt"] = {
			["mr"] = 48500,
			["H3219"] = 48500,
		},
		["Golden Pearl"] = {
			["H3223"] = 26714,
			["mr"] = 26714,
			["cc"] = 7,
			["id"] = "13926:0:0:0:0",
			["sc"] = 0,
		},
		["Longjaw Mud Snapper"] = {
			["mr"] = 3,
			["H3219"] = 3,
		},
		["Archer's Cloak of the Falcon"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Cadet Vest of the Tiger"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Simple Cord"] = {
			["mr"] = 199,
			["H3219"] = 199,
		},
		["Great Rage Potion"] = {
			["mr"] = 895,
			["sc"] = 0,
			["id"] = "5633:0:0:0:0",
			["cc"] = 0,
			["H3224"] = 895,
		},
		["Blue Power Crystal"] = {
			["mr"] = 390,
			["H3219"] = 390,
		},
		["Warden's Woolies"] = {
			["H3224"] = 12250,
			["cc"] = 4,
			["id"] = "14605:0:0:0:0",
			["sc"] = 2,
			["mr"] = 12250,
		},
		["Shield of Thorsen"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Ivycloth Cloak of Healing"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Sage's Sash of the Eagle"] = {
			["mr"] = 2250,
			["H3219"] = 2250,
		},
		["Infiltrator Buckler of the Bear"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Renegade Circlet of the Bear"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Recipe: Wildvine Potion"] = {
			["mr"] = 3697,
			["H3219"] = 3697,
		},
		["Recipe: Soothing Turtle Bisque"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Willow Cape of Frozen Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sage's Gloves of Fiery Wrath"] = {
			["mr"] = 1873,
			["H3219"] = 1873,
		},
		["White Spider Meat"] = {
			["mr"] = 334,
			["sc"] = 0,
			["id"] = "12205:0:0:0:0",
			["H3219"] = 334,
			["cc"] = 7,
		},
		["Shadowcraft Belt"] = {
			["mr"] = 190000,
			["H3219"] = 190000,
		},
		["Glyphed Buckler"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Willow Branch of the Owl"] = {
			["mr"] = 1175,
			["H3219"] = 1175,
		},
		["Scouting Trousers of Agility"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Ebonhold Shoulderpads"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Willow Pants of the Falcon"] = {
			["mr"] = 1589,
			["H3219"] = 1589,
		},
		["Willow Vest of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Elixir of Brute Force"] = {
			["H3223"] = 23500,
			["mr"] = 23500,
			["sc"] = 0,
			["id"] = "13453:0:0:0:0",
			["cc"] = 0,
		},
		["Soldier's Girdle of the Tiger"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Heart Ring"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Scouting Trousers of the Wolf"] = {
			["mr"] = 3438,
			["H3219"] = 3438,
		},
		["Buccaneer's Boots of Arcane Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Scarlet Wristguards"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Twilight Cowl of Stamina"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Recipe: Mighty Troll's Blood Potion"] = {
			["H3210"] = 17503,
			["mr"] = 17503,
			["sc"] = 6,
			["id"] = "3831:0:0:0:0",
			["cc"] = 9,
		},
		["Journeyman's Belt"] = {
			["H3225"] = 799,
			["sc"] = 1,
			["id"] = "4663:0:0:0:0",
			["mr"] = 799,
			["cc"] = 4,
		},
		["Forest Leather Mantle"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Bandit Cinch of the Monkey"] = {
			["mr"] = 1295,
			["H3219"] = 1295,
		},
		["The Queen's Jewel"] = {
			["mr"] = 14599,
			["H3219"] = 14599,
		},
		["Infiltrator Cloak of Arcane Wrath"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Slayer's Battle Axe"] = {
			["mr"] = 4875,
			["H3219"] = 4875,
		},
		["Bard's Tunic of Intellect"] = {
			["mr"] = 1203,
			["H3219"] = 1203,
		},
		["Blasthorn Bow of Marksmanship"] = {
			["mr"] = 120000,
			["sc"] = 2,
			["id"] = "15288:0:0:1711:0",
			["H3224"] = 120000,
			["cc"] = 2,
		},
		["Bandit Cloak of the Wolf"] = {
			["mr"] = 1060,
			["H3219"] = 1060,
		},
		["Battleforge Armor of the Boar"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Superior Buckler of the Bear"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Infiltrator Pants of the Falcon"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Native Pants of the Whale"] = {
			["mr"] = 530,
			["H3219"] = 530,
		},
		["Handstitched Leather Bracers"] = {
			["mr"] = 52,
			["H3219"] = 52,
		},
		["Grunt's Cape of the Whale"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Aboriginal Sash of the Whale"] = {
			["mr"] = 1497,
			["H3219"] = 1497,
		},
		["Plans: Dark Iron Sunderer"] = {
			["mr"] = 29800,
			["H3219"] = 29800,
		},
		["Wicked Chain Bracers of Stamina"] = {
			["mr"] = 3810,
			["H3219"] = 3810,
		},
		["Infiltrator Shoulders of Intellect"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Training Sword of the Bear"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Stonecutter Claymore of the Boar"] = {
			["mr"] = 10050,
			["H3219"] = 10050,
		},
		["Raider's Gauntlets of the Monkey"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Rigid Belt of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Bandit Gloves of the Eagle"] = {
			["mr"] = 974,
			["H3219"] = 974,
		},
		["Raider's Cloak of the Boar"] = {
			["mr"] = 702,
			["H3219"] = 702,
		},
		["Conjurer's Bracers of Fiery Wrath"] = {
			["mr"] = 15000,
			["cc"] = 4,
			["id"] = "9846:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 15000,
		},
		["Mail Combat Headguard"] = {
			["mr"] = 5499,
			["H3219"] = 5499,
		},
		["Gypsy Trousers of Spirit"] = {
			["mr"] = 795,
			["H3219"] = 795,
		},
		["Sequoia Hammer of the Tiger"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Spiked Club of the Tiger"] = {
			["mr"] = 1045,
			["H3219"] = 1045,
		},
		["Hillman's Shoulders"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Twilight Cape of the Eagle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Durable Boots of the Falcon"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Minor Rejuvenation Potion"] = {
			["mr"] = 31,
			["sc"] = 0,
			["id"] = "2456:0:0:0:0",
			["H3219"] = 31,
			["cc"] = 0,
		},
		["Militant Shortsword of the Tiger"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Forest Leather Pants"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Slarkskin"] = {
			["mr"] = 855,
			["H3219"] = 855,
		},
		["Silksand Wraps"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Pattern: Red Woolen Boots"] = {
			["mr"] = 200,
			["cc"] = 9,
			["id"] = "4345:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 200,
		},
		["Scholarly Robes"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Free Action Potion"] = {
			["mr"] = 198,
			["sc"] = 0,
			["id"] = "5634:0:0:0:0",
			["H3219"] = 198,
			["cc"] = 0,
		},
		["Refreshing Spring Water"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Ranger Boots of the Falcon"] = {
			["mr"] = 31500,
			["H3219"] = 31500,
		},
		["Archer's Cloak of Agility"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Old Greatsword"] = {
			["mr"] = 879,
			["H3219"] = 879,
		},
		["Ivycloth Tunic of the Owl"] = {
			["mr"] = 7700,
			["H3219"] = 7700,
		},
		["Heavy Shortbow"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Pioneer Trousers of the Bear"] = {
			["mr"] = 350,
			["H3219"] = 350,
		},
		["Viking Sword of Power"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Ancestral Orb"] = {
			["mr"] = 693,
			["H3219"] = 693,
		},
		["Soldier's Shield of the Boar"] = {
			["mr"] = 853,
			["H3219"] = 853,
		},
		["Superior Belt of the Tiger"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Darkmist Cape of Fiery Wrath"] = {
			["mr"] = 30000,
			["cc"] = 4,
			["id"] = "14239:0:0:1883:0",
			["sc"] = 1,
			["H3220"] = 30000,
		},
		["Calico Cloak"] = {
			["mr"] = 99,
			["H3219"] = 99,
		},
		["Hawkeye's Bracers"] = {
			["mr"] = 12323,
			["H3219"] = 12323,
		},
		["Greater Scythe of the Boar"] = {
			["mr"] = 136200,
			["H3219"] = 136200,
		},
		["Bard's Tunic of the Eagle"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Tundra Ring of the Wolf"] = {
			["mr"] = 5600,
			["H3219"] = 5600,
		},
		["Shadow Oil"] = {
			["mr"] = 7700,
			["H3219"] = 7700,
		},
		["Wild Steelbloom"] = {
			["mr"] = 197,
			["H3219"] = 197,
		},
		["Heavy Leather Ball"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Pioneer Tunic of the Eagle"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Incendicite Ore"] = {
			["mr"] = 153,
			["H3219"] = 153,
		},
		["Archer's Bracers of the Owl"] = {
			["mr"] = 5499,
			["H3219"] = 5499,
		},
		["Trueshot Bow of the Eagle"] = {
			["mr"] = 26000,
			["H3219"] = 26000,
		},
		["Hi-Impact Mithril Slugs"] = {
			["mr"] = 12,
			["H3219"] = 12,
		},
		["Twin-bladed Axe of the Whale"] = {
			["mr"] = 1910,
			["H3219"] = 1910,
		},
		["Pattern: Stormshroud Pants"] = {
			["mr"] = 190000,
			["H3219"] = 190000,
		},
		["Infiltrator Gloves of the Gorilla"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Insignia Belt"] = {
			["mr"] = 2437,
			["H3219"] = 2437,
		},
		["Iridescent Hammer"] = {
			["mr"] = 15800,
			["H3219"] = 15800,
		},
		["Warrior's Tunic"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Silk-threaded Trousers"] = {
			["mr"] = 472,
			["H3219"] = 472,
		},
		["Ironforge Breastplate"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bandit Pants of the Owl"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Bandit Boots of the Whale"] = {
			["mr"] = 820,
			["H3219"] = 820,
		},
		["Superior Cloak of Stamina"] = {
			["mr"] = 3698,
			["H3219"] = 3698,
		},
		["Phalanx Gauntlets of Power"] = {
			["mr"] = 16000,
			["H3219"] = 16000,
		},
		["Rainbow Fin Albacore"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Greater Mystic Wand"] = {
			["mr"] = 9087,
			["H3219"] = 9087,
		},
		["Deadly Kris of Strength"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Brutal War Axe of Power"] = {
			["mr"] = 8774,
			["H3219"] = 8774,
		},
		["Priest's Mace of Shadow Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Ritual Bands of Healing"] = {
			["mr"] = 1692,
			["H3219"] = 1692,
		},
		["Recipe: Elixir of Giants"] = {
			["H3223"] = 99490,
			["mr"] = 99490,
			["cc"] = 9,
			["id"] = "9298:0:0:0:0",
			["sc"] = 6,
		},
		["Scaled Leather Boots of Agility"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Formula: Enchant Cloak - Minor Agility"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Hacking Cleaver of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Native Branch of Intellect"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Dervish Cape of Defense"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Sturdy Quarterstaff of Healing"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Exquisite Flamberge of Stamina"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Beaded Wraps of the Eagle"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Mighty Rage Potion"] = {
			["mr"] = 39797,
			["sc"] = 0,
			["id"] = "13442:0:0:0:0",
			["H3224"] = 39797,
			["cc"] = 0,
		},
		["Pattern: Icy Cloak"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Stag Meat"] = {
			["mr"] = 124,
			["H3219"] = 124,
		},
		["Banded Shield of the Bear"] = {
			["mr"] = 15195,
			["H3219"] = 15195,
		},
		["Discombobulator Ray"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Pioneer Trousers of the Owl"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Mystic's Gloves"] = {
			["mr"] = 500,
			["sc"] = 1,
			["id"] = "14367:0:0:0:0",
			["H3219"] = 500,
			["cc"] = 4,
		},
		["Sage's Robe of the Whale"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Defender Gauntlets of the Monkey"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Ballast Maul of the Monkey"] = {
			["mr"] = 12800,
			["H3219"] = 12800,
		},
		["Scouting Tunic of the Whale"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Light Quiver"] = {
			["mr"] = 70,
			["H3219"] = 70,
		},
		["Guardian Gloves"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["War Knife of Stamina"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Runed Copper Gauntlets"] = {
			["mr"] = 429,
			["H3219"] = 429,
		},
		["Schematic: Lovingly Crafted Boomstick"] = {
			["mr"] = 1166,
			["H3219"] = 1166,
		},
		["Captain's Breastplate of Agility"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Pillager's Boots of the Bear"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Shimmering Bracers of Spirit"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Raider's Cloak of the Gorilla"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Bard's Trousers of Spirit"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Blinding Powder"] = {
			["mr"] = 449,
			["H3219"] = 449,
		},
		["Book: Gift of the Wild II"] = {
			["mr"] = 375000,
			["H3219"] = 375000,
		},
		["Bandit Cloak of the Owl"] = {
			["mr"] = 1001,
			["H3219"] = 1001,
		},
		["Perfect Deviate Scale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Insignia Boots"] = {
			["mr"] = 8775,
			["H3219"] = 8775,
		},
		["Infiltrator Pants of the Owl"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Exquisite Flamberge of the Bear"] = {
			["mr"] = 24500,
			["H3219"] = 24500,
		},
		["Sage's Cloak of the Whale"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Barbaric Battle Axe of Strength"] = {
			["mr"] = 1895,
			["H3219"] = 1895,
		},
		["Soldier's Girdle of Power"] = {
			["mr"] = 2998,
			["H3219"] = 2998,
		},
		["Simple Blouse of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Journeyman's Boots"] = {
			["H3225"] = 297,
			["sc"] = 1,
			["id"] = "2959:0:0:0:0",
			["mr"] = 297,
			["cc"] = 4,
		},
		["Tracker's Tunic of the Monkey"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Hefty Battlehammer of the Whale"] = {
			["mr"] = 5499,
			["H3219"] = 5499,
		},
		["Midnight Mace"] = {
			["mr"] = 90000,
			["H3219"] = 90000,
		},
		["Arena Bracers"] = {
			["mr"] = 79999,
			["H3219"] = 79999,
		},
		["Grunt Axe of Strength"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Fortified Bracers of the Whale"] = {
			["mr"] = 2099,
			["H3219"] = 2099,
		},
		["Heavy Woolen Pants"] = {
			["mr"] = 795,
			["cc"] = 4,
			["id"] = "4316:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 795,
		},
		["Incendosaur Scale"] = {
			["mr"] = 461,
			["sc"] = 0,
			["id"] = "18944:0:0:0:0",
			["H3219"] = 461,
			["cc"] = 12,
		},
		["Bard's Gloves of the Gorilla"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Insignia Mantle"] = {
			["mr"] = 5700,
			["H3219"] = 5700,
		},
		["Skeletal Gauntlets"] = {
			["mr"] = 575,
			["H3219"] = 575,
		},
		["Medicine Staff of the Boar"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Greater Nether Essence"] = {
			["mr"] = 17800,
			["cc"] = 7,
			["id"] = "11175:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 17800,
		},
		["Heavy Stone"] = {
			["mr"] = 300,
			["H3219"] = 300,
		},
		["Magician's Mantle"] = {
			["mr"] = 42500,
			["H3219"] = 42500,
		},
		["Battering Hammer of Strength"] = {
			["mr"] = 3950,
			["H3219"] = 3950,
		},
		["Fortified Bracers of Stamina"] = {
			["mr"] = 3300,
			["H3219"] = 3300,
		},
		["Bard's Boots of Nature's Wrath"] = {
			["mr"] = 818,
			["H3219"] = 818,
		},
		["Gemmed Copper Gauntlets of the Boar"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Bard's Gloves of the Eagle"] = {
			["mr"] = 865,
			["H3219"] = 865,
		},
		["Explosive Sheep"] = {
			["mr"] = 5480,
			["H3219"] = 5480,
		},
		["Sagefish Delight"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Forester's Axe of Strength"] = {
			["mr"] = 2969,
			["H3219"] = 2969,
		},
		["Great Goretusk Snout"] = {
			["mr"] = 72,
			["H3219"] = 72,
		},
		["Ivycloth Boots of Spirit"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Steelclaw Reaver"] = {
			["mr"] = 59682,
			["H3219"] = 59682,
		},
		["Hunter's Muzzle Loader"] = {
			["mr"] = 1475,
			["H3219"] = 1475,
		},
		["Sentinel Breastplate of the Owl"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Scouting Tunic of Stamina"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Gleaming Claymore of the Monkey"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Severing Axe of the Eagle"] = {
			["mr"] = 703,
			["H3219"] = 703,
		},
		["Clam Meat"] = {
			["mr"] = 47,
			["H3219"] = 47,
		},
		["Defender Cloak of Healing"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Fortified Shield of the Bear"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Infiltrator Boots of the Eagle"] = {
			["mr"] = 22500,
			["H3219"] = 22500,
		},
		["Pattern: Devilsaur Gauntlets"] = {
			["mr"] = 129500,
			["H3219"] = 129500,
		},
		["Rigid Bracelets of Stamina"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Dervish Gloves of Healing"] = {
			["mr"] = 5231,
			["H3219"] = 5231,
		},
		["Scaled Leather Tunic of the Eagle"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Elixir of Poison Resistance"] = {
			["H3223"] = 387,
			["mr"] = 387,
			["cc"] = 0,
			["id"] = "3386:0:0:0:0",
			["sc"] = 0,
		},
		["Rhahk'Zor's Hammer"] = {
			["mr"] = 1250,
			["H3219"] = 1250,
		},
		["Green Iron Gauntlets"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Greenstone Circle of the Gorilla"] = {
			["mr"] = 14529,
			["H3219"] = 14529,
		},
		["Oak Mallet of the Whale"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Sage's Mantle of Arcane Wrath"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Plans: Blue Glittering Axe"] = {
			["mr"] = 11700,
			["H3219"] = 11700,
		},
		["Infiltrator Armor of the Owl"] = {
			["mr"] = 4950,
			["H3219"] = 4950,
		},
		["Dwarven Magestaff of the Owl"] = {
			["mr"] = 25700,
			["H3219"] = 25700,
		},
		["Banded Cloak of the Whale"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Plans: Inlaid Mithril Cylinder"] = {
			["mr"] = 23250,
			["H3219"] = 23250,
		},
		["Plaguebloom"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Emblazoned Belt"] = {
			["mr"] = 2967,
			["H3219"] = 2967,
		},
		["Canvas Shoulderpads"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Greater Magic Essence"] = {
			["mr"] = 1300,
			["sc"] = 0,
			["id"] = "10939:0:0:0:0",
			["H3219"] = 1300,
			["cc"] = 7,
		},
		["Black Malice"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Phalanx Boots of the Tiger"] = {
			["mr"] = 7580,
			["H3219"] = 7580,
		},
		["Manual: Mageweave Bandage"] = {
			["mr"] = 5900,
			["sc"] = 7,
			["id"] = "16113:0:0:0:0",
			["H3219"] = 5900,
			["cc"] = 9,
		},
		["Scroll of Agility"] = {
			["mr"] = 82,
			["H3219"] = 82,
		},
		["Formula: Enchant Chest - Minor Mana"] = {
			["mr"] = 125,
			["H3219"] = 125,
		},
		["Elixir of Minor Fortitude"] = {
			["H3223"] = 39,
			["mr"] = 39,
			["sc"] = 0,
			["id"] = "2458:0:0:0:0",
			["cc"] = 0,
		},
		["Massive Battle Axe of Stamina"] = {
			["mr"] = 3074,
			["H3219"] = 3074,
		},
		["Pattern: White Leather Jerkin"] = {
			["mr"] = 187,
			["H3219"] = 187,
		},
		["Bandit Pants of the Gorilla"] = {
			["mr"] = 1839,
			["H3219"] = 1839,
		},
		["Wing of the Whelpling"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Seer's Padded Armor"] = {
			["mr"] = 1012,
			["H3219"] = 1012,
		},
		["Trueshot Bow of Agility"] = {
			["mr"] = 15500,
			["H3219"] = 15500,
		},
		["Buccaneer's Boots of the Whale"] = {
			["mr"] = 552,
			["H3219"] = 552,
		},
		["Massive Battle Axe of the Boar"] = {
			["mr"] = 3700,
			["H3219"] = 3700,
		},
		["Disciple's Robe of Intellect"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Thick Hide"] = {
			["mr"] = 500,
			["cc"] = 7,
			["id"] = "8169:0:0:0:0",
			["H3221"] = 500,
			["sc"] = 0,
		},
		["Crafted Solid Shot"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Infiltrator Cord of the Eagle"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Wrangler's Leggings of the Owl"] = {
			["mr"] = 4039,
			["H3219"] = 4039,
		},
		["Silver Ore"] = {
			["mr"] = 1721,
			["H3219"] = 1721,
		},
		["Splitting Hatchet of the Eagle"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Scouting Bracers of Agility"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Bandit Shoulders"] = {
			["mr"] = 1890,
			["H3219"] = 1890,
		},
		["Bard's Tunic of Nature's Wrath"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Bluegill Kukri"] = {
			["mr"] = 6083,
			["H3219"] = 6083,
		},
		["Emblazoned Boots"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Forest Leather Chestpiece"] = {
			["mr"] = 2243,
			["H3219"] = 2243,
		},
		["War Knife of Arcane Wrath"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Mistscape Boots"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Barbaric Linen Vest"] = {
			["mr"] = 324,
			["H3219"] = 324,
		},
		["Viridian Band of the Owl"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Knight's Breastplate of the Bear"] = {
			["mr"] = 12489,
			["H3219"] = 12489,
		},
		["Gloves of Meditation"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Simple Britches of the Falcon"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Yorgen Bracers"] = {
			["mr"] = 14900,
			["H3219"] = 14900,
		},
		["Pattern: Reinforced Woolen Shoulders"] = {
			["mr"] = 5500,
			["cc"] = 9,
			["id"] = "4347:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 5500,
		},
		["Knight's Headguard of Stamina"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Pattern: Green Silk Armor"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Training Sword of the Eagle"] = {
			["mr"] = 765,
			["H3219"] = 765,
		},
		["Seer's Mantle"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Cadet Shield of the Tiger"] = {
			["mr"] = 1150,
			["H3219"] = 1150,
		},
		["Pattern: Thick Murloc Armor"] = {
			["mr"] = 1675,
			["H3219"] = 1675,
		},
		["Red Leather Bag"] = {
			["mr"] = 875,
			["H3219"] = 875,
		},
		["Sanguine Cuffs"] = {
			["mr"] = 2033,
			["H3219"] = 2033,
		},
		["Huntsman's Bands of Healing"] = {
			["mr"] = 31068,
			["H3219"] = 31068,
		},
		["Hook Dagger of Arcane Wrath"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Giant Club of the Bear"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Gleaming Claymore of Stamina"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Gray Woolen Shirt"] = {
			["mr"] = 715,
			["cc"] = 4,
			["id"] = "2587:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 715,
		},
		["Outrunner's Cloak of the Bear"] = {
			["mr"] = 807,
			["H3219"] = 807,
		},
		["Magician Staff of the Bear"] = {
			["mr"] = 12200,
			["H3219"] = 12200,
		},
		["Dreamsinger Legguards"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Superior Cloak of Spirit"] = {
			["mr"] = 4754,
			["H3219"] = 4754,
		},
		["Polished Zweihander of Power"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Phalanx Shield of the Tiger"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Huntsman's Cape of the Falcon"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Sentinel Trousers of the Owl"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Nightscape Headband"] = {
			["mr"] = 6400,
			["H3219"] = 6400,
		},
		["Spiked Chain Gauntlets of the Bear"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Recipe: Savory Deviate Delight"] = {
			["mr"] = 159900,
			["H3219"] = 159900,
		},
		["Murloc Fin Soup"] = {
			["mr"] = 130,
			["H3219"] = 130,
		},
		["Brutal War Axe of Stamina"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Defender Leggings of the Eagle"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Raider's Chestpiece of the Whale"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Aquamarine"] = {
			["mr"] = 5000,
			["sc"] = 0,
			["id"] = "7909:0:0:0:0",
			["cc"] = 7,
			["H3220"] = 5000,
		},
		["Huntsman's Bands of Power"] = {
			["mr"] = 7013,
			["H3219"] = 7013,
		},
		["Scouting Tunic of the Monkey"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Superior Gloves of Defense"] = {
			["mr"] = 1899,
			["H3219"] = 1899,
		},
		["Chromite Bracers"] = {
			["mr"] = 29995,
			["H3219"] = 29995,
		},
		["Flanged Mace"] = {
			["mr"] = 85,
			["H3219"] = 85,
		},
		["Sage's Boots of the Falcon"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Ridge Cleaver of Stamina"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Azure Silk Belt"] = {
			["mr"] = 9099,
			["H3219"] = 9099,
		},
		["Bristlebark Blouse"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Frostbit Staff"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Staunch Hammer of Shadow Wrath"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Hacking Cleaver of Power"] = {
			["mr"] = 8499,
			["H3219"] = 8499,
		},
		["Battle Slayer of the Wolf"] = {
			["mr"] = 3300,
			["H3219"] = 3300,
		},
		["Battleforge Girdle of the Bear"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Knight's Pauldrons of the Gorilla"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Bristle Whisker Catfish"] = {
			["mr"] = 9,
			["H3219"] = 9,
		},
		["Razor Blade of the Monkey"] = {
			["mr"] = 29999,
			["H3219"] = 29999,
		},
		["Linen Bag"] = {
			["mr"] = 239,
			["H3219"] = 239,
		},
		["Steel Bar"] = {
			["mr"] = 1590,
			["H3219"] = 1590,
		},
		["Ritual Tunic of Intellect"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Cadet Shield of the Bear"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Training Sword of Strength"] = {
			["mr"] = 2050,
			["H3219"] = 2050,
		},
		["Schematic: Minor Recombobulator"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Aboriginal Gloves of the Whale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Gypsy Trousers of the Eagle"] = {
			["mr"] = 498,
			["H3219"] = 498,
		},
		["Infiltrator Boots of the Gorilla"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Lead Band of the Whale"] = {
			["mr"] = 4200,
			["H3219"] = 4200,
		},
		["Lesser Wizard's Robe"] = {
			["mr"] = 2199,
			["H3219"] = 2199,
		},
		["Ivycloth Gloves of the Falcon"] = {
			["mr"] = 1298,
			["H3219"] = 1298,
		},
		["Green Silken Shoulders"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Superior Shoulders of Nature's Wrath"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Shimmering Gloves of Fiery Wrath"] = {
			["mr"] = 2845,
			["cc"] = 4,
			["id"] = "6565:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 2845,
		},
		["Huntsman's Belt of the Owl"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Pattern: Brightcloth Cloak"] = {
			["mr"] = 13599,
			["H3219"] = 13599,
		},
		["Mail Combat Gauntlets"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Rigid Gloves of the Eagle"] = {
			["mr"] = 1419,
			["H3219"] = 1419,
		},
		["Scaled Shield of Intellect"] = {
			["mr"] = 16777,
			["H3219"] = 16777,
		},
		["Giant Egg"] = {
			["mr"] = 2800,
			["cc"] = 7,
			["id"] = "12207:0:0:0:0",
			["H3222"] = 2900,
			["sc"] = 0,
			["H3224"] = 2800,
		},
		["Battleforge Shield of the Bear"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Coral Band of Stamina"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Infiltrator Buckler of the Monkey"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Formula: Enchant Bracer - Lesser Spirit"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Soldier's Shield of the Bear"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Blue Sapphire"] = {
			["mr"] = 17800,
			["H3219"] = 17800,
		},
		["Schematic: Spellpower Goggles Xtreme Plus"] = {
			["mr"] = 49999,
			["H3219"] = 49999,
		},
		["War Knife of Healing"] = {
			["mr"] = 1699,
			["H3219"] = 1699,
		},
		["Medium Hide"] = {
			["mr"] = 500,
			["sc"] = 0,
			["id"] = "4232:0:0:0:0",
			["H3219"] = 500,
			["cc"] = 7,
		},
		["Disciple's Stein of the Wolf"] = {
			["mr"] = 599,
			["H3219"] = 599,
		},
		["Cadet Leggings of the Monkey"] = {
			["mr"] = 489,
			["H3219"] = 489,
		},
		["Barbarian War Axe of Stamina"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Bard's Bracers of Spirit"] = {
			["mr"] = 2255,
			["H3219"] = 2255,
		},
		["Merc Sword of the Monkey"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Boar Ribs"] = {
			["mr"] = 147,
			["H3219"] = 147,
		},
		["Viking Warhammer"] = {
			["mr"] = 300000,
			["H3219"] = 300000,
		},
		["Melon Juice"] = {
			["mr"] = 56,
			["H3219"] = 56,
		},
		["Durable Boots of Spirit"] = {
			["mr"] = 10600,
			["H3219"] = 10600,
		},
		["Demon Band"] = {
			["mr"] = 7916,
			["H3219"] = 7916,
		},
		["Nightsky Cloak"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Coarse Grinding Stone"] = {
			["mr"] = 890,
			["H3219"] = 890,
		},
		["Disciple's Robe of Spirit"] = {
			["mr"] = 725,
			["H3219"] = 725,
		},
		["Jazeraint Cloak of the Bear"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Razor Blade of the Tiger"] = {
			["mr"] = 99999,
			["H3219"] = 99999,
		},
		["Huntsman's Boots of the Owl"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Aboriginal Vest of Intellect"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Aurora Bracers"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Deadly Kris of Nature's Wrath"] = {
			["mr"] = 14000,
			["H3219"] = 14000,
		},
		["Banded Shield of the Tiger"] = {
			["mr"] = 6800,
			["H3219"] = 6800,
		},
		["Knight's Crest of Stamina"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Bandit Gloves of the Monkey"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Soldier's Shield of the Gorilla"] = {
			["mr"] = 920,
			["H3219"] = 920,
		},
		["Clamlette Surprise"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Blackforge Bracers"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Murloc Scale Breastplate"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Shimmering Boots of Arcane Wrath"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Durable Pants of Healing"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Green Leather Bag"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Pattern: Tough Scorpid Boots"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Willow Pants of Healing"] = {
			["mr"] = 950,
			["H3219"] = 950,
		},
		["Forest Leather Bracers"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Small Leather Ammo Pouch"] = {
			["mr"] = 39,
			["H3219"] = 39,
		},
		["Pattern: Felcloth Pants"] = {
			["mr"] = 80000,
			["cc"] = 9,
			["id"] = "14483:0:0:0:0",
			["sc"] = 2,
			["H3226"] = 80000,
		},
		["Ritual Sandals of the Whale"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Plans: Golden Scale Coif"] = {
			["mr"] = 12496,
			["H3219"] = 12496,
		},
		["Recipe: Shadow Oil"] = {
			["mr"] = 22000,
			["H3219"] = 22000,
		},
		["Battle Slayer of the Eagle"] = {
			["mr"] = 2871,
			["H3219"] = 2871,
		},
		["Marsh Ring of Eluding"] = {
			["mr"] = 45099,
			["H3219"] = 45099,
		},
		["Dervish Tunic of the Falcon"] = {
			["mr"] = 6200,
			["H3219"] = 6200,
		},
		["Dream Dust"] = {
			["mr"] = 1835,
			["sc"] = 0,
			["id"] = "11176:0:0:0:0",
			["cc"] = 7,
			["H3220"] = 1835,
		},
		["Grunt's Legguards of Power"] = {
			["mr"] = 17688,
			["H3219"] = 17688,
		},
		["Ritual Gloves of Healing"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Willow Vest of the Eagle"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Elder's Gloves of Spirit"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Light Hide"] = {
			["mr"] = 72,
			["H3219"] = 72,
		},
		["Rune of Teleportation"] = {
			["mr"] = 1649,
			["H3219"] = 1649,
		},
		["Schematic: Dark Iron Bomb"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Archer's Gloves of Spirit"] = {
			["mr"] = 18999,
			["H3219"] = 18999,
		},
		["Murphstar of Shadow Wrath"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Cadet Leggings of the Tiger"] = {
			["mr"] = 1645,
			["H3219"] = 1645,
		},
		["Massive Battle Axe of the Eagle"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Pattern: Deviate Scale Gloves"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Durable Belt of the Whale"] = {
			["mr"] = 2592,
			["H3219"] = 2592,
		},
		["Riverside Staff"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Shimmering Sash of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Accurate Scope"] = {
			["mr"] = 14000,
			["H3219"] = 14000,
		},
		["Tundra Ring of the Monkey"] = {
			["mr"] = 18500,
			["H3219"] = 18500,
		},
		["Ruined Leather Scraps"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["Chief Brigadier Armor"] = {
			["mr"] = 12675,
			["H3219"] = 12675,
		},
		["Bandit Buckler of Stamina"] = {
			["mr"] = 8998,
			["H3219"] = 8998,
		},
		["Stormwind Brie"] = {
			["mr"] = 82,
			["H3219"] = 82,
		},
		["Rough Copper Bomb"] = {
			["mr"] = 62,
			["H3219"] = 62,
		},
		["Sage's Boots of the Owl"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Sentinel Shoulders of Agility"] = {
			["mr"] = 13900,
			["H3219"] = 13900,
		},
		["Burnt Leather Breeches"] = {
			["mr"] = 198,
			["H3219"] = 198,
		},
		["Gypsy Tunic of the Owl"] = {
			["mr"] = 794,
			["H3219"] = 794,
		},
		["Viking Sword of Strength"] = {
			["mr"] = 10538,
			["H3219"] = 10538,
		},
		["Lesser Magic Wand"] = {
			["mr"] = 683,
			["H3219"] = 683,
		},
		["Bandit Pants of the Monkey"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Mageweave Bag"] = {
			["mr"] = 11400,
			["H3219"] = 11400,
		},
		["Sentinel Bracers of Intellect"] = {
			["mr"] = 9022,
			["H3219"] = 9022,
		},
		["Twin-bladed Axe of the Wolf"] = {
			["mr"] = 1699,
			["H3219"] = 1699,
		},
		["Brutish Riverpaw Axe"] = {
			["mr"] = 1024,
			["H3219"] = 1024,
		},
		["Willow Boots of the Eagle"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Glowing Magical Bracelets"] = {
			["mr"] = 10400,
			["H3219"] = 10400,
		},
		["Silver-lined Belt"] = {
			["mr"] = 3333,
			["H3219"] = 3333,
		},
		["Cooked Glossy Mightfish"] = {
			["mr"] = 550,
			["sc"] = 0,
			["id"] = "13927:0:0:0:0",
			["H3225"] = 550,
			["cc"] = 0,
		},
		["Defender Gauntlets of the Eagle"] = {
			["mr"] = 7594,
			["H3219"] = 7594,
		},
		["Feral Shoes of the Falcon"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Battle Slayer of the Bear"] = {
			["mr"] = 6786,
			["H3219"] = 6786,
		},
		["Renegade Bracers of the Tiger"] = {
			["mr"] = 5400,
			["H3219"] = 5400,
		},
		["Tigerseye"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Curved Dagger of Holy Wrath"] = {
			["mr"] = 1109,
			["H3219"] = 1109,
		},
		["Duskwoven Cape of Arcane Wrath"] = {
			["mr"] = 49900,
			["H3219"] = 49900,
		},
		["Pagan Bands of the Whale"] = {
			["mr"] = 753,
			["H3219"] = 753,
		},
		["Crawler Claw"] = {
			["mr"] = 84,
			["H3219"] = 84,
		},
		["Medicine Staff of the Owl"] = {
			["mr"] = 3058,
			["H3219"] = 3058,
		},
		["Bandit Boots of the Wolf"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Skeletal Shoulders"] = {
			["mr"] = 24898,
			["H3219"] = 24898,
		},
		["Phalanx Gauntlets of the Boar"] = {
			["mr"] = 6499,
			["H3219"] = 6499,
		},
		["Shimmering Stave of the Falcon"] = {
			["mr"] = 2099,
			["H3219"] = 2099,
		},
		["Infiltrator Cloak of Defense"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Pattern: Pilferer's Gloves"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Azure Silk Pants"] = {
			["mr"] = 1599,
			["H3219"] = 1599,
		},
		["Pioneer Trousers of Power"] = {
			["mr"] = 477,
			["H3219"] = 477,
		},
		["Giant Club of Power"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Recipe: Succulent Pork Ribs"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Whipwood Recurve Bow"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Headhunter's Belt of Arcane Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Headstriker Sword of the Whale"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Buccaneer's Robes of Intellect"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Archer's Buckler of the Gorilla"] = {
			["mr"] = 12305,
			["H3219"] = 12305,
		},
		["Willow Vest of Stamina"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Battleforge Gauntlets of the Monkey"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Cutthroat's Armguards of the Whale"] = {
			["mr"] = 4300,
			["H3219"] = 4300,
		},
		["Regal Cloak of the Whale"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Battleforge Gauntlets of Power"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Acrobatic Staff of the Boar"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Bard's Buckler of the Monkey"] = {
			["mr"] = 1238,
			["H3219"] = 1238,
		},
		["Mithril Blunderbuss"] = {
			["mr"] = 52673,
			["H3219"] = 52673,
		},
		["Heavy Wool Bandage"] = {
			["mr"] = 57,
			["sc"] = 0,
			["id"] = "3531:0:0:0:0",
			["H3224"] = 57,
			["cc"] = 0,
		},
		["Belt of Valor"] = {
			["H3224"] = 489998,
			["cc"] = 4,
			["id"] = "16736:0:0:0:0",
			["sc"] = 4,
			["mr"] = 489998,
		},
		["Archer's Buckler of the Bear"] = {
			["mr"] = 6800,
			["H3219"] = 6800,
		},
		["Disciple's Vest of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Bloodwoven Mask of Fiery Wrath"] = {
			["mr"] = 30486,
			["cc"] = 4,
			["id"] = "14263:0:0:1894:0",
			["sc"] = 1,
			["H3220"] = 30486,
		},
		["Stone Gnoll Hammer"] = {
			["mr"] = 220,
			["H3219"] = 220,
		},
		["Rigid Bracelets of the Owl"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Short Bastard Sword of Stamina"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Soul Dust"] = {
			["mr"] = 145,
			["cc"] = 7,
			["id"] = "11083:0:0:0:0",
			["H3219"] = 145,
			["sc"] = 0,
		},
		["Forest Pendant of Eluding"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Twilight Pants of Healing"] = {
			["mr"] = 11405,
			["H3219"] = 11405,
		},
		["Cobalt Crusher"] = {
			["mr"] = 77777,
			["H3219"] = 77777,
		},
		["Raider's Boots of the Gorilla"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Righteous Helmet of the Monkey"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Cadet Vest of the Bear"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Dreamer's Belt"] = {
			["mr"] = 7499,
			["H3219"] = 7499,
		},
		["Willow Cape of Stamina"] = {
			["mr"] = 760,
			["H3219"] = 760,
		},
		["Aboriginal Loincloth of the Eagle"] = {
			["mr"] = 1324,
			["H3219"] = 1324,
		},
		["Scaled Leather Headband of the Owl"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Renegade Pauldrons of the Bear"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Gypsy Buckler of Agility"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Banded Leggings of Strength"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Twilight Cowl of Fiery Wrath"] = {
			["mr"] = 10000,
			["cc"] = 4,
			["id"] = "7432:0:0:1889:0",
			["sc"] = 1,
			["H3220"] = 10000,
		},
		["Moonberry Juice"] = {
			["mr"] = 1855,
			["H3219"] = 1855,
		},
		["Iron Bar"] = {
			["mr"] = 500,
			["sc"] = 0,
			["id"] = "3575:0:0:0:0",
			["H3219"] = 500,
			["cc"] = 7,
		},
		["Green Hills of Stranglethorn - Page 11"] = {
			["mr"] = 560,
			["H3219"] = 560,
		},
		["Durable Bracers of Stamina"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Willow Cape of Intellect"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Silk Bandage"] = {
			["mr"] = 400,
			["sc"] = 0,
			["id"] = "6450:0:0:0:0",
			["H3219"] = 400,
			["cc"] = 0,
		},
		["Viking Sword of Stamina"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Conjurer's Hood of Frozen Wrath"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Veteran Gloves"] = {
			["mr"] = 594,
			["H3219"] = 594,
		},
		["Green Hills of Stranglethorn - Page 21"] = {
			["mr"] = 579,
			["cc"] = 15,
			["id"] = "2745:0:0:0:0",
			["H3219"] = 579,
			["sc"] = 0,
		},
		["Slimy Murloc Scale"] = {
			["mr"] = 95,
			["H3219"] = 95,
		},
		["Rethban Ore"] = {
			["mr"] = 329,
			["H3219"] = 329,
		},
		["Battle Slayer of Stamina"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Greater Scythe of the Eagle"] = {
			["mr"] = 18099,
			["H3219"] = 18099,
		},
		["Crimson Silk Vest"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Cresting Charm"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Severing Axe of Power"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Willow Branch of Intellect"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Lesser Mystic Wand"] = {
			["mr"] = 5500,
			["sc"] = 19,
			["id"] = "11289:0:0:0:0",
			["H3219"] = 5500,
			["cc"] = 2,
		},
		["Thallium Hoop of the Eagle"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Patterned Bronze Bracers"] = {
			["mr"] = 1900,
			["sc"] = 3,
			["id"] = "2868:0:0:0:0",
			["H3219"] = 1900,
			["cc"] = 4,
		},
		["Soldier's Girdle of the Bear"] = {
			["mr"] = 1998,
			["H3219"] = 1998,
		},
		["Spellbinder Robe"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Small Flame Sac"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Upper Map Fragment"] = {
			["mr"] = 6300,
			["sc"] = 0,
			["id"] = "9251:0:0:0:0",
			["H3219"] = 6300,
			["cc"] = 12,
		},
		["Felcloth Bag"] = {
			["mr"] = 949000,
			["cc"] = 1,
			["id"] = "21341:0:0:0:0",
			["sc"] = 1,
			["H3226"] = 949000,
		},
		["Schematic: Powerful Seaforium Charge"] = {
			["mr"] = 22000,
			["sc"] = 3,
			["id"] = "18656:0:0:0:0",
			["H3224"] = 22000,
			["cc"] = 9,
		},
		["Sentry's Surcoat of Power"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Carnelian Loop of Fire Resistance"] = {
			["mr"] = 49999,
			["cc"] = 4,
			["id"] = "11972:0:0:1411:0",
			["H3224"] = 49999,
			["sc"] = 0,
		},
		["Beaded Britches of Fiery Wrath"] = {
			["mr"] = 2099,
			["cc"] = 4,
			["id"] = "14090:0:0:1876:0",
			["sc"] = 1,
			["H3220"] = 2099,
		},
		["Jade Serpentblade"] = {
			["mr"] = 21000,
			["H3219"] = 21000,
		},
		["Elixir of Greater Agility"] = {
			["H3223"] = 1495,
			["mr"] = 1495,
			["cc"] = 0,
			["id"] = "9187:0:0:0:0",
			["sc"] = 0,
		},
		["Plans: Mithril Spurs"] = {
			["mr"] = 80000,
			["H3219"] = 80000,
		},
		["Battle Knife of Agility"] = {
			["mr"] = 5400,
			["H3219"] = 5400,
		},
		["Buccaneer's Cape of Shadow Wrath"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Ivycloth Cloak of Fiery Wrath"] = {
			["mr"] = 3000,
			["cc"] = 4,
			["id"] = "9794:0:0:1879:0",
			["sc"] = 1,
			["H3220"] = 3000,
		},
		["Durable Robe of Frozen Wrath"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Carving Knife of Healing"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Recipe: Invisibility Potion"] = {
			["mr"] = 42500,
			["H3219"] = 42500,
		},
		["Defender Bracers of the Bear"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Monk's Staff of Arcane Wrath"] = {
			["mr"] = 24000,
			["H3219"] = 24000,
		},
		["Heavy Leather"] = {
			["mr"] = 177,
			["sc"] = 0,
			["id"] = "4234:0:0:0:0",
			["H3219"] = 177,
			["cc"] = 7,
		},
		["Long Redwood Bow"] = {
			["mr"] = 12500,
			["sc"] = 2,
			["id"] = "15286:0:0:0:0",
			["H3219"] = 12500,
			["cc"] = 2,
		},
		["Enchanted Sea Kelp"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Cavalier Two-hander of the Whale"] = {
			["mr"] = 6144,
			["H3219"] = 6144,
		},
		["Sickle Axe"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Bloodscalp Channeling Staff"] = {
			["mr"] = 11212,
			["H3219"] = 11212,
		},
		["Viking Sword of the Bear"] = {
			["mr"] = 6800,
			["H3219"] = 6800,
		},
		["Plans: Mighty Iron Hammer"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Royal Sash of Fiery Wrath"] = {
			["mr"] = 40000,
			["cc"] = 4,
			["id"] = "9906:0:0:1888:0",
			["sc"] = 1,
			["H3220"] = 40000,
		},
		["Elder's Cloak of the Eagle"] = {
			["mr"] = 4777,
			["H3219"] = 4777,
		},
		["Willow Gloves of the Falcon"] = {
			["mr"] = 1802,
			["H3219"] = 1802,
		},
		["Schematic: Bright-Eye Goggles"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Battleforge Cloak of Strength"] = {
			["mr"] = 5899,
			["H3219"] = 5899,
		},
		["Geomancer's Cloak of the Owl"] = {
			["mr"] = 10100,
			["H3219"] = 10100,
		},
		["Jungle Remedy"] = {
			["mr"] = 820,
			["H3219"] = 820,
		},
		["Light Feather"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Staunch Hammer of Nature's Wrath"] = {
			["mr"] = 690,
			["H3219"] = 690,
		},
		["Buccaneer's Bracers of Stamina"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Scroll of Strength"] = {
			["mr"] = 71,
			["H3219"] = 71,
		},
		["Shimmering Boots of the Whale"] = {
			["mr"] = 1546,
			["H3219"] = 1546,
		},
		["Raider's Belt of the Gorilla"] = {
			["mr"] = 3054,
			["H3219"] = 3054,
		},
		["Bandit Buckler of the Boar"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Feral Shoes of Stamina"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Raider's Gauntlets of Strength"] = {
			["mr"] = 1495,
			["H3219"] = 1495,
		},
		["Shimmering Stave of the Owl"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Liferoot"] = {
			["mr"] = 295,
			["sc"] = 0,
			["id"] = "3357:0:0:0:0",
			["H3219"] = 295,
			["cc"] = 7,
		},
		["Medicine Staff of Stamina"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Crawler Meat"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Deeprock Salt"] = {
			["mr"] = 496,
			["sc"] = 0,
			["id"] = "8150:0:0:0:0",
			["H3224"] = 496,
			["cc"] = 7,
		},
		["Windchaser Woolies"] = {
			["mr"] = 14999,
			["cc"] = 4,
			["id"] = "14433:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 14999,
		},
		["Truesilver Rod"] = {
			["mr"] = 11500,
			["sc"] = 0,
			["id"] = "11144:0:0:0:0",
			["H3219"] = 11500,
			["cc"] = 7,
		},
		["Stonesplinter Axe"] = {
			["mr"] = 634,
			["H3219"] = 634,
		},
		["Bandit Boots of the Monkey"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Pattern: Green Woolen Bag"] = {
			["mr"] = 870,
			["cc"] = 9,
			["id"] = "4292:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 870,
		},
		["Bandit Boots of Stamina"] = {
			["mr"] = 1188,
			["H3219"] = 1188,
		},
		["Recipe: Elixir of Superior Defense"] = {
			["H3223"] = 19890,
			["mr"] = 19890,
			["cc"] = 9,
			["id"] = "13478:0:0:0:0",
			["sc"] = 6,
		},
		["Giant Club of Strength"] = {
			["mr"] = 14499,
			["H3219"] = 14499,
		},
		["Twilight Pants of the Whale"] = {
			["mr"] = 13300,
			["H3219"] = 13300,
		},
		["Seer's Gloves"] = {
			["mr"] = 325,
			["H3219"] = 325,
		},
		["Battering Hammer of Spirit"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Dokebi Leggings"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Scorpashi Slippers"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Hunting Bracers"] = {
			["mr"] = 117,
			["H3219"] = 117,
		},
		["Simple Branch of the Owl"] = {
			["mr"] = 980,
			["H3219"] = 980,
		},
		["Shimmering Robe of Arcane Wrath"] = {
			["mr"] = 5305,
			["H3219"] = 5305,
		},
		["Superior Buckler of Defense"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Militant Shortsword of the Bear"] = {
			["mr"] = 4820,
			["H3219"] = 4820,
		},
		["Large Glowing Shard"] = {
			["mr"] = 1900,
			["sc"] = 0,
			["id"] = "11139:0:0:0:0",
			["H3219"] = 1900,
			["cc"] = 7,
		},
		["Schematic: Mechanical Squirrel"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Schematic: Ice Deflector"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Superior Shoulders of the Falcon"] = {
			["mr"] = 15060,
			["H3219"] = 15060,
		},
		["Dokebi Cord"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Golden Skeleton Key"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Stylish Red Shirt"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Large Glimmering Shard"] = {
			["mr"] = 695,
			["sc"] = 0,
			["id"] = "11084:0:0:0:0",
			["H3219"] = 695,
			["cc"] = 7,
		},
		["Ranger Cloak of the Monkey"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Edged Bastard Sword of the Wolf"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Serpentine Loop of Fire Resistance"] = {
			["mr"] = 650000,
			["sc"] = 0,
			["id"] = "11977:0:0:1416:0",
			["H3224"] = 650000,
			["cc"] = 4,
		},
		["Simple Branch of Intellect"] = {
			["mr"] = 868,
			["H3219"] = 868,
		},
		["Willow Bracers of the Whale"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Ballast Maul of the Bear"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Shimmering Cloak of Arcane Wrath"] = {
			["mr"] = 768,
			["H3219"] = 768,
		},
		["Simple Britches of Healing"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Superior Buckler of the Monkey"] = {
			["mr"] = 4849,
			["H3219"] = 4849,
		},
		["Rageclaw Gloves of the Eagle"] = {
			["mr"] = 18105,
			["cc"] = 4,
			["id"] = "15383:0:0:864:0",
			["H3224"] = 18105,
			["sc"] = 2,
		},
		["Elemental Earth"] = {
			["mr"] = 1230,
			["H3219"] = 1230,
		},
		["Insignia Cap"] = {
			["mr"] = 6200,
			["H3219"] = 6200,
		},
		["Conjurer's Cloak of the Eagle"] = {
			["mr"] = 6099,
			["H3219"] = 6099,
		},
		["Red-speckled Mushroom"] = {
			["mr"] = 17,
			["H3219"] = 17,
		},
		["Sentinel Gloves of the Monkey"] = {
			["mr"] = 6999,
			["H3219"] = 6999,
		},
		["Buccaneer's Bracers of Frozen Wrath"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Outrunner's Cloak of Defense"] = {
			["mr"] = 1226,
			["H3219"] = 1226,
		},
		["12 Pound Mud Snapper"] = {
			["mr"] = 390,
			["H3219"] = 390,
		},
		["Bandit Bracers of Stamina"] = {
			["mr"] = 1428,
			["H3219"] = 1428,
		},
		["Aboriginal Rod of the Eagle"] = {
			["mr"] = 6320,
			["H3219"] = 6320,
		},
		["Scroll of Intellect III"] = {
			["mr"] = 645,
			["H3219"] = 645,
		},
		["Renegade Gauntlets of the Bear"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Linen Belt"] = {
			["mr"] = 30,
			["H3219"] = 30,
		},
		["Massive Battle Axe of the Bear"] = {
			["mr"] = 3462,
			["H3219"] = 3462,
		},
		["Barbarian War Axe of the Boar"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Phalanx Cloak of the Boar"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Twilight Belt of the Eagle"] = {
			["mr"] = 11500,
			["H3219"] = 11500,
		},
		["Raw Brilliant Smallfish"] = {
			["mr"] = 2,
			["H3219"] = 2,
		},
		["Knight's Breastplate of Power"] = {
			["mr"] = 11900,
			["H3219"] = 11900,
		},
		["Steel Breastplate"] = {
			["mr"] = 13099,
			["H3219"] = 13099,
		},
		["Prospector's Woolies"] = {
			["mr"] = 1225,
			["cc"] = 4,
			["id"] = "14565:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 1225,
		},
		["Amber Hoop of Fire Resistance"] = {
			["mr"] = 1463,
			["cc"] = 4,
			["id"] = "11968:0:0:1404:0",
			["H3224"] = 1463,
			["sc"] = 0,
		},
		["Firefin Snapper"] = {
			["mr"] = 53,
			["H3219"] = 53,
		},
		["Earthen Leather Shoulders"] = {
			["mr"] = 8013,
			["H3219"] = 8013,
		},
		["Illusion Dust"] = {
			["H3223"] = 4875,
			["mr"] = 11385,
			["sc"] = 0,
			["id"] = "16204:0:0:0:0",
			["H3224"] = 11385,
			["cc"] = 7,
		},
		["Black Duskwood Staff"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Primal Leggings of the Whale"] = {
			["mr"] = 821,
			["H3219"] = 821,
		},
		["Durable Cape of Arcane Wrath"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Plans: Iron Shield Spike"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Spinel Ring of Frost Resistance"] = {
			["mr"] = 2438,
			["H3219"] = 2438,
		},
		["Barbaric Battle Axe of the Whale"] = {
			["mr"] = 2058,
			["H3219"] = 2058,
		},
		["Banded Gauntlets of the Boar"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Knightly Longsword of the Bear"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Durable Cape of Stamina"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Staunch Hammer of Strength"] = {
			["mr"] = 780,
			["H3219"] = 780,
		},
		["Small Lustrous Pearl"] = {
			["mr"] = 200,
			["cc"] = 7,
			["id"] = "5498:0:0:0:0",
			["H3219"] = 200,
			["sc"] = 0,
		},
		["Driftwood Club"] = {
			["mr"] = 925,
			["H3219"] = 925,
		},
		["Formula: Enchant Chest - Major Health"] = {
			["mr"] = 31200,
			["H3219"] = 31200,
		},
		["Shimmering Bracers of Intellect"] = {
			["mr"] = 1542,
			["H3219"] = 1542,
		},
		["Archer's Belt of the Owl"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Hematite Link of Arcane Resistance"] = {
			["mr"] = 9990,
			["H3219"] = 9990,
		},
		["Conjurer's Mantle of the Owl"] = {
			["mr"] = 3710,
			["H3219"] = 3710,
		},
		["Renegade Gauntlets of the Whale"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Disciple's Pants of the Owl"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Infiltrator Shoulders of Agility"] = {
			["mr"] = 17200,
			["H3219"] = 17200,
		},
		["Dervish Leggings of Spirit"] = {
			["mr"] = 5927,
			["H3219"] = 5927,
		},
		["Carving Knife of Strength"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Phalanx Girdle of the Bear"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Raw Bristle Whisker Catfish"] = {
			["mr"] = 5,
			["H3219"] = 5,
		},
		["Huntsman's Cap of the Owl"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Cavalier Two-hander of the Monkey"] = {
			["mr"] = 13403,
			["H3219"] = 13403,
		},
		["Superior Buckler of the Gorilla"] = {
			["mr"] = 7100,
			["H3219"] = 7100,
		},
		["Thistlefur Bands of the Owl"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Gleaming Claymore of the Whale"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Reinforced Chain Shoulderpads"] = {
			["mr"] = 1690,
			["H3219"] = 1690,
		},
		["Bandit Boots of Agility"] = {
			["mr"] = 3850,
			["H3219"] = 3850,
		},
		["Chunk of Boar Meat"] = {
			["mr"] = 43,
			["H3219"] = 43,
		},
		["Deadly Blunderbuss"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Phoenix Gloves"] = {
			["mr"] = 9899,
			["H3219"] = 9899,
		},
		["Hollowfang Blade"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Stone Hammer of the Gorilla"] = {
			["mr"] = 19800,
			["H3219"] = 19800,
		},
		["Gypsy Tunic of the Wolf"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Mining Pick"] = {
			["mr"] = 765,
			["H3219"] = 765,
		},
		["Glyphed Breastplate"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Battle Slayer of the Whale"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Archer's Cloak of Intellect"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Brutal War Axe of Strength"] = {
			["mr"] = 12200,
			["H3219"] = 12200,
		},
		["Aquamarine Ring of Nature Resistance"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Raw Slitherskin Mackerel"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Bandit Gloves of the Tiger"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Dervish Cape of Spirit"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Arclight Spanner"] = {
			["mr"] = 150,
			["H3219"] = 150,
		},
		["Infiltrator Armor of the Whale"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Gouging Pick"] = {
			["mr"] = 1526,
			["H3219"] = 1526,
		},
		["Merc Sword of the Boar"] = {
			["mr"] = 1891,
			["H3219"] = 1891,
		},
		["Renegade Circlet of the Boar"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Archer's Boots of the Owl"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Battleforge Shield of Strength"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Black Mageweave Headband"] = {
			["mr"] = 7800,
			["H3219"] = 7800,
		},
		["Dreamfoil"] = {
			["H3224"] = 1850,
			["cc"] = 7,
			["id"] = "13463:0:0:0:0",
			["sc"] = 0,
			["mr"] = 1850,
		},
		["Tough Leather Pants"] = {
			["mr"] = 1764,
			["H3219"] = 1764,
		},
		["Bloodwoven Bracers of the Owl"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Magician Staff of the Whale"] = {
			["mr"] = 11350,
			["H3219"] = 11350,
		},
		["Archer's Boots of Agility"] = {
			["mr"] = 12400,
			["H3219"] = 12400,
		},
		["Blasted Boar Lung"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Scouting Belt of the Wolf"] = {
			["mr"] = 2223,
			["H3219"] = 2223,
		},
		["Superior Shoulders of the Boar"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Black Pearl Ring"] = {
			["mr"] = 15000,
			["cc"] = 4,
			["id"] = "6332:0:0:0:0",
			["H3213"] = 15000,
			["sc"] = 0,
		},
		["Ghost Mushroom"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Shimmering Trousers of the Monkey"] = {
			["mr"] = 1357,
			["H3219"] = 1357,
		},
		["Archer's Boots of Power"] = {
			["mr"] = 7499,
			["H3219"] = 7499,
		},
		["Handful of Copper Bolts"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Opulent Crown of Fiery Wrath"] = {
			["mr"] = 46866,
			["cc"] = 4,
			["id"] = "14281:0:0:1897:0",
			["sc"] = 1,
			["H3220"] = 46866,
		},
		["Inscribed Leather Bracers"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Libram of Rumination"] = {
			["mr"] = 593600,
			["H3219"] = 593600,
		},
		["Schematic: EZ-Thro Dynamite II"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Wolffear Harness"] = {
			["mr"] = 44800,
			["H3219"] = 44800,
		},
		["Superior Gloves of the Whale"] = {
			["mr"] = 2385,
			["H3219"] = 2385,
		},
		["Gossamer Belt of the Owl"] = {
			["mr"] = 10101,
			["H3219"] = 10101,
		},
		["Rod of Molten Fire"] = {
			["mr"] = 23220,
			["H3219"] = 23220,
		},
		["Glimmering Mail Breastplate"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Greenweave Sandals of Stamina"] = {
			["mr"] = 2918,
			["H3219"] = 2918,
		},
		["Hacking Cleaver of the Eagle"] = {
			["mr"] = 10800,
			["H3219"] = 10800,
		},
		["Shimmering Trousers of the Owl"] = {
			["mr"] = 3099,
			["H3219"] = 3099,
		},
		["Devout Gloves"] = {
			["H3224"] = 136500,
			["cc"] = 4,
			["id"] = "16692:0:0:0:0",
			["sc"] = 1,
			["mr"] = 136500,
		},
		["Stout Battlehammer of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Hefty Battlehammer of the Monkey"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Willow Belt of the Whale"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Soldier's Shield of the Tiger"] = {
			["mr"] = 949,
			["H3219"] = 949,
		},
		["Sage's Robe of the Owl"] = {
			["mr"] = 9900,
			["sc"] = 1,
			["id"] = "6610:0:0:775:0",
			["H3219"] = 9900,
			["cc"] = 4,
		},
		["Redridge Machete"] = {
			["mr"] = 1929,
			["H3219"] = 1929,
		},
		["Sage's Pants of the Eagle"] = {
			["mr"] = 6400,
			["sc"] = 1,
			["id"] = "6616:0:0:859:0",
			["H3213"] = 7800,
			["L3213"] = 6400,
			["cc"] = 4,
		},
		["Winterfall Firewater"] = {
			["mr"] = 6666,
			["H3219"] = 6666,
		},
		["Battleforge Shield of the Monkey"] = {
			["mr"] = 5302,
			["H3219"] = 5302,
		},
		["Gazlowe's Charm"] = {
			["mr"] = 49900,
			["H3219"] = 49900,
		},
		["Willow Vest of Arcane Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Amethyst Band of Frost Resistance"] = {
			["mr"] = 11500,
			["H3219"] = 11500,
		},
		["Formula: Enchant Gloves - Mining"] = {
			["mr"] = 989,
			["H3219"] = 989,
		},
		["Glimmering Flamberge of the Whale"] = {
			["mr"] = 9400,
			["H3219"] = 9400,
		},
		["Scouting Cloak of the Monkey"] = {
			["mr"] = 2766,
			["H3219"] = 2766,
		},
		["Phalanx Boots of the Whale"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Shimmering Robe of the Eagle"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Fortified Cloak of Stamina"] = {
			["mr"] = 3461,
			["H3219"] = 3461,
		},
		["Defender Leggings of the Whale"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Ancient Crown of the Owl"] = {
			["mr"] = 12400,
			["H3219"] = 12400,
		},
		["Rageclaw Belt of the Eagle"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Harpyclaw Short Bow"] = {
			["mr"] = 35000,
			["H3219"] = 35000,
		},
		["Archer's Shoulderpads of the Whale"] = {
			["mr"] = 7992,
			["H3219"] = 7992,
		},
		["Major Mana Potion"] = {
			["L3226"] = 15600,
			["mr"] = 15600,
			["cc"] = 0,
			["H3226"] = 17798,
			["sc"] = 0,
			["id"] = "13444:0:0:0:0",
		},
		["Shimmering Trousers of Fiery Wrath"] = {
			["mr"] = 2060,
			["H3219"] = 2060,
		},
		["Formula: Enchant Cloak - Lesser Shadow Resistance"] = {
			["mr"] = 1020,
			["H3219"] = 1020,
		},
		["Buccaneer's Bracers of the Owl"] = {
			["mr"] = 1969,
			["H3219"] = 1969,
		},
		["Scouting Boots of the Owl"] = {
			["mr"] = 1730,
			["H3219"] = 1730,
		},
		["Ridge Cleaver of Agility"] = {
			["mr"] = 4995,
			["H3219"] = 4995,
		},
		["Scaled Cloak of Defense"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Bloodspattered Loincloth of the Whale"] = {
			["mr"] = 1079,
			["H3219"] = 1079,
		},
		["Rigid Bracelets of the Whale"] = {
			["mr"] = 2598,
			["H3219"] = 2598,
		},
		["Shadoweave Robe"] = {
			["mr"] = 53095,
			["H3219"] = 53095,
		},
		["Superior Cloak of the Eagle"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Bard's Tunic of Power"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Herb Baked Egg"] = {
			["mr"] = 12,
			["H3219"] = 12,
		},
		["Gypsy Trousers of the Whale"] = {
			["mr"] = 680,
			["H3219"] = 680,
		},
		["Superior Cloak of the Falcon"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Cadet Vest of Power"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Dervish Bracers of the Whale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Glimmering Mail Greaves"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Barbed Club of Strength"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Recipe: Elixir of Poison Resistance"] = {
			["H3223"] = 3599,
			["mr"] = 3599,
			["sc"] = 6,
			["id"] = "3394:0:0:0:0",
			["cc"] = 9,
		},
		["Wildvine Potion"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Green Hills of Stranglethorn - Page 6"] = {
			["mr"] = 800,
			["cc"] = 15,
			["id"] = "2730:0:0:0:0",
			["H3219"] = 800,
			["sc"] = 0,
		},
		["Scouting Gloves of the Bear"] = {
			["mr"] = 3551,
			["H3219"] = 3551,
		},
		["Emblazoned Leggings"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Banded Helm of the Bear"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Dervish Bracers of the Owl"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Ivycloth Gloves of the Eagle"] = {
			["mr"] = 2399,
			["H3219"] = 2399,
		},
		["Lambent Scale Breastplate"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["War Torn Shield of Stamina"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Smoked Sagefish"] = {
			["mr"] = 93,
			["H3219"] = 93,
		},
		["Pearl-handled Dagger"] = {
			["mr"] = 5725,
			["cc"] = 2,
			["id"] = "5540:0:0:0:0",
			["H3219"] = 5725,
			["sc"] = 15,
		},
		["Gypsy Buckler of Strength"] = {
			["mr"] = 541,
			["H3219"] = 541,
		},
		["Elder's Bracers of Fiery Wrath"] = {
			["mr"] = 6368,
			["H3219"] = 6368,
		},
		["Pattern: Swift Boots"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Soldier's Armor of the Boar"] = {
			["mr"] = 1150,
			["H3219"] = 1150,
		},
		["Cavalier Two-hander of Agility"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Dervish Buckler of the Tiger"] = {
			["mr"] = 4950,
			["H3219"] = 4950,
		},
		["Mercenary Blade of the Bear"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Sage's Mantle of the Owl"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Stoneraven"] = {
			["mr"] = 400000,
			["sc"] = 6,
			["id"] = "13059:0:0:0:0",
			["cc"] = 2,
			["H3224"] = 608000,
			["H3225"] = 400000,
		},
		["Elixir of Wisdom"] = {
			["H3223"] = 150,
			["mr"] = 150,
			["sc"] = 0,
			["id"] = "3383:0:0:0:0",
			["cc"] = 0,
		},
		["Bandit Jerkin of the Wolf"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Raider's Belt of the Bear"] = {
			["mr"] = 1085,
			["H3219"] = 1085,
		},
		["Heraldic Headpiece"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Templar Crown of the Bear"] = {
			["mr"] = 50655,
			["H3219"] = 50655,
		},
		["Archer's Bracers of Agility"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Schematic: Gyrofreeze Ice Reflector"] = {
			["mr"] = 39598,
			["sc"] = 3,
			["id"] = "18652:0:0:0:0",
			["H3224"] = 39598,
			["cc"] = 9,
		},
		["Small Red Pouch"] = {
			["mr"] = 283,
			["H3219"] = 283,
		},
		["Birchwood Maul of the Boar"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Defender Leggings of the Boar"] = {
			["mr"] = 1990,
			["H3219"] = 1990,
		},
		["Defender Gauntlets of the Boar"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Ancient Crown of the Bear"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Infiltrator Buckler of Agility"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Truefaith Gloves"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Archer's Cloak of the Monkey"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Infantry Shield of Agility"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Green Hills of Stranglethorn - Page 4"] = {
			["mr"] = 556,
			["sc"] = 0,
			["id"] = "2728:0:0:0:0",
			["H3219"] = 556,
			["cc"] = 15,
		},
		["Staff of the Friar"] = {
			["mr"] = 48750,
			["H3219"] = 48750,
		},
		["Dervish Tunic of the Monkey"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Minor Healing Potion"] = {
			["mr"] = 5,
			["cc"] = 0,
			["id"] = "118:0:0:0:0",
			["H3219"] = 5,
			["sc"] = 0,
		},
		["Forester's Axe of the Tiger"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Pattern: Blue Linen Robe"] = {
			["mr"] = 1610,
			["H3219"] = 1610,
		},
		["Headhunter's Armor of Intellect"] = {
			["mr"] = 12525,
			["H3219"] = 12525,
		},
		["Fortified Gauntlets of the Monkey"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Superior Tunic of the Whale"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Cord of Elements"] = {
			["mr"] = 95000,
			["H3219"] = 95000,
		},
		["Double-barreled Shotgun"] = {
			["mr"] = 19800,
			["H3219"] = 19800,
		},
		["Fortified Belt of Power"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Ivycloth Mantle of the Wolf"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Pillager's Girdle of the Monkey"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Gyromatic Micro-Adjustor"] = {
			["mr"] = 7796,
			["sc"] = 1,
			["id"] = "10498:0:0:0:0",
			["H3219"] = 7796,
			["cc"] = 7,
		},
		["Disciple's Stein of Shadow Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Thornspike"] = {
			["mr"] = 8899,
			["H3219"] = 8899,
		},
		["Short Bastard Sword of Agility"] = {
			["mr"] = 695,
			["H3219"] = 695,
		},
		["Outrunner's Cloak of Strength"] = {
			["mr"] = 1210,
			["H3219"] = 1210,
		},
		["Bard's Tunic of the Wolf"] = {
			["mr"] = 1457,
			["H3219"] = 1457,
		},
		["Copper Bracers"] = {
			["mr"] = 29,
			["H3219"] = 29,
		},
		["Bard's Gloves of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["War Knife of Strength"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Feral Gloves of the Whale"] = {
			["mr"] = 1050,
			["H3219"] = 1050,
		},
		["Spider Palp"] = {
			["mr"] = 673,
			["H3219"] = 673,
		},
		["Cadet Shield of the Monkey"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Tree Bark Jacket"] = {
			["mr"] = 175000,
			["H3219"] = 175000,
		},
		["Training Sword of the Wolf"] = {
			["mr"] = 660,
			["H3219"] = 660,
		},
		["Pioneer Trousers of Arcane Wrath"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Soldier's Armor of the Eagle"] = {
			["mr"] = 2025,
			["H3219"] = 2025,
		},
		["Knight's Girdle of the Bear"] = {
			["mr"] = 6705,
			["H3219"] = 6705,
		},
		["Willow Cape of Healing"] = {
			["mr"] = 1895,
			["H3219"] = 1895,
		},
		["Cadet Shield of the Gorilla"] = {
			["mr"] = 760,
			["H3219"] = 760,
		},
		["War Torn Pants of the Monkey"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Pattern: Heavy Scorpid Vest"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Glyphed Bracers"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Basalt Ring of Stamina"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Fortified Boots of the Gorilla"] = {
			["mr"] = 4350,
			["H3219"] = 4350,
		},
		["Buccaneer's Cape of the Eagle"] = {
			["mr"] = 890,
			["H3219"] = 890,
		},
		["Formula: Enchant Weapon - Lesser Beastslayer"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Feral Gloves of the Bear"] = {
			["mr"] = 1324,
			["H3219"] = 1324,
		},
		["Grunt's Legguards of the Bear"] = {
			["mr"] = 3387,
			["H3219"] = 3387,
		},
		["Bright Armor"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Sorcerer Sash of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Acrobatic Staff of Power"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Oil of Immolation"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Giant Club of the Monkey"] = {
			["mr"] = 9300,
			["H3219"] = 9300,
		},
		["Amy's Blanket"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Brigade Cloak of Stamina"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Sentinel Cloak of the Falcon"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Decapitating Sword of Power"] = {
			["mr"] = 5025,
			["H3219"] = 5025,
		},
		["Black Mageweave Robe"] = {
			["mr"] = 14999,
			["H3219"] = 14999,
		},
		["Tundra Ring of Eluding"] = {
			["mr"] = 6400,
			["H3219"] = 6400,
		},
		["Infiltrator Gloves of the Bear"] = {
			["mr"] = 7100,
			["H3219"] = 7100,
		},
		["Flask of Oil"] = {
			["mr"] = 25,
			["H3219"] = 25,
		},
		["Recipe: Roast Raptor"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Stone Hammer of Stamina"] = {
			["mr"] = 21000,
			["H3219"] = 21000,
		},
		["Supercharger Battle Axe"] = {
			["mr"] = 12499,
			["H3219"] = 12499,
		},
		["Pattern: Heavy Woolen Cloak"] = {
			["mr"] = 400,
			["cc"] = 9,
			["id"] = "4346:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 400,
		},
		["Superior Tunic of the Eagle"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Plans: Frost Tiger Blade"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Thundering Charm"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Black Vitriol"] = {
			["mr"] = 2995,
			["H3219"] = 2995,
		},
		["Buccaneer's Gloves of the Whale"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Poison-tipped Bone Spear"] = {
			["mr"] = 28000,
			["H3219"] = 28000,
		},
		["Savage Axe of the Whale"] = {
			["mr"] = 15714,
			["H3219"] = 15714,
		},
		["Pattern: Guardian Leather Bracers"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Sentry's Cape of Strength"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Twilight Cuffs of Fiery Wrath"] = {
			["mr"] = 4990,
			["cc"] = 4,
			["id"] = "7437:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 4990,
		},
		["Spiritchaser Staff of Fiery Wrath"] = {
			["mr"] = 229668,
			["cc"] = 2,
			["id"] = "1613:0:0:1892:0",
			["sc"] = 10,
			["H3220"] = 229668,
		},
		["Lucky Charm"] = {
			["mr"] = 1189,
			["H3219"] = 1189,
		},
		["Blackskull Shield"] = {
			["mr"] = 210000,
			["H3219"] = 210000,
		},
		["Infantry Tunic of Strength"] = {
			["mr"] = 3087,
			["H3219"] = 3087,
		},
		["Archer's Shoulderpads of the Owl"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Fortified Bracers of the Bear"] = {
			["mr"] = 2730,
			["H3219"] = 2730,
		},
		["Dusky Leather Armor"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Hillborne Axe of the Boar"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Elder's Boots of Spirit"] = {
			["mr"] = 22368,
			["H3219"] = 22368,
		},
		["Banded Girdle of Power"] = {
			["mr"] = 4725,
			["H3219"] = 4725,
		},
		["Willow Cape of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Long Crawler Limb"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Dervish Leggings of Healing"] = {
			["mr"] = 50083,
			["H3219"] = 50083,
		},
		["Heavy Blasting Powder"] = {
			["mr"] = 408,
			["H3219"] = 408,
		},
		["Soft-soled Linen Boots"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Formula: Enchant Gloves - Advanced Mining"] = {
			["mr"] = 1453,
			["H3219"] = 1453,
		},
		["Wicked Chain Shield of the Monkey"] = {
			["mr"] = 50148,
			["H3219"] = 50148,
		},
		["Curved Dagger of Nature's Wrath"] = {
			["mr"] = 1248,
			["H3219"] = 1248,
		},
		["Scaled Cloak of Intellect"] = {
			["mr"] = 4838,
			["H3219"] = 4838,
		},
		["Bard's Belt of the Eagle"] = {
			["mr"] = 1767,
			["H3219"] = 1767,
		},
		["Shadoweave Boots"] = {
			["mr"] = 58616,
			["H3219"] = 58616,
		},
		["Jazeraint Shield of the Tiger"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Deadly Kris of the Tiger"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Sentinel Shoulders of the Wolf"] = {
			["mr"] = 13007,
			["H3219"] = 13007,
		},
		["Green Hills of Stranglethorn - Page 26"] = {
			["mr"] = 793,
			["cc"] = 15,
			["id"] = "2750:0:0:0:0",
			["H3219"] = 793,
			["sc"] = 0,
		},
		["Fortified Shield of Stamina"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Renegade Belt of the Monkey"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Small Glimmering Shard"] = {
			["mr"] = 148,
			["sc"] = 0,
			["id"] = "10978:0:0:0:0",
			["H3219"] = 148,
			["cc"] = 7,
		},
		["Elder's Sash of the Eagle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Tough Leather Shoulderpads"] = {
			["mr"] = 1049,
			["H3219"] = 1049,
		},
		["Gossamer Belt of the Whale"] = {
			["mr"] = 33965,
			["H3219"] = 33965,
		},
		["Willow Belt of Healing"] = {
			["mr"] = 1175,
			["H3219"] = 1175,
		},
		["Ridge Cleaver of the Monkey"] = {
			["mr"] = 4300,
			["H3219"] = 4300,
		},
		["Buccaneer's Cape of Healing"] = {
			["mr"] = 9888,
			["H3219"] = 9888,
		},
		["Infiltrator Gloves of Defense"] = {
			["mr"] = 4899,
			["H3219"] = 4899,
		},
		["Superior Bracers of Spirit"] = {
			["mr"] = 2187,
			["H3219"] = 2187,
		},
		["Willow Belt of Fiery Wrath"] = {
			["mr"] = 1700,
			["H3219"] = 1700,
		},
		["Embossed Leather Boots"] = {
			["mr"] = 325,
			["H3219"] = 325,
		},
		["Twilight Mantle of the Owl"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Pattern: Fine Leather Pants"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Phalanx Headguard of the Whale"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Slitherskin Mackerel"] = {
			["mr"] = 5,
			["H3219"] = 5,
		},
		["Jazeraint Boots of the Monkey"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Wrangler's Cloak of Healing"] = {
			["mr"] = 6545,
			["H3219"] = 6545,
		},
		["Simple Kilt"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Fortified Bracers of Strength"] = {
			["mr"] = 2304,
			["H3219"] = 2304,
		},
		["Moonglow Vest"] = {
			["mr"] = 690,
			["H3219"] = 690,
		},
		["Buccaneer's Cord of Fiery Wrath"] = {
			["mr"] = 1870,
			["cc"] = 4,
			["id"] = "14173:0:0:1879:0",
			["sc"] = 1,
			["H3220"] = 1870,
		},
		["Sequoia Hammer of Power"] = {
			["mr"] = 9422,
			["H3219"] = 9422,
		},
		["Strong Anti-Venom"] = {
			["mr"] = 239,
			["H3219"] = 239,
		},
		["Grizzly Jerkin of the Wolf"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Westfall Stew"] = {
			["mr"] = 120,
			["H3219"] = 120,
		},
		["Dervish Buckler of the Gorilla"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Dwarven Hatchet of Power"] = {
			["mr"] = 775,
			["H3219"] = 775,
		},
		["Monstrous War Axe of the Bear"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Skullcrusher Mace of the Monkey"] = {
			["mr"] = 31208,
			["H3219"] = 31208,
		},
		["Woolen Boots"] = {
			["mr"] = 1400,
			["cc"] = 4,
			["id"] = "2583:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 1400,
		},
		["Merc Sword of Strength"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["BKP \"Sparrow\" Smallbore"] = {
			["mr"] = 5200,
			["H3219"] = 5200,
		},
		["Tusker Sword of the Tiger"] = {
			["mr"] = 99999,
			["cc"] = 2,
			["id"] = "15252:0:0:708:0",
			["sc"] = 8,
			["H3220"] = 99999,
		},
		["Robes of Insight"] = {
			["mr"] = 1302500,
			["H3219"] = 1302500,
		},
		["Burnt Leather Boots"] = {
			["mr"] = 118,
			["H3219"] = 118,
		},
		["Gleaming Claymore of Strength"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Strider Meat"] = {
			["mr"] = 58,
			["H3219"] = 58,
		},
		["Defender Gauntlets of Power"] = {
			["mr"] = 1949,
			["H3219"] = 1949,
		},
		["Explosive Rocket"] = {
			["mr"] = 171,
			["H3219"] = 171,
		},
		["Barbaric Battle Axe of the Tiger"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Topaz Ring of Fire Resistance"] = {
			["mr"] = 15000,
			["sc"] = 0,
			["id"] = "11975:0:0:1414:0",
			["H3224"] = 15000,
			["cc"] = 4,
		},
		["Heavy Armor Kit"] = {
			["mr"] = 960,
			["H3219"] = 960,
		},
		["Emblazoned Buckler"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Blazing Emblem"] = {
			["mr"] = 453501,
			["H3219"] = 453501,
		},
		["Nightsky Robe"] = {
			["mr"] = 9100,
			["H3219"] = 9100,
		},
		["Wizard's Belt"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Worn Mace"] = {
			["mr"] = 237,
			["H3219"] = 237,
		},
		["Raider's Gauntlets of the Tiger"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Battleforge Cloak of the Bear"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Windchaser Footpads"] = {
			["mr"] = 8400,
			["H3219"] = 8400,
		},
		["Wintersbite"] = {
			["mr"] = 4000,
			["sc"] = 0,
			["id"] = "3819:0:0:0:0",
			["H3219"] = 4000,
			["cc"] = 7,
		},
		["Shimmering Robe of the Owl"] = {
			["mr"] = 2340,
			["H3219"] = 2340,
		},
		["Carving Knife of Nature's Wrath"] = {
			["mr"] = 775,
			["H3219"] = 775,
		},
		["Archer's Boots of the Gorilla"] = {
			["mr"] = 5555,
			["H3219"] = 5555,
		},
		["Pattern: Tough Scorpid Bracers"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Recipe: Philosopher's Stone"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Sentinel Cap of the Monkey"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Tracker's Shoulderpads of the Eagle"] = {
			["mr"] = 25521,
			["H3219"] = 25521,
		},
		["Scaled Leather Boots of the Falcon"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Nightcrawlers"] = {
			["mr"] = 29,
			["sc"] = 0,
			["id"] = "6530:0:0:0:0",
			["cc"] = 0,
			["H3226"] = 29,
		},
		["Restorative Potion"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Ring of Defense"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Splitting Hatchet of the Tiger"] = {
			["mr"] = 9651,
			["H3219"] = 9651,
		},
		["Pioneer Trousers of Agility"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Briarthorn"] = {
			["mr"] = 159,
			["H3219"] = 159,
		},
		["Twilight Cuffs of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Recipe: Frost Oil"] = {
			["mr"] = 11800,
			["sc"] = 6,
			["id"] = "14634:0:0:0:0",
			["H3219"] = 11800,
			["cc"] = 9,
		},
		["Relic Coffer Key"] = {
			["mr"] = 995,
			["cc"] = 13,
			["id"] = "11078:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 995,
		},
		["Gemmed Copper Gauntlets of the Eagle"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Scaled Leather Shoulders of the Boar"] = {
			["mr"] = 7043,
			["H3219"] = 7043,
		},
		["Hacking Cleaver of the Boar"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Phalanx Gauntlets of the Eagle"] = {
			["mr"] = 4463,
			["H3219"] = 4463,
		},
		["Formula: Enchant Weapon - Fiery Weapon"] = {
			["mr"] = 80000,
			["H3219"] = 80000,
		},
		["Aurora Sash"] = {
			["mr"] = 3700,
			["H3219"] = 3700,
		},
		["Ridge Cleaver of the Tiger"] = {
			["mr"] = 3495,
			["H3219"] = 3495,
		},
		["Infiltrator Gloves of the Monkey"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Mana Potion"] = {
			["mr"] = 550,
			["cc"] = 0,
			["id"] = "3827:0:0:0:0",
			["H3219"] = 550,
			["sc"] = 0,
		},
		["Conjurer's Vest of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Infiltrator Cloak of the Owl"] = {
			["mr"] = 5307,
			["H3219"] = 5307,
		},
		["Carving Knife of Shadow Wrath"] = {
			["mr"] = 895,
			["H3219"] = 895,
		},
		["Glimmering Mail Legguards"] = {
			["mr"] = 2728,
			["H3219"] = 2728,
		},
		["Raider's Bracers of the Bear"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Superior Leggings of Healing"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Enchanted Water"] = {
			["mr"] = 140,
			["sc"] = 0,
			["id"] = "4791:0:0:0:0",
			["H3219"] = 140,
			["cc"] = 0,
		},
		["Banded Armor of the Bear"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Raider's Shield of the Monkey"] = {
			["mr"] = 2199,
			["H3219"] = 2199,
		},
		["Spiked Club of the Bear"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Linen Cloak"] = {
			["mr"] = 29,
			["H3219"] = 29,
		},
		["Recipe: Nature Protection Potion"] = {
			["mr"] = 9400,
			["H3219"] = 9400,
		},
		["Heavy Hide"] = {
			["mr"] = 448,
			["cc"] = 7,
			["id"] = "4235:0:0:0:0",
			["H3219"] = 448,
			["sc"] = 0,
		},
		["Aboriginal Sash of Healing"] = {
			["mr"] = 1046,
			["H3219"] = 1046,
		},
		["Renegade Belt of Strength"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Disciple's Vest of Spirit"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Blue Linen Robe"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Nightsky Sash"] = {
			["mr"] = 4699,
			["H3219"] = 4699,
		},
		["Edged Bastard Sword of Power"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Cross Dagger of Nature's Wrath"] = {
			["mr"] = 5937,
			["H3219"] = 5937,
		},
		["Beaded Orb of the Wolf"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Nocturnal Tunic of the Bear"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Infantry Tunic of the Bear"] = {
			["mr"] = 550,
			["H3219"] = 550,
		},
		["Scarlet Belt"] = {
			["mr"] = 3900,
			["cc"] = 4,
			["id"] = "10329:0:0:0:0",
			["sc"] = 3,
			["H3225"] = 3900,
		},
		["Schematic: Goblin Rocket Boots"] = {
			["mr"] = 150000,
			["H3219"] = 150000,
		},
		["Bronze Framework"] = {
			["mr"] = 890,
			["H3219"] = 890,
		},
		["Curiously Tasty Omelet"] = {
			["mr"] = 163,
			["H3219"] = 163,
		},
		["War Paint Bindings"] = {
			["mr"] = 1569,
			["H3219"] = 1569,
		},
		["Pattern: Turtle Scale Gloves"] = {
			["mr"] = 20000,
			["cc"] = 9,
			["id"] = "8385:0:0:0:0",
			["H3213"] = 20000,
			["sc"] = 1,
		},
		["Elder's Hat of Frozen Wrath"] = {
			["mr"] = 10500,
			["H3219"] = 10500,
		},
		["Anti-Venom"] = {
			["mr"] = 35,
			["H3219"] = 35,
		},
		["Willow Belt of the Owl"] = {
			["mr"] = 1484,
			["H3219"] = 1484,
		},
		["Defias Renegade Ring"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Expert Cookbook"] = {
			["H3225"] = 20000,
			["sc"] = 5,
			["id"] = "16072:0:0:0:0",
			["mr"] = 20000,
			["cc"] = 9,
		},
		["Banded Cloak of Stamina"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Silver-thread Pants"] = {
			["mr"] = 4300,
			["H3219"] = 4300,
		},
		["Grime-Encrusted Object"] = {
			["mr"] = 43,
			["H3219"] = 43,
		},
		["Hefty Battlehammer of Stamina"] = {
			["mr"] = 5950,
			["H3219"] = 5950,
		},
		["Infiltrator Boots of Agility"] = {
			["mr"] = 27468,
			["H3219"] = 27468,
		},
		["Scouting Trousers of the Falcon"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Cooked Crab Claw"] = {
			["H3225"] = 25,
			["sc"] = 0,
			["id"] = "2682:0:0:0:0",
			["mr"] = 25,
			["cc"] = 0,
		},
		["Buccaneer's Orb of Intellect"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Green Lens of Concentration"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Amber Hoop of Shadow Resistance"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Fortified Boots of the Tiger"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Silver-thread Sash"] = {
			["mr"] = 3861,
			["H3219"] = 3861,
		},
		["Small Brilliant Shard"] = {
			["H3223"] = 17500,
			["mr"] = 17500,
			["cc"] = 7,
			["id"] = "14343:0:0:0:0",
			["sc"] = 0,
		},
		["Green Woolen Vest"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Banded Gauntlets of Strength"] = {
			["mr"] = 4799,
			["H3219"] = 4799,
		},
		["Light Bow"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Golden Rod"] = {
			["mr"] = 1517,
			["H3219"] = 1517,
		},
		["Plans: Steel Weapon Chain"] = {
			["mr"] = 1250000,
			["cc"] = 9,
			["id"] = "6046:0:0:0:0",
			["H3221"] = 1250000,
			["sc"] = 4,
		},
		["Inlaid Mithril Cylinder"] = {
			["mr"] = 23800,
			["H3219"] = 23800,
		},
		["Cross Dagger of Healing"] = {
			["mr"] = 5938,
			["H3219"] = 5938,
		},
		["Sacrificial Kris of the Tiger"] = {
			["mr"] = 28900,
			["H3219"] = 28900,
		},
		["Resilient Tunic"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Twilight Mantle of Shadow Wrath"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Defender Boots of Defense"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Glyphed Belt"] = {
			["mr"] = 6831,
			["H3219"] = 6831,
		},
		["Recipe: Gooey Spider Cake"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Ring of Precision"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Crescent Edge of the Tiger"] = {
			["mr"] = 49999,
			["H3219"] = 49999,
		},
		["Acrobatic Staff of Nature's Wrath"] = {
			["mr"] = 9600,
			["H3219"] = 9600,
		},
		["Mercenary Blade of the Tiger"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Formula: Enchant Cloak - Lesser Agility"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Cadet Leggings of the Bear"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Schematic: Delicate Arcanite Converter"] = {
			["mr"] = 20000,
			["sc"] = 3,
			["id"] = "16050:0:0:0:0",
			["H3224"] = 20000,
			["cc"] = 9,
		},
		["Elder's Sash of the Monkey"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Bandit Cinch of Intellect"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sage's Sash of the Whale"] = {
			["mr"] = 3499,
			["H3219"] = 3499,
		},
		["Archer's Boots of Spirit"] = {
			["mr"] = 10131,
			["H3219"] = 10131,
		},
		["Viridian Band of Intellect"] = {
			["mr"] = 14399,
			["H3219"] = 14399,
		},
		["Feral Gloves of the Monkey"] = {
			["mr"] = 1110,
			["H3219"] = 1110,
		},
		["Beaded Orb of the Owl"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Buccaneer's Cord of the Monkey"] = {
			["mr"] = 2297,
			["H3219"] = 2297,
		},
		["Searing Needle"] = {
			["mr"] = 180000,
			["H3219"] = 180000,
		},
		["Nightscape Shoulders"] = {
			["mr"] = 9995,
			["H3219"] = 9995,
		},
		["Simple Britches of the Eagle"] = {
			["mr"] = 440,
			["H3219"] = 440,
		},
		["Solid Stone"] = {
			["mr"] = 327,
			["cc"] = 7,
			["id"] = "7912:0:0:0:0",
			["H3221"] = 327,
			["sc"] = 0,
		},
		["Geomancer's Gloves of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Training Sword of Power"] = {
			["mr"] = 549,
			["H3219"] = 549,
		},
		["Abjurer's Hood of the Wolf"] = {
			["mr"] = 80000,
			["H3219"] = 80000,
		},
		["Scouting Boots of the Monkey"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Rumsey Rum Dark"] = {
			["mr"] = 78,
			["H3219"] = 78,
		},
		["Renegade Belt of Power"] = {
			["mr"] = 11291,
			["H3219"] = 11291,
		},
		["Recipe: Limited Invulnerability Potion"] = {
			["mr"] = 25000,
			["cc"] = 9,
			["id"] = "3395:0:0:0:0",
			["sc"] = 6,
			["H3220"] = 25000,
		},
		["Rodentia Flint Axe"] = {
			["mr"] = 685,
			["H3219"] = 685,
		},
		["Banded Boots of the Bear"] = {
			["mr"] = 5497,
			["H3219"] = 5497,
		},
		["Scouting Bracers of Intellect"] = {
			["mr"] = 1199,
			["H3219"] = 1199,
		},
		["Sauteed Sunfish"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Crude Scope"] = {
			["mr"] = 128,
			["H3219"] = 128,
		},
		["Shadoweave Gloves"] = {
			["mr"] = 49054,
			["H3219"] = 49054,
		},
		["Tender Crab Meat"] = {
			["mr"] = 174,
			["H3219"] = 174,
		},
		["Azure Silk Hood"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Bard's Belt of Defense"] = {
			["mr"] = 1514,
			["H3219"] = 1514,
		},
		["Barbarian War Axe of the Tiger"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Hacking Cleaver of Strength"] = {
			["mr"] = 9939,
			["H3219"] = 9939,
		},
		["Defender Shield of the Boar"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Pattern: Tough Scorpid Gloves"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Spinel Ring of Fire Resistance"] = {
			["H3224"] = 10036,
			["cc"] = 4,
			["id"] = "11970:0:0:1409:0",
			["L3224"] = 7909,
			["mr"] = 7909,
			["sc"] = 0,
		},
		["Sacrificial Kris of the Monkey"] = {
			["mr"] = 34602,
			["H3219"] = 34602,
		},
		["Firestarter"] = {
			["mr"] = 3510,
			["H3219"] = 3510,
		},
		["Pattern: Dark Leather Tunic"] = {
			["mr"] = 417,
			["H3219"] = 417,
		},
		["Banded Leggings of the Whale"] = {
			["mr"] = 9489,
			["H3219"] = 9489,
		},
		["Bolt of Runecloth"] = {
			["H3225"] = 4000,
			["cc"] = 7,
			["id"] = "14048:0:0:0:0",
			["H3224"] = 3996,
			["sc"] = 0,
			["mr"] = 4000,
		},
		["Gossamer Robe of the Eagle"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Simple Britches of the Owl"] = {
			["mr"] = 300,
			["H3219"] = 300,
		},
		["Mistscape Sash"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Infantry Shield of Stamina"] = {
			["mr"] = 3799,
			["H3219"] = 3799,
		},
		["Infantry Shield of the Bear"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Antiquated Cloak"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Shimmering Armor of the Owl"] = {
			["mr"] = 6336,
			["H3219"] = 6336,
		},
		["Huntsman's Boots of the Whale"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Pattern: Deviate Scale Cloak"] = {
			["mr"] = 7554,
			["H3219"] = 7554,
		},
		["Abjurer's Cloak of Fiery Wrath"] = {
			["mr"] = 15993,
			["cc"] = 4,
			["id"] = "9938:0:0:1885:0",
			["sc"] = 1,
			["H3220"] = 15993,
		},
		["Mystery Meat"] = {
			["mr"] = 160,
			["H3219"] = 160,
		},
		["Geomancer's Gloves of Healing"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Grunt Axe of Stamina"] = {
			["mr"] = 1699,
			["H3219"] = 1699,
		},
		["Scaled Leather Shoulders of Intellect"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Boiled Clams"] = {
			["mr"] = 24,
			["H3219"] = 24,
		},
		["Hulking Gauntlets"] = {
			["mr"] = 2099,
			["H3219"] = 2099,
		},
		["Spellbinder Cloak"] = {
			["mr"] = 150,
			["H3219"] = 150,
		},
		["Renegade Circlet of Defense"] = {
			["mr"] = 6099,
			["H3219"] = 6099,
		},
		["Large Knapsack"] = {
			["mr"] = 15400,
			["H3219"] = 15400,
		},
		["Formula: Enchant Weapon - Minor Beastslayer"] = {
			["mr"] = 199,
			["H3219"] = 199,
		},
		["Jet Chain of Intellect"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Buccaneer's Pants of Fiery Wrath"] = {
			["mr"] = 2214,
			["cc"] = 4,
			["id"] = "14171:0:0:1881:0",
			["sc"] = 1,
			["H3220"] = 2214,
		},
		["Savage Axe of the Boar"] = {
			["mr"] = 15600,
			["H3219"] = 15600,
		},
		["Kobold Mining Shovel"] = {
			["mr"] = 350,
			["H3219"] = 350,
		},
		["Bandit Jerkin of the Owl"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Lion Meat"] = {
			["mr"] = 368,
			["H3219"] = 368,
		},
		["Plains Ring"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Durable Cape of the Eagle"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Moist Cornbread"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Raider's Bracers of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Gooey Spider Leg"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Zircon Band of Fire Resistance"] = {
			["mr"] = 9750,
			["H3219"] = 9750,
		},
		["Banded Cloak of Strength"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Stonevault Shiv"] = {
			["mr"] = 352451,
			["H3219"] = 352451,
		},
		["Bracers of Valor"] = {
			["mr"] = 245131,
			["cc"] = 4,
			["id"] = "16735:0:0:0:0",
			["sc"] = 4,
			["H3224"] = 245131,
		},
		["Mithril Casing"] = {
			["mr"] = 12498,
			["cc"] = 7,
			["id"] = "10561:0:0:0:0",
			["H3219"] = 12498,
			["sc"] = 1,
		},
		["Archer's Cap of the Owl"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Formula: Enchant Shield - Lesser Protection"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Bandit Boots of Power"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Raider's Legguards of the Monkey"] = {
			["mr"] = 1099,
			["H3219"] = 1099,
		},
		["Spellbinder Pants"] = {
			["mr"] = 450,
			["H3219"] = 450,
		},
		["Sorcerer Gloves of the Eagle"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Conjurer's Gloves of Spirit"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Opulent Gloves of Fiery Wrath"] = {
			["mr"] = 20000,
			["cc"] = 4,
			["id"] = "14282:0:0:1889:0",
			["sc"] = 1,
			["H3220"] = 20000,
		},
		["Glimmering Flamberge of the Bear"] = {
			["mr"] = 10400,
			["H3219"] = 10400,
		},
		["Crocolisk Gumbo"] = {
			["mr"] = 153,
			["H3219"] = 153,
		},
		["Buccaneer's Gloves of Fiery Wrath"] = {
			["mr"] = 2700,
			["H3219"] = 2700,
		},
		["Schematic: Shadow Goggles"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Ivory Wand of Fiery Wrath"] = {
			["mr"] = 155500,
			["cc"] = 2,
			["id"] = "15279:0:0:1881:0",
			["sc"] = 19,
			["H3220"] = 155500,
		},
		["Short Bastard Sword of the Tiger"] = {
			["mr"] = 1410,
			["H3219"] = 1410,
		},
		["Shimmering Stave of the Eagle"] = {
			["mr"] = 5600,
			["H3219"] = 5600,
		},
		["Mageweave Cloth"] = {
			["mr"] = 635,
			["sc"] = 0,
			["id"] = "4338:0:0:0:0",
			["H3224"] = 635,
			["cc"] = 7,
		},
		["Scaled Leather Tunic of the Owl"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Metalworking Gloves"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Battle Chain Tunic"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Staunch Hammer of Healing"] = {
			["mr"] = 795,
			["H3219"] = 795,
		},
		["Witchfury"] = {
			["mr"] = 69499,
			["cc"] = 2,
			["id"] = "13051:0:0:0:0",
			["H3219"] = 69499,
			["sc"] = 8,
		},
		["Stormwind Seasoning Herbs"] = {
			["mr"] = 174,
			["H3219"] = 174,
		},
		["Buccaneer's Pants of the Whale"] = {
			["mr"] = 3050,
			["H3219"] = 3050,
		},
		["Infiltrator Shoulders of the Whale"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Spellbinder Vest"] = {
			["mr"] = 790,
			["H3219"] = 790,
		},
		["Archer's Gloves of Defense"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Scroll of Protection II"] = {
			["mr"] = 168,
			["H3219"] = 168,
		},
		["Frostmane Club"] = {
			["mr"] = 173,
			["H3219"] = 173,
		},
		["Burnished Boots"] = {
			["mr"] = 1389,
			["H3219"] = 1389,
		},
		["Soldier's Boots of the Gorilla"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Malachite"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Willow Robe of Spirit"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Dwarven Magestaff of Arcane Wrath"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Elixir of Lesser Agility"] = {
			["H3223"] = 1199,
			["mr"] = 1199,
			["cc"] = 0,
			["id"] = "3390:0:0:0:0",
			["sc"] = 0,
		},
		["Charger's Pants of the Bear"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Banded Boots of the Whale"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Aboriginal Rod of the Owl"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Clay Ring of the Boar"] = {
			["mr"] = 9952,
			["H3219"] = 9952,
		},
		["Gypsy Trousers of Healing"] = {
			["mr"] = 469,
			["H3219"] = 469,
		},
		["Savannah Ring of the Tiger"] = {
			["mr"] = 8834,
			["H3219"] = 8834,
		},
		["Handstitched Leather Cloak"] = {
			["mr"] = 34,
			["H3219"] = 34,
		},
		["Crystal Starfire Medallion"] = {
			["mr"] = 35000,
			["H3219"] = 35000,
		},
		["Barbed Club of Nature's Wrath"] = {
			["mr"] = 2125,
			["H3219"] = 2125,
		},
		["Shimmering Robe of Stamina"] = {
			["mr"] = 1566,
			["H3219"] = 1566,
		},
		["Big Bronze Bomb"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Savory Deviate Delight"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Phalanx Girdle of Strength"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Bogling Root"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Prairie Ring of the Monkey"] = {
			["mr"] = 30491,
			["H3219"] = 30491,
		},
		["Coal"] = {
			["mr"] = 375,
			["H3219"] = 375,
		},
		["Barbarian War Axe of Strength"] = {
			["mr"] = 4675,
			["H3219"] = 4675,
		},
		["Thorbia's Gauntlets"] = {
			["mr"] = 49999,
			["H3219"] = 49999,
		},
		["Pattern: Phoenix Pants"] = {
			["mr"] = 2177,
			["H3219"] = 2177,
		},
		["Expert First Aid - Under Wraps"] = {
			["mr"] = 11598,
			["H3219"] = 11598,
		},
		["Durable Shoulders of the Wolf"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Savannah Ring of the Monkey"] = {
			["mr"] = 12188,
			["H3219"] = 12188,
		},
		["Buccaneer's Orb of the Eagle"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Sage's Sash of the Owl"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Mindbender Loop"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Scroll of Intellect"] = {
			["mr"] = 47,
			["H3219"] = 47,
		},
		["Worn Leather Belt"] = {
			["mr"] = 109,
			["H3219"] = 109,
		},
		["Spiked Club of the Whale"] = {
			["mr"] = 780,
			["H3219"] = 780,
		},
		["Bandit Bracers of the Owl"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Cross Dagger of Power"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Archer's Jerkin of the Monkey"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Linen Cloth"] = {
			["mr"] = 25,
			["sc"] = 0,
			["id"] = "2589:0:0:0:0",
			["H3219"] = 25,
			["cc"] = 7,
		},
		["Sage's Stave of the Eagle"] = {
			["mr"] = 19900,
			["H3219"] = 19900,
		},
		["Silvered Bronze Boots"] = {
			["mr"] = 1825,
			["H3219"] = 1825,
		},
		["Wrangler's Wraps of the Monkey"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Ivycloth Mantle of the Owl"] = {
			["mr"] = 8546,
			["H3219"] = 8546,
		},
		["Aurora Cowl"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Buccaneer's Cape of the Whale"] = {
			["mr"] = 490,
			["H3219"] = 490,
		},
		["Noble's Robe"] = {
			["mr"] = 640,
			["H3219"] = 640,
		},
		["War Torn Shield of the Gorilla"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["White Leather Bag"] = {
			["mr"] = 1319,
			["H3219"] = 1319,
		},
		["Bright Sphere"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Wildheart Gloves"] = {
			["mr"] = 300000,
			["H3219"] = 300000,
		},
		["Phalanx Boots of the Monkey"] = {
			["mr"] = 7800,
			["H3219"] = 7800,
		},
		["Scouting Gloves of the Owl"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Elixir of Ogre's Strength"] = {
			["H3223"] = 299,
			["mr"] = 299,
			["sc"] = 0,
			["id"] = "3391:0:0:0:0",
			["cc"] = 0,
		},
		["Purple Lotus"] = {
			["mr"] = 670,
			["H3219"] = 670,
		},
		["Journeyman's Pants"] = {
			["H3225"] = 173,
			["sc"] = 1,
			["id"] = "2958:0:0:0:0",
			["mr"] = 173,
			["cc"] = 4,
		},
		["Elixir of Defense"] = {
			["H3223"] = 683,
			["mr"] = 683,
			["cc"] = 0,
			["id"] = "3389:0:0:0:0",
			["sc"] = 0,
		},
		["Nightsky Orb"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Scaled Leather Tunic of the Falcon"] = {
			["mr"] = 9347,
			["H3219"] = 9347,
		},
		["Deviate Fish"] = {
			["mr"] = 102,
			["H3219"] = 102,
		},
		["Cross Dagger of the Tiger"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Conjurer's Gloves of the Eagle"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Merc Sword of the Tiger"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Sturdy Quarterstaff of Arcane Wrath"] = {
			["mr"] = 1387,
			["H3219"] = 1387,
		},
		["Elder's Hat of the Owl"] = {
			["mr"] = 8999,
			["H3219"] = 8999,
		},
		["Bandit Pants of Power"] = {
			["mr"] = 2748,
			["H3219"] = 2748,
		},
		["Simple Robe of Stamina"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Curved Dagger of Fiery Wrath"] = {
			["mr"] = 7260,
			["cc"] = 2,
			["id"] = "2632:0:0:1875:0",
			["sc"] = 15,
			["H3220"] = 7260,
		},
		["Sage's Mantle of the Eagle"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Thin Kodo Leather"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Essence of Fire"] = {
			["mr"] = 74000,
			["H3219"] = 74000,
		},
		["Glimmering Mail Girdle"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Conjurer's Shoes of the Falcon"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Steel Weapon Chain"] = {
			["mr"] = 32081,
			["cc"] = 7,
			["id"] = "6041:0:0:0:0",
			["H3221"] = 32081,
			["sc"] = 0,
		},
		["Banded Bracers of the Whale"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Knight's Crest of Blocking"] = {
			["mr"] = 21500,
			["H3219"] = 21500,
		},
		["Formula: Enchant Weapon - Lesser Elemental Slayer"] = {
			["mr"] = 4100,
			["H3219"] = 4100,
		},
		["Twilight Gloves of the Eagle"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Shimmering Boots of the Owl"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Raw Rockscale Cod"] = {
			["mr"] = 43,
			["H3219"] = 43,
		},
		["Superior Shoulders of the Whale"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Soldier's Boots of the Boar"] = {
			["mr"] = 998,
			["H3219"] = 998,
		},
		["Rough Bronze Shoulders"] = {
			["mr"] = 805,
			["H3219"] = 805,
		},
		["Shimmering Bracers of the Eagle"] = {
			["mr"] = 2299,
			["H3219"] = 2299,
		},
		["Ritual Sandals of the Falcon"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Journeyman's Backpack"] = {
			["H3225"] = 45429,
			["sc"] = 0,
			["id"] = "3914:0:0:0:0",
			["mr"] = 45429,
			["cc"] = 1,
		},
		["Buccaneer's Boots of Spirit"] = {
			["mr"] = 1495,
			["H3219"] = 1495,
		},
		["Willow Robe of the Eagle"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Sorcerer Cloak of Arcane Wrath"] = {
			["mr"] = 9469,
			["H3219"] = 9469,
		},
		["Gypsy Tunic of Power"] = {
			["mr"] = 9899,
			["H3219"] = 9899,
		},
		["Willow Branch of the Whale"] = {
			["mr"] = 1294,
			["H3219"] = 1294,
		},
		["Large Fang"] = {
			["mr"] = 193,
			["H3219"] = 193,
		},
		["Infiltrator Pants of the Eagle"] = {
			["mr"] = 6569,
			["H3219"] = 6569,
		},
		["Lunar Handwraps of Fiery Wrath"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Recipe: Elixir of Lesser Agility"] = {
			["H3223"] = 10000,
			["mr"] = 10000,
			["sc"] = 6,
			["id"] = "3396:0:0:0:0",
			["cc"] = 9,
		},
		["Formula: Enchant Gloves - Fishing"] = {
			["mr"] = 760,
			["H3219"] = 760,
		},
		["Infiltrator Gloves of the Eagle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Schematic: Portable Bronze Mortar"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Banded Shield of the Boar"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Shimmering Trousers of the Falcon"] = {
			["mr"] = 3432,
			["H3219"] = 3432,
		},
		["Pattern: Red Linen Bag"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Scouting Cloak of Spirit"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Notched Shortsword of Strength"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Beaded Robe of Stamina"] = {
			["mr"] = 610,
			["H3219"] = 610,
		},
		["Grizzly Buckler of Spirit"] = {
			["mr"] = 2555,
			["H3219"] = 2555,
		},
		["Recipe: Longjaw Mud Snapper"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Soldier's Armor of the Tiger"] = {
			["mr"] = 1838,
			["H3219"] = 1838,
		},
		["War Knife of Nature's Wrath"] = {
			["mr"] = 2299,
			["H3219"] = 2299,
		},
		["Rageclaw Leggings of the Monkey"] = {
			["mr"] = 20500,
			["cc"] = 4,
			["id"] = "15385:0:0:623:0",
			["H3224"] = 20500,
			["sc"] = 2,
		},
		["Cured Light Hide"] = {
			["mr"] = 124,
			["H3219"] = 124,
		},
		["Superior Bracers of the Whale"] = {
			["mr"] = 8748,
			["H3219"] = 8748,
		},
		["Medicine Staff of Healing"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Weighted Sap"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Shimmering Bracers of Stamina"] = {
			["mr"] = 1816,
			["H3219"] = 1816,
		},
		["Fortified Gauntlets of the Boar"] = {
			["mr"] = 3046,
			["H3219"] = 3046,
		},
		["Superior Belt of Defense"] = {
			["mr"] = 3316,
			["H3219"] = 3316,
		},
		["Durable Shoulders of the Owl"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Ritual Bands of the Owl"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Dervish Cape of the Monkey"] = {
			["mr"] = 2166,
			["H3219"] = 2166,
		},
		["Basalt Ring of the Bear"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Twilight Belt of Intellect"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Superior Belt of the Whale"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Gauntlets of Valor"] = {
			["H3224"] = 700000,
			["cc"] = 4,
			["id"] = "16737:0:0:0:0",
			["sc"] = 4,
			["mr"] = 700000,
		},
		["Crimson Silk Belt"] = {
			["mr"] = 8600,
			["H3219"] = 8600,
		},
		["Thick Murloc Scale"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Roast Raptor"] = {
			["mr"] = 780,
			["H3219"] = 780,
		},
		["Buzzard Wing"] = {
			["mr"] = 640,
			["sc"] = 0,
			["id"] = "3404:0:0:0:0",
			["H3219"] = 640,
			["cc"] = 7,
		},
		["Feral Leggings of the Owl"] = {
			["mr"] = 8940,
			["H3219"] = 8940,
		},
		["Renegade Cloak of Strength"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Raider's Cloak of the Monkey"] = {
			["mr"] = 1250,
			["H3219"] = 1250,
		},
		["Inscribed Leather Pants"] = {
			["mr"] = 729,
			["H3219"] = 729,
		},
		["Tigerbane"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Frostreaver Crown"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Green Power Crystal"] = {
			["mr"] = 630,
			["H3219"] = 630,
		},
		["Soldier's Gauntlets of the Boar"] = {
			["mr"] = 801,
			["H3219"] = 801,
		},
		["Headsplitter"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Raider's Shield of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Battering Hammer of the Boar"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Ivycloth Gloves of the Owl"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Dwarven Magestaff of the Boar"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Elder's Boots of the Owl"] = {
			["mr"] = 6899,
			["H3219"] = 6899,
		},
		["Huntsman's Cap of the Eagle"] = {
			["mr"] = 9499,
			["H3219"] = 9499,
		},
		["Simple Britches of Fiery Wrath"] = {
			["mr"] = 300,
			["cc"] = 4,
			["id"] = "9747:0:0:1877:0",
			["sc"] = 1,
			["H3220"] = 300,
		},
		["Heavy Linen Bandage"] = {
			["mr"] = 20,
			["sc"] = 0,
			["id"] = "2581:0:0:0:0",
			["H3219"] = 20,
			["cc"] = 0,
		},
		["Edged Bastard Sword of Agility"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Renegade Belt of the Boar"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Decapitating Sword of the Tiger"] = {
			["mr"] = 3860,
			["H3219"] = 3860,
		},
		["Pioneer Tunic of Spirit"] = {
			["mr"] = 457,
			["H3219"] = 457,
		},
		["Gyrochronatom"] = {
			["mr"] = 3605,
			["sc"] = 1,
			["id"] = "4389:0:0:0:0",
			["H3219"] = 3605,
			["cc"] = 7,
		},
		["Small Furry Paw"] = {
			["mr"] = 92,
			["H3219"] = 92,
		},
		["Dokebi Mantle"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Ridge Cleaver of the Wolf"] = {
			["mr"] = 7777,
			["H3219"] = 7777,
		},
		["Scaled Leather Belt of the Owl"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Scouting Boots of Stamina"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Forgotten Wraps"] = {
			["mr"] = 30000,
			["cc"] = 4,
			["id"] = "9433:0:0:0:0",
			["sc"] = 1,
			["H3220"] = 30000,
		},
		["Field Plate Girdle of the Bear"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Sword of Corruption"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Righteous Orb"] = {
			["mr"] = 900000,
			["H3219"] = 900000,
		},
		["Aurora Boots"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Splitting Hatchet of the Monkey"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Raider's Shield of Strength"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Cross Dagger of the Bear"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Defender Shield of the Monkey"] = {
			["mr"] = 3760,
			["H3219"] = 3760,
		},
		["Sorcerer Hat of Stamina"] = {
			["mr"] = 14714,
			["H3219"] = 14714,
		},
		["Staunch Hammer of Arcane Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Phalanx Boots of Stamina"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Lupine Vest of Nature's Wrath"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Elder's Mantle of the Whale"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Green Tea Leaf"] = {
			["mr"] = 19,
			["H3219"] = 19,
		},
		["Essence of Air"] = {
			["mr"] = 89899,
			["H3219"] = 89899,
		},
		["Crimson Lotus"] = {
			["mr"] = 350,
			["H3219"] = 350,
		},
		["Pads of the Venom Spider"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Defender Leggings of the Bear"] = {
			["mr"] = 3450,
			["H3219"] = 3450,
		},
		["Sergeant's Warhammer of Arcane Wrath"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Superior Tunic of Stamina"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Earthroot"] = {
			["mr"] = 20,
			["H3219"] = 20,
		},
		["Twisted Sabre"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Rough Grinding Stone"] = {
			["mr"] = 15,
			["H3219"] = 15,
		},
		["Scaled Leather Belt of Intellect"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Bandit Boots of the Falcon"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Sentinel Bracers of Healing"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Raider's Gauntlets of the Boar"] = {
			["mr"] = 950,
			["H3219"] = 950,
		},
		["Copper Modulator"] = {
			["mr"] = 302,
			["H3219"] = 302,
		},
		["Willow Robe of Intellect"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Pattern: Murloc Scale Bracers"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Staff of Horrors"] = {
			["mr"] = 2699,
			["H3219"] = 2699,
		},
		["Spider Sausage"] = {
			["mr"] = 1249,
			["H3219"] = 1249,
		},
		["Phalanx Gauntlets of the Whale"] = {
			["mr"] = 5334,
			["H3219"] = 5334,
		},
		["Sage's Cloth of Intellect"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Dreamslayer"] = {
			["mr"] = 45000,
			["H3219"] = 45000,
		},
		["Mail Combat Spaulders"] = {
			["mr"] = 5999,
			["H3219"] = 5999,
		},
		["Enduring Gauntlets"] = {
			["mr"] = 22499,
			["H3219"] = 22499,
		},
		["10 Pound Mud Snapper"] = {
			["mr"] = 79,
			["H3219"] = 79,
		},
		["Battering Hammer of Power"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Sentinel Breastplate of the Monkey"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Headhunter's Woolies of the Eagle"] = {
			["H3224"] = 8500,
			["cc"] = 4,
			["id"] = "15358:0:0:863:0",
			["sc"] = 2,
			["mr"] = 8500,
		},
		["Superior Bracers of the Owl"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Scouting Trousers of Power"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Canvas Gloves"] = {
			["mr"] = 151,
			["H3219"] = 151,
		},
		["Ritual Sandals of Stamina"] = {
			["mr"] = 1240,
			["H3219"] = 1240,
		},
		["War Torn Pants of Power"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Simple Wood"] = {
			["mr"] = 195,
			["H3219"] = 195,
		},
		["Pattern: Red Linen Robe"] = {
			["mr"] = 48,
			["H3219"] = 48,
		},
		["Raider's Cloak of the Whale"] = {
			["mr"] = 942,
			["H3219"] = 942,
		},
		["Ranger Leggings of the Monkey"] = {
			["mr"] = 17500,
			["H3219"] = 17500,
		},
		["Stonecutter Claymore of the Monkey"] = {
			["mr"] = 10101,
			["H3219"] = 10101,
		},
		["Nightwind Belt"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Knight's Bracers of the Boar"] = {
			["mr"] = 29148,
			["H3219"] = 29148,
		},
		["Priest's Mace of Strength"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Troll Tribal Necklace"] = {
			["mr"] = 2222,
			["H3219"] = 2222,
		},
		["Plans: Copper Chain Vest"] = {
			["mr"] = 29,
			["H3219"] = 29,
		},
		["Grizzly Pants of the Falcon"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Ridge Cleaver of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Durable Gloves of Spirit"] = {
			["mr"] = 7708,
			["H3219"] = 7708,
		},
		["Shimmering Armor of Spirit"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Pressed Felt Robe"] = {
			["mr"] = 7800,
			["H3219"] = 7800,
		},
		["Blackforge Cape"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Darkmist Wizard Hat of Stamina"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Pillager's Boots of the Monkey"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Viking Sword of the Tiger"] = {
			["mr"] = 9300,
			["H3219"] = 9300,
		},
		["Skeletal Longsword"] = {
			["mr"] = 6055,
			["H3219"] = 6055,
		},
		["Elemental Water"] = {
			["mr"] = 415,
			["sc"] = 0,
			["id"] = "7070:0:0:0:0",
			["cc"] = 5,
			["H3222"] = 415,
		},
		["Tiger Meat"] = {
			["mr"] = 347,
			["sc"] = 0,
			["id"] = "12202:0:0:0:0",
			["H3219"] = 347,
			["cc"] = 7,
		},
		["Conjurer's Hood of Fiery Wrath"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Spectral Necklace of the Bear"] = {
			["mr"] = 59899,
			["H3219"] = 59899,
		},
		["Rockscale Cod"] = {
			["mr"] = 121,
			["H3219"] = 121,
		},
		["Cerulean Ring of Concentration"] = {
			["mr"] = 11994,
			["H3219"] = 11994,
		},
		["Renegade Boots of the Tiger"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Watchman Pauldrons"] = {
			["mr"] = 117000,
			["H3219"] = 117000,
		},
		["Durable Cape of Spirit"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Wicked Chain Boots of the Whale"] = {
			["mr"] = 6924,
			["H3219"] = 6924,
		},
		["Gypsy Buckler of Stamina"] = {
			["mr"] = 496,
			["H3219"] = 496,
		},
		["Sentinel Cloak of the Whale"] = {
			["mr"] = 7300,
			["H3219"] = 7300,
		},
		["Spidersilk Boots"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Green Hills of Stranglethorn - Page 25"] = {
			["mr"] = 588,
			["sc"] = 0,
			["id"] = "2749:0:0:0:0",
			["H3219"] = 588,
			["cc"] = 15,
		},
		["Inscribed Cloak"] = {
			["mr"] = 377,
			["H3219"] = 377,
		},
		["Vision Dust"] = {
			["mr"] = 3999,
			["cc"] = 7,
			["id"] = "11137:0:0:0:0",
			["H3219"] = 3999,
			["sc"] = 0,
		},
		["Elder's Hat of Healing"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Conjurer's Mantle of the Eagle"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Recipe: Magic Resistance Potion"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Forest Leather Gloves"] = {
			["mr"] = 1050,
			["H3219"] = 1050,
		},
		["Barbarian War Axe of the Monkey"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Dervish Buckler of the Boar"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Heavy Woolen Gloves"] = {
			["mr"] = 995,
			["cc"] = 4,
			["id"] = "4310:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 995,
		},
		["Trickster's Leggings of the Eagle"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Sequoia Hammer of Stamina"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Beaded Orb of the Eagle"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Raw Spotted Yellowtail"] = {
			["mr"] = 18,
			["H3219"] = 18,
		},
		["Bandit Buckler of the Gorilla"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Combat Cloak"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Sorcerer Cloak of Intellect"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Sentinel Breastplate of Intellect"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Scouting Gloves of Spirit"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Scaled Leather Tunic of Intellect"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Twilight Gloves of the Owl"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Twilight Cape of Stamina"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Tigerstrike Mantle"] = {
			["mr"] = 149998,
			["H3219"] = 149998,
		},
		["Small Brown Pouch"] = {
			["mr"] = 242,
			["H3219"] = 242,
		},
		["Strider Stew"] = {
			["mr"] = 46,
			["H3219"] = 46,
		},
		["Hulking Boots"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Pattern: Fine Leather Gloves"] = {
			["mr"] = 190,
			["H3219"] = 190,
		},
		["Pattern: Crimson Silk Cloak"] = {
			["mr"] = 4700,
			["H3219"] = 4700,
		},
		["Gleaming Claymore of the Eagle"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Jagged Star of Healing"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Goldthorn Tea"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Willow Robe of Arcane Wrath"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Battlesmasher of Strength"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Chrome Ring of the Owl"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Phalanx Leggings of the Monkey"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Double Link Tunic"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Banded Cloak of Defense"] = {
			["mr"] = 1998,
			["H3219"] = 1998,
		},
		["Green Iron Hauberk"] = {
			["mr"] = 27500,
			["H3219"] = 27500,
		},
		["Fine Leather Cloak"] = {
			["mr"] = 823,
			["H3219"] = 823,
		},
		["Brutal War Axe of Agility"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Leaden Mace of the Tiger"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Ivycloth Cloak of Spirit"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Mercenary Blade of Strength"] = {
			["mr"] = 48750,
			["H3219"] = 48750,
		},
		["Seer's Pants"] = {
			["mr"] = 599,
			["H3219"] = 599,
		},
		["Squishy Basilisk Eye"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Scaled Leather Headband of Stamina"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Knight's Girdle of Power"] = {
			["mr"] = 24000,
			["H3219"] = 24000,
		},
		["Renegade Gauntlets of Strength"] = {
			["mr"] = 12426,
			["H3219"] = 12426,
		},
		["Dark Iron Leather"] = {
			["mr"] = 5234,
			["H3219"] = 5234,
		},
		["Seer's Fine Stein"] = {
			["mr"] = 1647,
			["H3219"] = 1647,
		},
		["Knight's Legguards of the Bear"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Mail Combat Belt"] = {
			["mr"] = 3050,
			["H3219"] = 3050,
		},
		["Pearl-clasped Cloak"] = {
			["mr"] = 1100,
			["cc"] = 4,
			["id"] = "5542:0:0:0:0",
			["H3219"] = 1100,
			["sc"] = 1,
		},
		["Red Linen Bag"] = {
			["mr"] = 297,
			["H3219"] = 297,
		},
		["Cadet Vest of Stamina"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Khan's Legguards"] = {
			["mr"] = 18000,
			["H3219"] = 18000,
		},
		["Pattern: Barbaric Gloves"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Recipe: Elixir of Minor Agility"] = {
			["H3223"] = 794,
			["mr"] = 794,
			["sc"] = 6,
			["id"] = "2553:0:0:0:0",
			["cc"] = 9,
		},
		["Trueshot Bow of the Whale"] = {
			["mr"] = 10017,
			["H3219"] = 10017,
		},
		["Moss Agate"] = {
			["mr"] = 680,
			["sc"] = 0,
			["id"] = "1206:0:0:0:0",
			["H3219"] = 680,
			["cc"] = 7,
		},
		["Bard's Bracers of the Eagle"] = {
			["mr"] = 860,
			["H3219"] = 860,
		},
		["Bard's Tunic of the Whale"] = {
			["mr"] = 950,
			["H3219"] = 950,
		},
		["Cured Ham Steak"] = {
			["mr"] = 539,
			["H3219"] = 539,
		},
		["Glimmering Flamberge of Agility"] = {
			["mr"] = 15500,
			["H3219"] = 15500,
		},
		["Native Pants of Healing"] = {
			["mr"] = 1288,
			["H3219"] = 1288,
		},
		["Birchwood Maul of the Eagle"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Greenweave Cloak of Healing"] = {
			["mr"] = 950,
			["H3219"] = 950,
		},
		["Durable Robe of Intellect"] = {
			["mr"] = 14998,
			["H3219"] = 14998,
		},
		["Pattern: Gray Woolen Robe"] = {
			["mr"] = 1500,
			["cc"] = 9,
			["id"] = "2601:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 1500,
		},
		["Schematic: EZ-Thro Dynamite"] = {
			["mr"] = 348,
			["H3219"] = 348,
		},
		["Shimmering Stave of the Whale"] = {
			["mr"] = 2322,
			["H3219"] = 2322,
		},
		["Militant Shortsword of the Monkey"] = {
			["mr"] = 5599,
			["H3219"] = 5599,
		},
		["Exquisite Flamberge of the Eagle"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Sorcerer Cloak of the Whale"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Rawhide Cloak"] = {
			["mr"] = 830,
			["H3219"] = 830,
		},
		["Prospector Axe"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Warden's Wizard Hat"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Forest Leather Belt"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Archer's Bracers of the Whale"] = {
			["mr"] = 5262,
			["H3219"] = 5262,
		},
		["Gleaming Claymore of the Bear"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Shadowhide Two-handed Sword"] = {
			["mr"] = 6599,
			["H3219"] = 6599,
		},
		["Bandit Cloak of Defense"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Infiltrator Bracers of Nature's Wrath"] = {
			["mr"] = 2950,
			["H3219"] = 2950,
		},
		["Green Whelp Scale"] = {
			["mr"] = 378,
			["H3219"] = 378,
		},
		["Silvered Bronze Shoulders"] = {
			["mr"] = 7315,
			["H3219"] = 7315,
		},
		["Spider Ichor"] = {
			["mr"] = 16,
			["H3219"] = 16,
		},
		["Infantry Leggings of the Gorilla"] = {
			["mr"] = 606,
			["H3219"] = 606,
		},
		["Gray Woolen Robe"] = {
			["mr"] = 3000,
			["cc"] = 4,
			["id"] = "2585:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 3000,
		},
		["Silver Skeleton Key"] = {
			["mr"] = 84,
			["H3219"] = 84,
		},
		["Green Hills of Stranglethorn - Page 1"] = {
			["mr"] = 592,
			["cc"] = 15,
			["id"] = "2725:0:0:0:0",
			["H3219"] = 592,
			["sc"] = 0,
		},
		["Fighter Broadsword of Strength"] = {
			["mr"] = 8910,
			["H3219"] = 8910,
		},
		["Coyote Meat"] = {
			["mr"] = 396,
			["H3219"] = 396,
		},
		["Pattern: Crimson Silk Shoulders"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Schematic: Masterwork Target Dummy"] = {
			["mr"] = 22221,
			["sc"] = 3,
			["id"] = "16046:0:0:0:0",
			["H3224"] = 22221,
			["cc"] = 9,
		},
		["Veteran Leggings"] = {
			["mr"] = 595,
			["H3219"] = 595,
		},
		["Silver-thread Gloves"] = {
			["mr"] = 1498,
			["H3219"] = 1498,
		},
		["Long Elegant Feather"] = {
			["mr"] = 894,
			["sc"] = 0,
			["id"] = "4589:0:0:0:0",
			["H3219"] = 894,
			["cc"] = 15,
		},
		["Ivy Orb of the Whale"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Scaled Leather Headband of the Eagle"] = {
			["mr"] = 8798,
			["H3219"] = 8798,
		},
		["Ritual Leggings of the Whale"] = {
			["mr"] = 1403,
			["H3219"] = 1403,
		},
		["Blood Ring"] = {
			["mr"] = 9458,
			["H3219"] = 9458,
		},
		["Star Belt"] = {
			["mr"] = 85616,
			["H3219"] = 85616,
		},
		["Gorilla Fang"] = {
			["mr"] = 284,
			["H3219"] = 284,
		},
		["Superior Cloak of Defense"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Insignia Leggings"] = {
			["mr"] = 9499,
			["H3219"] = 9499,
		},
		["Barbaric Shoulders"] = {
			["mr"] = 2699,
			["H3219"] = 2699,
		},
		["Fine Leather Tunic"] = {
			["mr"] = 735,
			["H3219"] = 735,
		},
		["Bard's Bracers of the Owl"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Regal Cloak of Arcane Wrath"] = {
			["mr"] = 13000,
			["H3219"] = 13000,
		},
		["Mithril Scale Pants"] = {
			["mr"] = 12100,
			["H3219"] = 12100,
		},
		["Goblin Nutcracker of the Monkey"] = {
			["mr"] = 24999,
			["H3219"] = 24999,
		},
		["Superior Bracers of Agility"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Chief Brigadier Cloak"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Raw Greater Sagefish"] = {
			["mr"] = 497,
			["H3219"] = 497,
		},
		["Linen Bandage"] = {
			["mr"] = 10,
			["sc"] = 0,
			["id"] = "1251:0:0:0:0",
			["H3219"] = 10,
			["cc"] = 0,
		},
		["Gypsy Trousers of the Owl"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Elder's Amber Stave of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Ranger Shoulders of the Monkey"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Grim Reaper"] = {
			["mr"] = 54499,
			["H3219"] = 54499,
		},
		["Wool Bandage"] = {
			["mr"] = 39,
			["sc"] = 0,
			["id"] = "3530:0:0:0:0",
			["H3224"] = 39,
			["cc"] = 0,
		},
		["Archer's Gloves of the Monkey"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Scaled Cloak of the Eagle"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Celestial Bindings of Fiery Wrath"] = {
			["mr"] = 50431,
			["cc"] = 4,
			["id"] = "14311:0:0:1888:0",
			["sc"] = 1,
			["H3220"] = 50431,
		},
		["Elixir of Greater Water Breathing"] = {
			["H3223"] = 1997,
			["mr"] = 1997,
			["cc"] = 0,
			["id"] = "18294:0:0:0:0",
			["sc"] = 0,
		},
		["Lesser Nether Essence"] = {
			["mr"] = 4700,
			["H3219"] = 4700,
		},
		["Smoldering Pants"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Hillman's Leather Vest"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Aboriginal Loincloth of Fiery Wrath"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Ballast Maul of Power"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Curve-bladed Ripper"] = {
			["mr"] = 99500,
			["H3219"] = 99500,
		},
		["Barbarian War Axe of Agility"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Archer's Jerkin of Agility"] = {
			["mr"] = 60000,
			["H3219"] = 60000,
		},
		["Archer's Belt of the Wolf"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Sentinel Gloves of the Whale"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Sturdy Quarterstaff of Fiery Wrath"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Archer's Belt of Intellect"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Elixir of Demonslaying"] = {
			["mr"] = 7500,
			["cc"] = 0,
			["id"] = "9224:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 7500,
		},
		["Nobles Brand of the Monkey"] = {
			["mr"] = 26900,
			["H3219"] = 26900,
		},
		["Grunt Axe of Power"] = {
			["mr"] = 2495,
			["H3219"] = 2495,
		},
		["Archer's Gloves of Healing"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Inscribed Leather Boots"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Lower Map Fragment"] = {
			["mr"] = 5699,
			["cc"] = 12,
			["id"] = "9252:0:0:0:0",
			["H3216"] = 5699,
			["sc"] = 0,
		},
		["Thick Scale Sabatons of the Bear"] = {
			["mr"] = 6712,
			["H3219"] = 6712,
		},
		["Iridescent Pearl"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Staunch Hammer of Power"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Scouting Bracers of the Owl"] = {
			["mr"] = 1595,
			["H3219"] = 1595,
		},
		["Headstriker Sword of the Eagle"] = {
			["mr"] = 34452,
			["H3219"] = 34452,
		},
		["Trueshot Bow of the Falcon"] = {
			["mr"] = 27588,
			["H3219"] = 27588,
		},
		["Scroll of Strength II"] = {
			["mr"] = 439,
			["H3219"] = 439,
		},
		["Recipe: Kaldorei Spider Kabob"] = {
			["mr"] = 9230,
			["H3219"] = 9230,
		},
		["Symbolic Crest"] = {
			["mr"] = 14999,
			["H3219"] = 14999,
		},
		["Lupine Leggings of the Wolf"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Defender Girdle of the Monkey"] = {
			["mr"] = 14299,
			["H3219"] = 14299,
		},
		["Gossamer Gloves of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Buccaneer's Robes of the Eagle"] = {
			["mr"] = 12511,
			["H3219"] = 12511,
		},
		["Lupine Leggings of Agility"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Pattern: Spider Silk Slippers"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Shimmering Gloves of the Whale"] = {
			["mr"] = 1799,
			["H3219"] = 1799,
		},
		["Cat Carrier (Siamese)"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Buccaneer's Vest of Stamina"] = {
			["mr"] = 3305,
			["H3219"] = 3305,
		},
		["Sorcerer Robe of the Owl"] = {
			["mr"] = 16344,
			["H3219"] = 16344,
		},
		["Larval Acid"] = {
			["mr"] = 24800,
			["H3219"] = 24800,
		},
		["Dervish Gloves of the Eagle"] = {
			["mr"] = 1665,
			["H3219"] = 1665,
		},
		["Durable Pants of the Owl"] = {
			["mr"] = 5985,
			["H3219"] = 5985,
		},
		["Archer's Trousers of Agility"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Bandit Pants of the Whale"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Ivycloth Pants of Spirit"] = {
			["mr"] = 3300,
			["H3219"] = 3300,
		},
		["Lambent Scale Shield"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Gypsy Tunic of Agility"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Barbaric Cloth Boots"] = {
			["mr"] = 1099,
			["H3219"] = 1099,
		},
		["Soldier's Armor of Power"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Schematic: Thorium Tube"] = {
			["mr"] = 29200,
			["sc"] = 3,
			["id"] = "16047:0:0:0:0",
			["H3224"] = 29200,
			["cc"] = 9,
		},
		["Simple Britches of the Whale"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Heavy Mithril Gauntlet"] = {
			["mr"] = 7999,
			["H3219"] = 7999,
		},
		["Ice Cold Milk"] = {
			["mr"] = 22,
			["H3219"] = 22,
		},
		["Deadmines Cleaver"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Shimmering Armor of the Eagle"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Soldier's Armor of Stamina"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Ogremind Ring"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Smooth Pebble"] = {
			["mr"] = 4,
			["H3219"] = 4,
		},
		["Sage's Mantle of Frozen Wrath"] = {
			["mr"] = 29800,
			["H3219"] = 29800,
		},
		["Severing Axe of the Boar"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Sniper Rifle of the Owl"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Greenweave Robe of Frozen Wrath"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Red Mageweave Bag"] = {
			["mr"] = 11544,
			["H3219"] = 11544,
		},
		["Pillager's Cloak of the Bear"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Glyphed Mitts"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Embossed Leather Vest"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Gypsy Buckler of the Bear"] = {
			["mr"] = 363,
			["H3219"] = 363,
		},
		["Monk's Staff of Nature's Wrath"] = {
			["mr"] = 35211,
			["H3219"] = 35211,
		},
		["Elixir of Minor Defense"] = {
			["H3223"] = 14,
			["mr"] = 14,
			["sc"] = 0,
			["id"] = "5997:0:0:0:0",
			["cc"] = 0,
		},
		["Goretusk Liver Pie"] = {
			["mr"] = 47,
			["H3219"] = 47,
		},
		["Pathfinder Cloak of Stamina"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bard's Tunic of the Monkey"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Wirt's Third Leg"] = {
			["mr"] = 28000,
			["H3219"] = 28000,
		},
		["Shimmering Bracers of Fiery Wrath"] = {
			["mr"] = 2000,
			["cc"] = 4,
			["id"] = "6563:0:0:1877:0",
			["sc"] = 1,
			["H3220"] = 2000,
		},
		["Pattern: Red Mageweave Shoulders"] = {
			["mr"] = 19000,
			["H3219"] = 19000,
		},
		["Pattern: Green Whelp Armor"] = {
			["mr"] = 3960,
			["H3219"] = 3960,
		},
		["Conjurer's Cloak of Frozen Wrath"] = {
			["mr"] = 14900,
			["H3219"] = 14900,
		},
		["Banded Leggings of the Monkey"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Burnt Cloak"] = {
			["mr"] = 122,
			["H3219"] = 122,
		},
		["Aboriginal Gloves of the Eagle"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Disciple's Robe of the Whale"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Outrunner's Slippers of the Bear"] = {
			["mr"] = 1813,
			["H3219"] = 1813,
		},
		["Lesser Moonstone"] = {
			["mr"] = 729,
			["sc"] = 0,
			["id"] = "1705:0:0:0:0",
			["H3219"] = 729,
			["cc"] = 7,
		},
		["Necklace of Calisea"] = {
			["mr"] = 67045,
			["H3219"] = 67045,
		},
		["Raider's Chestpiece of the Monkey"] = {
			["mr"] = 1495,
			["H3219"] = 1495,
		},
		["Blackrock Gauntlets"] = {
			["mr"] = 689,
			["H3219"] = 689,
		},
		["Glimmering Mail Coif"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Darkmist Wizard Hat of the Owl"] = {
			["mr"] = 65000,
			["H3219"] = 65000,
		},
		["Kaleidoscope Chain"] = {
			["mr"] = 51000,
			["H3219"] = 51000,
		},
		["Pioneer Trousers of the Gorilla"] = {
			["mr"] = 400,
			["H3219"] = 400,
		},
		["Durable Shoulders of the Whale"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Bolt of Mageweave"] = {
			["mr"] = 3099,
			["H3219"] = 3099,
		},
		["Battering Hammer of the Monkey"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Renegade Shield of Strength"] = {
			["mr"] = 8997,
			["H3219"] = 8997,
		},
		["Twilight Belt of the Owl"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Formula: Enchant Bracer - Minor Strength"] = {
			["mr"] = 101,
			["H3219"] = 101,
		},
		["Medicine Staff of Fiery Wrath"] = {
			["mr"] = 2461,
			["H3219"] = 2461,
		},
		["Limited Invulnerability Potion"] = {
			["mr"] = 34850,
			["H3219"] = 34850,
		},
		["Defender Boots of the Tiger"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Clay Ring of the Bear"] = {
			["mr"] = 6529,
			["H3219"] = 6529,
		},
		["Raider's Boots of the Boar"] = {
			["mr"] = 4799,
			["H3219"] = 4799,
		},
		["Handstitched Leather Belt"] = {
			["mr"] = 45,
			["H3219"] = 45,
		},
		["Willow Cape of Spirit"] = {
			["mr"] = 1744,
			["H3219"] = 1744,
		},
		["Pattern: Big Voodoo Mask"] = {
			["mr"] = 8200,
			["H3219"] = 8200,
		},
		["Blindweed"] = {
			["mr"] = 1460,
			["H3219"] = 1460,
		},
		["Captain's Bracers of Nature's Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Cadet Shield of the Boar"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Knight's Girdle of Strength"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Black Diamond"] = {
			["mr"] = 98,
			["cc"] = 15,
			["id"] = "11754:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 98,
		},
		["Merc Sword of Stamina"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Gemmed Copper Gauntlets of the Monkey"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Sturdy Quarterstaff of the Boar"] = {
			["mr"] = 735,
			["H3219"] = 735,
		},
		["Dervish Gloves of the Owl"] = {
			["mr"] = 1655,
			["H3219"] = 1655,
		},
		["Opaque Wand"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Gypsy Tunic of the Whale"] = {
			["mr"] = 595,
			["H3219"] = 595,
		},
		["Imperial Leather Bracers"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Dwarven Mild"] = {
			["mr"] = 42,
			["H3219"] = 42,
		},
		["Elixir of Greater Intellect"] = {
			["H3223"] = 1970,
			["mr"] = 1970,
			["cc"] = 0,
			["id"] = "9179:0:0:0:0",
			["sc"] = 0,
		},
		["Dark Iron Residue"] = {
			["mr"] = 206,
			["cc"] = 15,
			["id"] = "18945:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 206,
		},
		["Cavalier Two-hander of the Bear"] = {
			["mr"] = 8480,
			["H3219"] = 8480,
		},
		["Glimmering Flamberge of the Boar"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Trueshot Bow of the Tiger"] = {
			["mr"] = 17500,
			["H3219"] = 17500,
		},
		["Buccaneer's Orb of the Whale"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Large Brilliant Shard"] = {
			["H3223"] = 30000,
			["mr"] = 30000,
			["cc"] = 7,
			["id"] = "14344:0:0:0:0",
			["sc"] = 0,
		},
		["Elder's Bracers of Healing"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Bandit Bracers of the Eagle"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Savannah Ring of Agility"] = {
			["mr"] = 13900,
			["H3219"] = 13900,
		},
		["Training Sword of Stamina"] = {
			["mr"] = 1317,
			["H3219"] = 1317,
		},
		["Ritual Cape of Fiery Wrath"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Phalanx Shield of the Bear"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Bloodforged Belt of the Eagle"] = {
			["mr"] = 28100,
			["H3219"] = 28100,
		},
		["Manual: Strong Anti-Venom"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Phalanx Headguard of Stamina"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Twin-bladed Axe of the Bear"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Stalvan's Reaper"] = {
			["mr"] = 22500,
			["H3219"] = 22500,
		},
		["Dervish Tunic of the Eagle"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Magician Staff of Intellect"] = {
			["mr"] = 12018,
			["H3219"] = 12018,
		},
		["Severing Axe of the Monkey"] = {
			["mr"] = 740,
			["H3219"] = 740,
		},
		["Scouting Trousers of Healing"] = {
			["mr"] = 10101,
			["H3219"] = 10101,
		},
		["Conjurer's Mantle of Intellect"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Infantry Shield of Defense"] = {
			["mr"] = 898,
			["H3219"] = 898,
		},
		["Indurium Ore"] = {
			["mr"] = 496,
			["H3219"] = 496,
		},
		["Dervish Tunic of Intellect"] = {
			["mr"] = 4444,
			["H3219"] = 4444,
		},
		["Raider's Shield of the Bear"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Champion's Bracers of the Eagle"] = {
			["mr"] = 14242,
			["H3219"] = 14242,
		},
		["Gnoll Casting Gloves"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Living Essence"] = {
			["mr"] = 13500,
			["H3219"] = 13500,
		},
		["Devout Belt"] = {
			["H3224"] = 169000,
			["cc"] = 4,
			["id"] = "16696:0:0:0:0",
			["sc"] = 1,
			["mr"] = 169000,
		},
		["Durable Cape of Fiery Wrath"] = {
			["mr"] = 10000,
			["cc"] = 4,
			["id"] = "9822:0:0:1880:0",
			["sc"] = 1,
			["H3220"] = 10000,
		},
		["Superior Tunic of the Wolf"] = {
			["mr"] = 3300,
			["H3219"] = 3300,
		},
		["Braincage"] = {
			["mr"] = 47200,
			["cc"] = 4,
			["id"] = "12549:0:0:0:0",
			["sc"] = 3,
			["H3220"] = 47200,
		},
		["Scalping Tomahawk of Power"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Forester's Axe of Stamina"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Gloom Reaper of the Tiger"] = {
			["mr"] = 11999,
			["H3219"] = 11999,
		},
		["Geomancer's Cloak of Spirit"] = {
			["mr"] = 5075,
			["H3219"] = 5075,
		},
		["Superior Shoulders of the Owl"] = {
			["mr"] = 3899,
			["H3219"] = 3899,
		},
		["Buccaneer's Orb of the Falcon"] = {
			["mr"] = 2438,
			["H3219"] = 2438,
		},
		["Sentinel Bracers of the Owl"] = {
			["mr"] = 7602,
			["H3219"] = 7602,
		},
		["Glowing Scorpid Blood"] = {
			["mr"] = 2099,
			["sc"] = 0,
			["id"] = "19933:0:0:0:0",
			["H3219"] = 2099,
			["cc"] = 15,
		},
		["Gypsy Tunic of Spirit"] = {
			["mr"] = 550,
			["H3219"] = 550,
		},
		["Trueshot Bow of Stamina"] = {
			["mr"] = 53500,
			["H3219"] = 53500,
		},
		["Jagged Star of Power"] = {
			["mr"] = 4998,
			["H3219"] = 4998,
		},
		["White Linen Robe"] = {
			["mr"] = 194,
			["H3219"] = 194,
		},
		["Schematic: Gnomish Universal Remote"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Battleforge Armor of Strength"] = {
			["mr"] = 6999,
			["H3219"] = 6999,
		},
		["Expert Fishing - The Bass and You"] = {
			["mr"] = 11599,
			["H3219"] = 11599,
		},
		["Wolf Bracers"] = {
			["mr"] = 7399,
			["H3219"] = 7399,
		},
		["Archer's Trousers of the Eagle"] = {
			["mr"] = 8499,
			["H3219"] = 8499,
		},
		["Formula: Enchant Weapon - Demonslaying"] = {
			["mr"] = 9900,
			["cc"] = 9,
			["id"] = "11208:0:0:0:0",
			["sc"] = 8,
			["H3220"] = 9900,
		},
		["Ivycloth Mantle of the Eagle"] = {
			["mr"] = 10020,
			["H3219"] = 10020,
		},
		["Raider's Gauntlets of the Bear"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Watcher's Handwraps of Healing"] = {
			["mr"] = 9920,
			["H3219"] = 9920,
		},
		["Scouting Bracers of the Wolf"] = {
			["mr"] = 9309,
			["H3219"] = 9309,
		},
		["Sage's Cloth of Stamina"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Brigade Defender of Stamina"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Battle Slayer of the Boar"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Combatant Claymore"] = {
			["L3219"] = 19800,
			["cc"] = 2,
			["id"] = "2877:0:0:0:0",
			["H3219"] = 19999,
			["sc"] = 8,
			["mr"] = 19800,
		},
		["Cerulean Ring of the Owl"] = {
			["mr"] = 16762,
			["H3219"] = 16762,
		},
		["Willow Pants of Spirit"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Gauntlets of Ogre Strength"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Blue Overalls"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Superior Bracers of Stamina"] = {
			["mr"] = 13997,
			["H3219"] = 13997,
		},
		["Pattern: Murloc Scale Breastplate"] = {
			["mr"] = 166,
			["H3219"] = 166,
		},
		["Recipe: Free Action Potion"] = {
			["mr"] = 7785,
			["sc"] = 6,
			["id"] = "5642:0:0:0:0",
			["H3219"] = 7785,
			["cc"] = 9,
		},
		["Fortified Chain of the Monkey"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Raw Redgill"] = {
			["mr"] = 259,
			["H3219"] = 259,
		},
		["Plans: Shadow Crescent Axe"] = {
			["mr"] = 1926,
			["H3219"] = 1926,
		},
		["Ranger Leggings of the Owl"] = {
			["mr"] = 24620,
			["H3219"] = 24620,
		},
		["Bloodwoven Cloak of Fiery Wrath"] = {
			["mr"] = 49999,
			["cc"] = 4,
			["id"] = "14261:0:0:1884:0",
			["sc"] = 1,
			["H3220"] = 49999,
		},
		["Flesh Eating Worm"] = {
			["mr"] = 237,
			["H3219"] = 237,
		},
		["Scouting Cloak of Agility"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Glimmering Flamberge of the Monkey"] = {
			["mr"] = 17399,
			["H3219"] = 17399,
		},
		["Stone Hammer of the Monkey"] = {
			["mr"] = 34668,
			["H3219"] = 34668,
		},
		["Raider's Belt of the Whale"] = {
			["mr"] = 1485,
			["H3219"] = 1485,
		},
		["Bard's Buckler of Stamina"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Shimmering Bracers of the Owl"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Worn Dragonscale"] = {
			["H3223"] = 730,
			["mr"] = 730,
			["cc"] = 15,
			["id"] = "8165:0:0:0:0",
			["sc"] = 0,
		},
		["Bright Belt"] = {
			["mr"] = 1380,
			["H3219"] = 1380,
		},
		["Ridge Cleaver of Strength"] = {
			["mr"] = 5499,
			["H3219"] = 5499,
		},
		["Pagan Wraps of Intellect"] = {
			["mr"] = 7799,
			["H3219"] = 7799,
		},
		["Fine Leather Belt"] = {
			["mr"] = 198,
			["H3219"] = 198,
		},
		["Phalanx Breastplate of Strength"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Righteous Gloves of the Tiger"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Dervish Boots of the Whale"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Superior Shoulders of Agility"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Infiltrator Armor of the Monkey"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Training Sword of the Tiger"] = {
			["mr"] = 1160,
			["H3219"] = 1160,
		},
		["Fortified Leggings of the Monkey"] = {
			["mr"] = 3980,
			["H3219"] = 3980,
		},
		["Meadow Ring of Eluding"] = {
			["mr"] = 5555555,
			["H3219"] = 5555555,
		},
		["Pattern: Blue Linen Vest"] = {
			["mr"] = 1772,
			["H3219"] = 1772,
		},
		["Knight's Headguard of the Tiger"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Birchwood Maul of Stamina"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Tracker's Wristguards of the Eagle"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Pattern: Big Voodoo Robe"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Staff of the Shade"] = {
			["mr"] = 51000,
			["H3219"] = 51000,
		},
		["Cadet Leggings of the Eagle"] = {
			["mr"] = 957,
			["H3219"] = 957,
		},
		["Stout Battlehammer of the Bear"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Priest's Mace of Power"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Emblazoned Shoulders"] = {
			["mr"] = 2277,
			["H3219"] = 2277,
		},
		["Savage Axe of the Wolf"] = {
			["mr"] = 21400,
			["H3219"] = 21400,
		},
		["Jouster's Gauntlets"] = {
			["mr"] = 4873,
			["H3219"] = 4873,
		},
		["Jadefire Epaulets of the Monkey"] = {
			["mr"] = 99999,
			["H3219"] = 99999,
		},
		["Soft Bushy Tail"] = {
			["mr"] = 750,
			["H3219"] = 750,
		},
		["Ridge Cleaver of the Bear"] = {
			["mr"] = 25255,
			["H3219"] = 25255,
		},
		["Cured Thick Hide"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Gypsy Bands"] = {
			["mr"] = 199,
			["H3219"] = 199,
		},
		["Buccaneer's Vest of the Eagle"] = {
			["mr"] = 7312,
			["H3219"] = 7312,
		},
		["Ironweaver"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Schematic: Mechanical Dragonling"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Sacrificial Kris of Power"] = {
			["mr"] = 34500,
			["H3219"] = 34500,
		},
		["Bard's Boots of the Whale"] = {
			["mr"] = 838,
			["H3219"] = 838,
		},
		["Raider's Belt of the Monkey"] = {
			["mr"] = 975,
			["H3219"] = 975,
		},
		["Huntsman's Belt of the Eagle"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Recipe: Jungle Stew"] = {
			["mr"] = 26082,
			["H3219"] = 26082,
		},
		["Small Black Pouch"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Swift Boots"] = {
			["mr"] = 8700,
			["H3219"] = 8700,
		},
		["Leaden Mace of the Bear"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Buccaneer's Bracers of the Eagle"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Fortified Leggings of Power"] = {
			["mr"] = 4053,
			["H3219"] = 4053,
		},
		["Glimmering Shield"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Barbaric Battle Axe of Stamina"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Buccaneer's Pants of the Falcon"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Phalanx Shield of the Boar"] = {
			["mr"] = 12990,
			["H3219"] = 12990,
		},
		["Twilight Belt of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Amber Hoop of Frost Resistance"] = {
			["mr"] = 10800,
			["H3219"] = 10800,
		},
		["Silk Headband"] = {
			["mr"] = 1339,
			["H3219"] = 1339,
		},
		["Buccaneer's Vest of the Whale"] = {
			["mr"] = 3099,
			["H3219"] = 3099,
		},
		["Gypsy Buckler of the Monkey"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Disciple's Robe of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Lupine Vest of the Whale"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Smoothbore Gun"] = {
			["mr"] = 16469,
			["H3219"] = 16469,
		},
		["Scouting Gloves of Defense"] = {
			["mr"] = 4220,
			["H3219"] = 4220,
		},
		["Copper Tube"] = {
			["mr"] = 125,
			["H3219"] = 125,
		},
		["Dark Runner Boots"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Sorcerer Pants of Fiery Wrath"] = {
			["mr"] = 21938,
			["H3219"] = 21938,
		},
		["Stonescale Eel"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Superior Gloves of the Eagle"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Dusky Bracers"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Twilight Cape of the Owl"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Sanguine Sandals"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Dervish Gloves of the Wolf"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["White Swashbuckler's Shirt"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Valorous Wristguards"] = {
			["H3224"] = 20000,
			["cc"] = 4,
			["id"] = "8273:0:0:0:0",
			["sc"] = 4,
			["mr"] = 20000,
		},
		["Pattern: White Bandit Mask"] = {
			["mr"] = 7400,
			["H3219"] = 7400,
		},
		["Soldier's Gauntlets of the Eagle"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Elder's Gloves of the Whale"] = {
			["mr"] = 5031,
			["H3219"] = 5031,
		},
		["Shadow Wand"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Leaden Mace of Nature's Wrath"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Jacinth Circle of Arcane Resistance"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Libram of Constitution"] = {
			["mr"] = 710000,
			["H3219"] = 710000,
		},
		["Superior Boots of the Gorilla"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Pattern: Stylish Blue Shirt"] = {
			["mr"] = 1085,
			["H3219"] = 1085,
		},
		["Woolen Bag"] = {
			["mr"] = 599,
			["cc"] = 1,
			["id"] = "4240:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 599,
		},
		["Swiftness Potion"] = {
			["mr"] = 366,
			["sc"] = 0,
			["id"] = "2459:0:0:0:0",
			["H3219"] = 366,
			["cc"] = 0,
		},
		["Frenzied Striker"] = {
			["mr"] = 150000,
			["H3219"] = 150000,
		},
		["Bandit Jerkin of Agility"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Willow Gloves of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Dense Stone"] = {
			["mr"] = 3398,
			["H3219"] = 3398,
		},
		["Iron Shield Spike"] = {
			["mr"] = 4700,
			["H3219"] = 4700,
		},
		["Morrowgrain"] = {
			["mr"] = 6200,
			["cc"] = 7,
			["id"] = "11040:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 6200,
		},
		["Greater Mana Potion"] = {
			["mr"] = 700,
			["cc"] = 0,
			["id"] = "6149:0:0:0:0",
			["H3224"] = 700,
			["sc"] = 0,
		},
		["Amethyst Band of Fire Resistance"] = {
			["mr"] = 11700,
			["sc"] = 0,
			["id"] = "11971:0:0:1410:0",
			["H3224"] = 11700,
			["cc"] = 4,
		},
		["Ritual Sandals of Spirit"] = {
			["mr"] = 3977,
			["H3219"] = 3977,
		},
		["Imperial Leather Helm"] = {
			["mr"] = 9500,
			["H3219"] = 9500,
		},
		["Battleforge Wristguards of Stamina"] = {
			["mr"] = 4040,
			["H3219"] = 4040,
		},
		["Battering Hammer of the Bear"] = {
			["mr"] = 7023,
			["H3219"] = 7023,
		},
		["Bard's Belt of the Boar"] = {
			["mr"] = 1563,
			["H3219"] = 1563,
		},
		["Buccaneer's Orb of the Owl"] = {
			["mr"] = 2807,
			["H3219"] = 2807,
		},
		["Defender Girdle of the Gorilla"] = {
			["mr"] = 3699,
			["H3219"] = 3699,
		},
		["Greater Scythe of the Tiger"] = {
			["mr"] = 19500,
			["H3219"] = 19500,
		},
		["Acrobatic Staff of the Owl"] = {
			["mr"] = 13800,
			["H3219"] = 13800,
		},
		["Ritual Leggings of the Eagle"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Essence of Earth"] = {
			["mr"] = 94499,
			["H3219"] = 94499,
		},
		["Grizzly Buckler of the Wolf"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Silver Defias Belt"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Exquisite Flamberge of the Monkey"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Small Egg"] = {
			["mr"] = 20,
			["H3219"] = 20,
		},
		["Iron Strut"] = {
			["mr"] = 955,
			["H3219"] = 955,
		},
		["Defender Tunic of the Bear"] = {
			["mr"] = 1968,
			["H3219"] = 1968,
		},
		["Scaled Leather Bracers of Stamina"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Scouting Buckler of the Gorilla"] = {
			["mr"] = 3095,
			["H3219"] = 3095,
		},
		["Disciple's Stein of Fiery Wrath"] = {
			["mr"] = 1185,
			["H3219"] = 1185,
		},
		["Scaled Leather Bracers of the Falcon"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Pattern: Enchanter's Cowl"] = {
			["mr"] = 4699,
			["H3219"] = 4699,
		},
		["Rigid Cape of Intellect"] = {
			["mr"] = 1853,
			["H3219"] = 1853,
		},
		["Cavalier Two-hander of the Boar"] = {
			["mr"] = 6499,
			["H3219"] = 6499,
		},
		["Tribal Vest"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Severing Axe of the Whale"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Bard's Boots of the Monkey"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Medicine Staff of Arcane Wrath"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Defender Gauntlets of Strength"] = {
			["mr"] = 3825,
			["H3219"] = 3825,
		},
		["Disciple's Stein of Frozen Wrath"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Venom Web Fang"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Buccaneer's Pants of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Ancestral Tunic"] = {
			["mr"] = 880,
			["H3219"] = 880,
		},
		["Dervish Boots of Power"] = {
			["mr"] = 5047,
			["H3219"] = 5047,
		},
		["Warbringer's Legguards of Power"] = {
			["mr"] = 19296,
			["H3219"] = 19296,
		},
		["Wild Leather Cloak of the Monkey"] = {
			["mr"] = 39900,
			["H3219"] = 39900,
		},
		["Formula: Smoking Heart of the Mountain"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Bandit Gloves of the Owl"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Huntsman's Bands of the Owl"] = {
			["mr"] = 13300,
			["H3219"] = 13300,
		},
		["Elder's Hat of Fiery Wrath"] = {
			["mr"] = 20000,
			["cc"] = 4,
			["L3220"] = 20000,
			["id"] = "7357:0:0:1888:0",
			["sc"] = 1,
			["H3220"] = 25000,
		},
		["Lambent Scale Legguards"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Archer's Cap of Stamina"] = {
			["mr"] = 12852,
			["H3219"] = 12852,
		},
		["Brutal War Axe of the Bear"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Battering Hammer of the Tiger"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Shimmering Trousers of the Eagle"] = {
			["mr"] = 4984,
			["H3219"] = 4984,
		},
		["Curved Dagger of Strength"] = {
			["mr"] = 710,
			["H3219"] = 710,
		},
		["Northern Shortsword of Strength"] = {
			["mr"] = 1895,
			["H3219"] = 1895,
		},
		["Superior Leggings of the Whale"] = {
			["mr"] = 2049,
			["H3219"] = 2049,
		},
		["Twin-bladed Axe of the Eagle"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Dokebi Boots"] = {
			["mr"] = 5807,
			["H3219"] = 5807,
		},
		["Crafted Heavy Shot"] = {
			["mr"] = 1,
			["H3219"] = 1,
		},
		["Soldier's Armor of Strength"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Superior Cloak of the Monkey"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Bow of Searing Arrows"] = {
			["mr"] = 1500000,
			["H3219"] = 1500000,
		},
		["Plans: Silvered Bronze Leggings"] = {
			["mr"] = 4400,
			["H3219"] = 4400,
		},
		["Jet Chain of the Boar"] = {
			["mr"] = 14500,
			["H3219"] = 14500,
		},
		["Insignia Gloves"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Nightsky Boots"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Scaled Leather Headband of Intellect"] = {
			["mr"] = 47424,
			["H3219"] = 47424,
		},
		["Grunt's Cape of the Bear"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Geomancer's Spaulders of the Eagle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Silver Bar"] = {
			["mr"] = 800,
			["cc"] = 7,
			["id"] = "2842:0:0:0:0",
			["H3219"] = 800,
			["sc"] = 0,
		},
		["Forester's Axe of the Monkey"] = {
			["mr"] = 5999,
			["H3219"] = 5999,
		},
		["Forest Cloak"] = {
			["mr"] = 1237,
			["H3219"] = 1237,
		},
		["Grizzly Bracers"] = {
			["mr"] = 198,
			["H3219"] = 198,
		},
		["Bear Meat"] = {
			["mr"] = 16,
			["H3219"] = 16,
		},
		["Jet Chain of the Gorilla"] = {
			["mr"] = 22038,
			["H3219"] = 22038,
		},
		["Recipe: Cooked Crab Claw"] = {
			["H3225"] = 174,
			["sc"] = 5,
			["id"] = "2698:0:0:0:0",
			["mr"] = 174,
			["cc"] = 9,
		},
		["Thunderwood"] = {
			["mr"] = 34486,
			["H3219"] = 34486,
		},
		["Sage's Pants of the Owl"] = {
			["mr"] = 6609,
			["H3219"] = 6609,
		},
		["Archer's Boots of the Falcon"] = {
			["mr"] = 9875,
			["H3219"] = 9875,
		},
		["Moccasins of the White Hare"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Silver-thread Rod"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Native Branch of Spirit"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Lupine Cord of Intellect"] = {
			["mr"] = 1285,
			["H3219"] = 1285,
		},
		["Ivycloth Sash of the Owl"] = {
			["mr"] = 7620,
			["H3219"] = 7620,
		},
		["Raider's Cloak of the Bear"] = {
			["mr"] = 570,
			["H3219"] = 570,
		},
		["Major Healing Potion"] = {
			["H3223"] = 4400,
			["mr"] = 9800,
			["sc"] = 0,
			["id"] = "13446:0:0:0:0",
			["cc"] = 0,
			["H3224"] = 9800,
		},
		["Mountainside Buckler"] = {
			["mr"] = 60000,
			["H3219"] = 60000,
		},
		["Plans: Deadly Bronze Poniard"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Archer's Boots of the Eagle"] = {
			["mr"] = 7900,
			["H3219"] = 7900,
		},
		["Twilight Pants of Fiery Wrath"] = {
			["mr"] = 46788,
			["H3219"] = 46788,
		},
		["Woodworking Gloves"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Monstrous War Axe of the Tiger"] = {
			["mr"] = 80000,
			["H3219"] = 80000,
		},
		["Runed Copper Bracers"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Twilight Mantle of the Eagle"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Linked Chain Shoulderpads"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Black Whelp Scale"] = {
			["mr"] = 25,
			["H3219"] = 25,
		},
		["Lupine Cord of the Whale"] = {
			["mr"] = 888,
			["H3219"] = 888,
		},
		["Inscribed Buckler"] = {
			["mr"] = 754,
			["H3219"] = 754,
		},
		["Willow Robe of Shadow Wrath"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Pattern: Tough Scorpid Helm"] = {
			["mr"] = 3298,
			["cc"] = 9,
			["id"] = "8402:0:0:0:0",
			["H3216"] = 3298,
			["sc"] = 1,
		},
		["Infiltrator Gloves of the Wolf"] = {
			["mr"] = 3800,
			["H3219"] = 3800,
		},
		["Cadet Vest of the Eagle"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Recipe: Dragonbreath Chili"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Raider Shortsword of Stamina"] = {
			["mr"] = 1425,
			["H3219"] = 1425,
		},
		["Captain's Bracers of Agility"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Oak Mallet of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["17 Pound Catfish"] = {
			["mr"] = 300,
			["H3219"] = 300,
		},
		["Curved Dagger of Shadow Wrath"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Elder's Boots of the Whale"] = {
			["mr"] = 4100,
			["H3219"] = 4100,
		},
		["Bonelink Bracers of the Owl"] = {
			["mr"] = 13062,
			["H3219"] = 13062,
		},
		["Dark Leather Pants"] = {
			["mr"] = 1189,
			["H3219"] = 1189,
		},
		["Burnt Leather Vest"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Infiltrator Bracers of Spirit"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Gypsy Buckler of the Tiger"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Cadet Vest of the Boar"] = {
			["mr"] = 1006,
			["H3219"] = 1006,
		},
		["Superior Gloves of Spirit"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Battleforge Boots of Defense"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Brutal War Axe of the Monkey"] = {
			["mr"] = 9969,
			["H3219"] = 9969,
		},
		["Gigantic War Axe of the Tiger"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Raider's Belt of the Eagle"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Scouting Cloak of the Owl"] = {
			["mr"] = 1899,
			["H3219"] = 1899,
		},
		["Rough Weightstone"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Elixir of Minor Agility"] = {
			["H3223"] = 413,
			["mr"] = 413,
			["sc"] = 0,
			["id"] = "2457:0:0:0:0",
			["cc"] = 0,
		},
		["Stonecutter Claymore of Strength"] = {
			["mr"] = 13999,
			["H3219"] = 13999,
		},
		["Conjurer's Vest of Shadow Wrath"] = {
			["mr"] = 15500,
			["H3219"] = 15500,
		},
		["Feral Buckler of the Bear"] = {
			["mr"] = 1747,
			["H3219"] = 1747,
		},
		["Raider's Cloak of the Eagle"] = {
			["mr"] = 1215,
			["H3219"] = 1215,
		},
		["Jaina's Firestarter"] = {
			["mr"] = 390000,
			["H3219"] = 390000,
		},
		["Sorcerer Drape of Intellect"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Battle Knife of Power"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Archer's Belt of the Whale"] = {
			["mr"] = 3585,
			["H3219"] = 3585,
		},
		["Dusky Belt"] = {
			["mr"] = 8300,
			["H3219"] = 8300,
		},
		["Greater Maul of the Monkey"] = {
			["mr"] = 39998,
			["H3219"] = 39998,
		},
		["Field Plate Vambraces of the Bear"] = {
			["mr"] = 14000,
			["H3219"] = 14000,
		},
		["Superior Bracers of the Eagle"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Phalanx Breastplate of the Bear"] = {
			["mr"] = 10725,
			["H3219"] = 10725,
		},
		["Rageclaw Cloak of the Monkey"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Imposing Pants of the Monkey"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Renegade Bracers of the Bear"] = {
			["mr"] = 8950,
			["H3219"] = 8950,
		},
		["Green Carapace Shield"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Cutthroat's Mantle of the Eagle"] = {
			["mr"] = 7587,
			["H3219"] = 7587,
		},
		["Mountain Silversage"] = {
			["mr"] = 5400,
			["H3222"] = 4799,
			["id"] = "13465:0:0:0:0",
			["H3224"] = 5400,
			["sc"] = 0,
			["cc"] = 7,
		},
		["Infiltrator Armor of Agility"] = {
			["mr"] = 13400,
			["H3219"] = 13400,
		},
		["Bright Cloak"] = {
			["mr"] = 690,
			["H3219"] = 690,
		},
		["Ichor of Undeath"] = {
			["mr"] = 995,
			["cc"] = 5,
			["id"] = "7972:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 995,
		},
		["Renegade Cloak of the Bear"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Magician Staff of Healing"] = {
			["mr"] = 6020,
			["H3219"] = 6020,
		},
		["Recipe: Beer Basted Boar Ribs"] = {
			["mr"] = 845,
			["H3219"] = 845,
		},
		["Brown Linen Vest"] = {
			["mr"] = 39,
			["H3219"] = 39,
		},
		["Gloves of the Fang"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Elixir of Dream Vision"] = {
			["H3223"] = 23000,
			["mr"] = 23000,
			["sc"] = 0,
			["id"] = "9197:0:0:0:0",
			["cc"] = 0,
		},
		["Scorpashi Wristbands"] = {
			["mr"] = 9801,
			["H3219"] = 9801,
		},
		["Superior Leggings of the Bear"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Scouting Trousers of the Whale"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Soldier's Boots of the Bear"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Lupine Leggings of the Falcon"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bolt of Linen Cloth"] = {
			["mr"] = 66,
			["sc"] = 0,
			["id"] = "2996:0:0:0:0",
			["H3219"] = 66,
			["cc"] = 7,
		},
		["Bard's Trousers of the Falcon"] = {
			["mr"] = 743,
			["H3219"] = 743,
		},
		["Archer's Trousers of the Whale"] = {
			["mr"] = 12779,
			["H3219"] = 12779,
		},
		["Crushridge Bindings"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Willow Branch of the Eagle"] = {
			["mr"] = 1940,
			["H3219"] = 1940,
		},
		["Raptor Flesh"] = {
			["mr"] = 430,
			["sc"] = 0,
			["id"] = "12184:0:0:0:0",
			["H3219"] = 430,
			["cc"] = 7,
		},
		["Rageclaw Boots of the Monkey"] = {
			["mr"] = 16000,
			["sc"] = 2,
			["id"] = "15379:0:0:610:0",
			["H3224"] = 16000,
			["cc"] = 4,
		},
		["Conjurer's Gloves of the Owl"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Felcloth Robe"] = {
			["mr"] = 350000,
			["cc"] = 4,
			["id"] = "14106:0:0:0:0",
			["sc"] = 1,
			["H3226"] = 350000,
		},
		["Scaled Leather Leggings of the Monkey"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Bandit Boots of the Eagle"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Native Branch of Healing"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Sentry's Gloves of the Boar"] = {
			["mr"] = 4571,
			["H3219"] = 4571,
		},
		["Murphstar of the Monkey"] = {
			["mr"] = 14500,
			["H3219"] = 14500,
		},
		["Red Whelp Scale"] = {
			["mr"] = 114,
			["H3219"] = 114,
		},
		["Buccaneer's Pants of Spirit"] = {
			["mr"] = 1188,
			["H3219"] = 1188,
		},
		["Elder's Amber Stave of Healing"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Twilight Mantle of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Battle Knife of the Bear"] = {
			["mr"] = 9943,
			["H3219"] = 9943,
		},
		["Pattern: Guardian Cloak"] = {
			["mr"] = 3413,
			["H3219"] = 3413,
		},
		["Bard's Gloves of the Bear"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Tough Condor Meat"] = {
			["mr"] = 1390,
			["H3219"] = 1390,
		},
		["Thick War Axe"] = {
			["mr"] = 5577,
			["H3219"] = 5577,
		},
		["Renegade Shield of Blocking"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Plans: Silvered Bronze Shoulders"] = {
			["mr"] = 4200,
			["H3219"] = 4200,
		},
		["Burning War Axe"] = {
			["mr"] = 43600,
			["H3219"] = 43600,
		},
		["Buccaneer's Vest of Intellect"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Disciple's Vest of the Eagle"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Phalanx Shield of the Monkey"] = {
			["mr"] = 19998,
			["H3219"] = 19998,
		},
		["Lupine Leggings of the Whale"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Sentry's Slippers of the Whale"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Plans: Golden Scale Cuirass"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Bard's Cloak"] = {
			["mr"] = 455,
			["H3219"] = 455,
		},
		["Nightsky Trousers"] = {
			["mr"] = 5632,
			["H3219"] = 5632,
		},
		["Infiltrator Boots of the Owl"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Beaded Britches of the Falcon"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Knight's Girdle of the Whale"] = {
			["mr"] = 3715,
			["H3219"] = 3715,
		},
		["Dwarven Magestaff of Nature's Wrath"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Darkweave Breeches"] = {
			["mr"] = 24375,
			["H3219"] = 24375,
		},
		["Renegade Gauntlets of the Monkey"] = {
			["mr"] = 6400,
			["H3219"] = 6400,
		},
		["Buccaneer's Pants of the Monkey"] = {
			["mr"] = 1499,
			["H3219"] = 1499,
		},
		["Green Lens of Healing"] = {
			["mr"] = 359000,
			["H3219"] = 359000,
		},
		["Fortified Boots of Stamina"] = {
			["mr"] = 1712,
			["H3219"] = 1712,
		},
		["Captain's Cloak of Strength"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Defender Leggings of Power"] = {
			["mr"] = 3629,
			["H3219"] = 3629,
		},
		["Pagan Belt of the Eagle"] = {
			["mr"] = 4694,
			["H3219"] = 4694,
		},
		["Pagan Cape of the Whale"] = {
			["mr"] = 1129,
			["H3219"] = 1129,
		},
		["Thistlefur Bands of Spirit"] = {
			["mr"] = 8199,
			["H3219"] = 8199,
		},
		["Magic Dust"] = {
			["H3212"] = 4721,
			["cc"] = 0,
			["id"] = "2091:0:0:0:0",
			["sc"] = 0,
			["mr"] = 4721,
		},
		["Gold Bar"] = {
			["mr"] = 850,
			["H3219"] = 850,
		},
		["Schematic: Large Seaforium Charge"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Runecloth Gloves"] = {
			["H3223"] = 12000,
			["mr"] = 20963,
			["sc"] = 1,
			["id"] = "13863:0:0:0:0",
			["H3224"] = 21500,
			["cc"] = 4,
			["H3225"] = 20963,
		},
		["Schematic: Spellpower Goggles Xtreme"] = {
			["mr"] = 34800,
			["H3219"] = 34800,
		},
		["Explosive Shotgun"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Brown Linen Pants"] = {
			["mr"] = 67,
			["H3219"] = 67,
		},
		["Insignia Bracers"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Formula: Enchant Boots - Minor Agility"] = {
			["mr"] = 2790,
			["H3219"] = 2790,
		},
		["Sorcerer Cloak of Fiery Wrath"] = {
			["mr"] = 5016,
			["cc"] = 4,
			["id"] = "9877:0:0:1883:0",
			["sc"] = 1,
			["H3220"] = 5016,
		},
		["Bristlebark Gloves"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Conjurer's Sphere of the Whale"] = {
			["mr"] = 12200,
			["H3219"] = 12200,
		},
		["Claw of the Shadowmancer"] = {
			["mr"] = 33700,
			["H3219"] = 33700,
		},
		["Mystic's Robe"] = {
			["H3210"] = 4500,
			["mr"] = 4500,
			["sc"] = 1,
			["id"] = "14371:0:0:0:0",
			["cc"] = 4,
		},
		["Carving Knife of Agility"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Compact Shotgun"] = {
			["mr"] = 699,
			["H3219"] = 699,
		},
		["Sage's Pants of the Monkey"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Carving Knife of Frozen Wrath"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Battleforge Shield of the Tiger"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Tangy Clam Meat"] = {
			["mr"] = 95,
			["H3219"] = 95,
		},
		["Pioneer Cloak"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Giant Club of the Tiger"] = {
			["mr"] = 9400,
			["H3219"] = 9400,
		},
		["Spiked Chain Cloak of the Boar"] = {
			["mr"] = 1555,
			["H3219"] = 1555,
		},
		["Green Lens of Shadow Wrath"] = {
			["mr"] = 200000,
			["H3219"] = 200000,
		},
		["Primal Leggings of the Owl"] = {
			["mr"] = 525,
			["H3219"] = 525,
		},
		["Willow Vest of Intellect"] = {
			["mr"] = 2250,
			["H3219"] = 2250,
		},
		["Robust Cloak of the Monkey"] = {
			["mr"] = 33968,
			["H3219"] = 33968,
		},
		["Acrobatic Staff of the Bear"] = {
			["mr"] = 29250,
			["H3219"] = 29250,
		},
		["Willow Belt of the Monkey"] = {
			["mr"] = 1545,
			["H3219"] = 1545,
		},
		["Seer's Boots"] = {
			["mr"] = 448,
			["H3219"] = 448,
		},
		["Pioneer Tunic of the Monkey"] = {
			["mr"] = 1133,
			["H3219"] = 1133,
		},
		["Coarse Blasting Powder"] = {
			["mr"] = 67,
			["H3219"] = 67,
		},
		["Nightsky Wristbands"] = {
			["mr"] = 3250,
			["H3219"] = 3250,
		},
		["Oak Mallet of Stamina"] = {
			["mr"] = 5700,
			["H3219"] = 5700,
		},
		["Cross Dagger of Agility"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Grizzly Pants of the Eagle"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Grunt's Legguards of the Monkey"] = {
			["mr"] = 3163,
			["H3219"] = 3163,
		},
		["Twilight Cowl of the Eagle"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Polished Zweihander of the Whale"] = {
			["mr"] = 6655,
			["H3219"] = 6655,
		},
		["Manual: Heavy Silk Bandage"] = {
			["mr"] = 6501,
			["sc"] = 7,
			["id"] = "16112:0:0:0:0",
			["H3219"] = 6501,
			["cc"] = 9,
		},
		["Raider's Belt of the Tiger"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Dervish Cape of the Eagle"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Kaldorei Spider Kabob"] = {
			["mr"] = 10,
			["H3219"] = 10,
		},
		["Bandit Gloves of Arcane Wrath"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Delicious Cave Mold"] = {
			["mr"] = 537,
			["H3219"] = 537,
		},
		["Bard's Tunic of Spirit"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Gleaming Claymore of Power"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Rigid Buckler of the Tiger"] = {
			["mr"] = 4966,
			["H3219"] = 4966,
		},
		["Battleforge Girdle of the Eagle"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Decapitating Sword of Stamina"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Stonecutter Claymore of the Bear"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Spiked Club of the Boar"] = {
			["mr"] = 995,
			["H3219"] = 995,
		},
		["Sentinel Bracers of Nature's Wrath"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Bard's Buckler of Agility"] = {
			["mr"] = 6396,
			["H3219"] = 6396,
		},
		["Feral Gloves of the Owl"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Moonsteel Broadsword"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Bandit Jerkin of Intellect"] = {
			["mr"] = 1698,
			["H3219"] = 1698,
		},
		["Crusader Bow of the Tiger"] = {
			["mr"] = 49000,
			["H3219"] = 49000,
		},
		["Scouting Tunic of Spirit"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Regal Cloak of Stamina"] = {
			["mr"] = 6600,
			["H3219"] = 6600,
		},
		["Hunting Buckler"] = {
			["mr"] = 389,
			["H3219"] = 389,
		},
		["Dervish Boots of the Eagle"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Ivycloth Boots of Arcane Wrath"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Recipe: Clam Chowder"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Murphstar of the Tiger"] = {
			["mr"] = 15200,
			["H3219"] = 15200,
		},
		["Tundra Ring of the Tiger"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Green Lens of Nature's Wrath"] = {
			["mr"] = 120000,
			["H3219"] = 120000,
		},
		["Twilight Boots of the Whale"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Thick Leather Ammo Pouch"] = {
			["mr"] = 29899,
			["H3219"] = 29899,
		},
		["Tel'Abim Banana"] = {
			["mr"] = 69,
			["H3219"] = 69,
		},
		["Defender Bracers of the Whale"] = {
			["mr"] = 4697,
			["H3219"] = 4697,
		},
		["Stylish Black Shirt"] = {
			["mr"] = 39000,
			["H3219"] = 39000,
		},
		["Tender Wolf Meat"] = {
			["mr"] = 640,
			["cc"] = 7,
			["id"] = "12208:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 640,
		},
		["Archer's Belt of the Eagle"] = {
			["mr"] = 5499,
			["H3219"] = 5499,
		},
		["Battleforge Cloak of the Whale"] = {
			["mr"] = 7699,
			["H3219"] = 7699,
		},
		["Elder's Mantle of Frozen Wrath"] = {
			["mr"] = 8400,
			["H3219"] = 8400,
		},
		["Red Woolen Bag"] = {
			["mr"] = 900,
			["cc"] = 1,
			["id"] = "5763:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 900,
		},
		["Shiny Fish Scales"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["Phalanx Headguard of the Boar"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Truesilver Bar"] = {
			["mr"] = 2299,
			["sc"] = 0,
			["id"] = "6037:0:0:0:0",
			["cc"] = 7,
			["H3220"] = 2299,
		},
		["Shimmering Cloak of Stamina"] = {
			["mr"] = 1522,
			["H3219"] = 1522,
		},
		["Battleforge Shield of Blocking"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Archer's Jerkin of the Wolf"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Sweet Nectar"] = {
			["mr"] = 50,
			["H3219"] = 50,
		},
		["Gypsy Tunic of the Monkey"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["War Knife of Agility"] = {
			["mr"] = 2041,
			["H3219"] = 2041,
		},
		["Forest Hoop of the Tiger"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Heavy Kodo Meat"] = {
			["mr"] = 341,
			["H3219"] = 341,
		},
		["Pattern: Green Silk Pack"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Gloom Reaper of Power"] = {
			["mr"] = 18391,
			["H3219"] = 18391,
		},
		["19 Pound Catfish"] = {
			["mr"] = 222,
			["H3219"] = 222,
		},
		["Ivycloth Robe of Stamina"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Walking Boots"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Scaled Leather Leggings of the Eagle"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Knight's Gauntlets of the Tiger"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Renegade Leggings of the Whale"] = {
			["mr"] = 12799,
			["H3219"] = 12799,
		},
		["Security DELTA Data Access Card"] = {
			["mr"] = 750,
			["H3219"] = 750,
		},
		["Scaled Leather Shoulders of the Owl"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Sturdy Quarterstaff of the Wolf"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Band of Purification"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Soldier's Boots of Stamina"] = {
			["mr"] = 1220,
			["H3219"] = 1220,
		},
		["Elder's Hat of Intellect"] = {
			["mr"] = 19543,
			["H3219"] = 19543,
		},
		["Tough Hunk of Bread"] = {
			["mr"] = 128,
			["H3219"] = 128,
		},
		["Formula: Runed Arcanite Rod"] = {
			["mr"] = 29600,
			["H3219"] = 29600,
		},
		["Lambent Scale Boots"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Kingsblood"] = {
			["mr"] = 199,
			["sc"] = 0,
			["id"] = "3356:0:0:0:0",
			["H3219"] = 199,
			["cc"] = 7,
		},
		["Conjurer's Cloak of Arcane Wrath"] = {
			["mr"] = 8511,
			["H3219"] = 8511,
		},
		["Scaled Cloak of Nature's Wrath"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Double Mail Coif"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Greenweave Cloak of the Owl"] = {
			["mr"] = 1799,
			["H3219"] = 1799,
		},
		["Lupine Leggings of the Eagle"] = {
			["mr"] = 1820,
			["H3219"] = 1820,
		},
		["Aboriginal Rod of Spirit"] = {
			["mr"] = 3113,
			["H3219"] = 3113,
		},
		["Rusty Warhammer"] = {
			["mr"] = 882,
			["H3219"] = 882,
		},
		["Deadly Kris of Stamina"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Jazeraint Boots of the Eagle"] = {
			["mr"] = 13074,
			["H3219"] = 13074,
		},
		["Resilient Boots"] = {
			["mr"] = 6274,
			["H3219"] = 6274,
		},
		["Fortified Chain of Power"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Rough Copper Vest"] = {
			["mr"] = 70,
			["H3219"] = 70,
		},
		["Embossed Leather Gloves"] = {
			["mr"] = 74,
			["H3219"] = 74,
		},
		["Superior Leggings of the Eagle"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Wolf Rider's Gloves of Defense"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Superior Buckler of Strength"] = {
			["mr"] = 5622,
			["H3219"] = 5622,
		},
		["Durable Hat of the Owl"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Stonemason Cloak"] = {
			["mr"] = 485,
			["H3219"] = 485,
		},
		["Buccaneer's Gloves of Healing"] = {
			["mr"] = 927,
			["H3219"] = 927,
		},
		["Bolt of Silk Cloth"] = {
			["mr"] = 940,
			["cc"] = 7,
			["id"] = "4305:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 940,
		},
		["Chromite Greaves"] = {
			["H3215"] = 20000,
			["mr"] = 20000,
			["sc"] = 4,
			["id"] = "8141:0:0:0:0",
			["cc"] = 4,
		},
		["Phalanx Boots of the Bear"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Jagged Star of Nature's Wrath"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Beaded Wraps of the Owl"] = {
			["mr"] = 450,
			["H3219"] = 450,
		},
		["Bandit Cinch of Defense"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Recipe: Tasty Lion Steak"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Darkmist Wizard Hat of the Whale"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Lupine Buckler of Fiery Wrath"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Shimmering Trousers of Healing"] = {
			["mr"] = 5800,
			["H3219"] = 5800,
		},
		["Haunch of Meat"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Savannah Ring of the Falcon"] = {
			["mr"] = 10758,
			["H3219"] = 10758,
		},
		["Tracker's Boots of Power"] = {
			["mr"] = 11999,
			["H3219"] = 11999,
		},
		["Trueshot Bow of the Owl"] = {
			["mr"] = 24800,
			["H3219"] = 24800,
		},
		["Hefty Battlehammer of the Eagle"] = {
			["mr"] = 5507,
			["H3219"] = 5507,
		},
		["Elixir of Giants"] = {
			["mr"] = 5996,
			["H3219"] = 5996,
		},
		["Buccaneer's Bracers of Fiery Wrath"] = {
			["mr"] = 1300,
			["cc"] = 4,
			["id"] = "14166:0:0:1878:0",
			["sc"] = 1,
			["H3220"] = 1300,
		},
		["Starfaller"] = {
			["mr"] = 47012,
			["H3219"] = 47012,
		},
		["Ghostwalker Belt of the Owl"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Primal Leggings of Healing"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Brawler Gloves"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Sentinel Cloak of the Owl"] = {
			["mr"] = 9300,
			["H3219"] = 9300,
		},
		["Scorpid Stinger"] = {
			["mr"] = 24,
			["H3219"] = 24,
		},
		["Sliverblade"] = {
			["mr"] = 119500,
			["H3219"] = 119500,
		},
		["Pattern: Guardian Armor"] = {
			["mr"] = 2799,
			["H3219"] = 2799,
		},
		["Bright Mantle"] = {
			["mr"] = 8800,
			["H3219"] = 8800,
		},
		["Elder's Pants of Fiery Wrath"] = {
			["mr"] = 10000,
			["cc"] = 4,
			["id"] = "7368:0:0:1888:0",
			["sc"] = 1,
			["H3220"] = 10000,
		},
		["Sword of the Magistrate"] = {
			["mr"] = 69500,
			["H3219"] = 69500,
		},
		["Ivycloth Pants of the Whale"] = {
			["mr"] = 6600,
			["H3219"] = 6600,
		},
		["Murloc Scale Belt"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Outrunner's Gloves of the Whale"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Shimmering Stave of Fiery Wrath"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Infantry Shield of Blocking"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Deadly Kris of Agility"] = {
			["mr"] = 20934,
			["H3219"] = 20934,
		},
		["Splitting Hatchet of the Whale"] = {
			["mr"] = 7703,
			["H3219"] = 7703,
		},
		["Bloodspattered Shield of Strength"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Enduring Cap"] = {
			["mr"] = 14800,
			["H3219"] = 14800,
		},
		["Barbaric Battle Axe of Agility"] = {
			["mr"] = 1949,
			["H3219"] = 1949,
		},
		["Hunting Pants"] = {
			["mr"] = 493,
			["H3219"] = 493,
		},
		["Splitting Hatchet of Strength"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Plans: Radiant Breastplate"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Battle Knife of Strength"] = {
			["mr"] = 6085,
			["H3219"] = 6085,
		},
		["Green Lens of Frozen Wrath"] = {
			["mr"] = 429000,
			["H3219"] = 429000,
		},
		["Infantry Shield of the Monkey"] = {
			["mr"] = 549,
			["H3219"] = 549,
		},
		["Dark Leather Shoulders"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Dense Triangle Mace"] = {
			["mr"] = 44000,
			["H3219"] = 44000,
		},
		["Dervish Boots of the Monkey"] = {
			["mr"] = 17244,
			["H3219"] = 17244,
		},
		["Short Bastard Sword of the Eagle"] = {
			["mr"] = 688,
			["H3219"] = 688,
		},
		["Resilient Robe"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Shining Silver Breastplate"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Pattern: Robes of Arcana"] = {
			["mr"] = 120000,
			["H3219"] = 120000,
		},
		["Green Woolen Bag"] = {
			["mr"] = 800,
			["cc"] = 1,
			["id"] = "4241:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 800,
		},
		["Phalanx Cloak of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Minor Magic Resistance Potion"] = {
			["mr"] = 496,
			["H3219"] = 496,
		},
		["Superior Boots of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Bard's Boots of the Owl"] = {
			["mr"] = 478,
			["H3219"] = 478,
		},
		["Recipe: Elixir of Demonslaying"] = {
			["H3223"] = 51200,
			["mr"] = 51200,
			["cc"] = 9,
			["id"] = "9300:0:0:0:0",
			["sc"] = 6,
		},
		["Grunt Axe of Agility"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Merc Sword of the Eagle"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Priest's Mace of Stamina"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Banded Bracers of Stamina"] = {
			["mr"] = 5919,
			["H3219"] = 5919,
		},
		["Shimmering Stave of Intellect"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Holy Protection Potion"] = {
			["H3210"] = 174,
			["mr"] = 174,
			["sc"] = 0,
			["id"] = "6051:0:0:0:0",
			["cc"] = 0,
		},
		["Handstitched Linen Britches"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Bandit Cloak of Spirit"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Heart of the Wild"] = {
			["H3223"] = 595,
			["mr"] = 730,
			["cc"] = 5,
			["id"] = "10286:0:0:0:0",
			["H3222"] = 769,
			["sc"] = 0,
			["H3224"] = 730,
		},
		["Ghostwalker Rags of the Falcon"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Sergeant's Warhammer of Strength"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Cadet Leggings of Strength"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Practice Lock"] = {
			["mr"] = 27,
			["H3219"] = 27,
		},
		["Spinel Ring of Nature Resistance"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Greater Healing Potion"] = {
			["mr"] = 456,
			["cc"] = 0,
			["id"] = "1710:0:0:0:0",
			["H3219"] = 456,
			["sc"] = 0,
		},
		["Soldier's Girdle of the Eagle"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Knight's Breastplate of Strength"] = {
			["mr"] = 13796,
			["H3219"] = 13796,
		},
		["Beaded Orb of the Whale"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Lean Wolf Flank"] = {
			["mr"] = 359,
			["H3219"] = 359,
		},
		["Scouting Gloves of the Whale"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Bard's Belt of the Monkey"] = {
			["mr"] = 1495,
			["H3219"] = 1495,
		},
		["Aboriginal Footwraps of Spirit"] = {
			["mr"] = 1230,
			["H3219"] = 1230,
		},
		["Girdle of Golem Strength"] = {
			["mr"] = 35000,
			["H3219"] = 35000,
		},
		["Rough Bronze Leggings"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Recipe: Barbecued Buzzard Wing"] = {
			["mr"] = 1390,
			["H3219"] = 1390,
		},
		["Shimmering Gloves of the Owl"] = {
			["mr"] = 2950,
			["H3219"] = 2950,
		},
		["Scouting Belt of Defense"] = {
			["mr"] = 1198,
			["H3219"] = 1198,
		},
		["Forester's Axe of the Wolf"] = {
			["mr"] = 3299,
			["H3219"] = 3299,
		},
		["Buccaneer's Bracers of the Whale"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Bright Bracers"] = {
			["mr"] = 2662,
			["H3219"] = 2662,
		},
		["Pattern: Runecloth Boots"] = {
			["H3225"] = 57500,
			["cc"] = 9,
			["id"] = "14488:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 43500,
			["mr"] = 57500,
		},
		["Ivycloth Gloves of Spirit"] = {
			["mr"] = 1299,
			["H3219"] = 1299,
		},
		["Bard's Trousers of the Monkey"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Infiltrator Armor of Spirit"] = {
			["mr"] = 43992,
			["H3219"] = 43992,
		},
		["Slayer's Pants"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Savage Axe of Stamina"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Copper Chain Pants"] = {
			["mr"] = 80,
			["H3219"] = 80,
		},
		["Green Hills of Stranglethorn - Page 16"] = {
			["mr"] = 2359,
			["H3219"] = 2359,
		},
		["Pattern: Earthen Silk Belt"] = {
			["mr"] = 22500,
			["H3219"] = 22500,
		},
		["Banded Boots of the Boar"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Scarlet Gauntlets"] = {
			["mr"] = 14500,
			["H3219"] = 14500,
		},
		["Bandit Cinch of the Owl"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Veteran Girdle"] = {
			["mr"] = 262,
			["H3219"] = 262,
		},
		["Soldier's Leggings of Strength"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Shadow Hood"] = {
			["mr"] = 19800,
			["H3219"] = 19800,
		},
		["Mageroyal"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Light Leather Quiver"] = {
			["mr"] = 33,
			["H3219"] = 33,
		},
		["Scaled Leather Boots of Spirit"] = {
			["mr"] = 5027,
			["H3219"] = 5027,
		},
		["Tunnel Pick"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Superior Tunic of the Monkey"] = {
			["mr"] = 5414,
			["H3219"] = 5414,
		},
		["Robust Gloves of the Falcon"] = {
			["mr"] = 5055,
			["H3219"] = 5055,
		},
		["Superior Tunic of the Falcon"] = {
			["mr"] = 3999,
			["H3219"] = 3999,
		},
		["Battleforge Girdle of the Whale"] = {
			["mr"] = 11200,
			["H3219"] = 11200,
		},
		["Precision Bow"] = {
			["mr"] = 5100,
			["H3219"] = 5100,
		},
		["Buccaneer's Cape of Frozen Wrath"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Formula: Enchant Boots - Lesser Spirit"] = {
			["mr"] = 7200,
			["H3219"] = 7200,
		},
		["Darkshore Grouper"] = {
			["mr"] = 3,
			["H3219"] = 3,
		},
		["Fortified Leggings of Strength"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Buccaneer's Vest of the Owl"] = {
			["mr"] = 9499,
			["H3219"] = 9499,
		},
		["Simple Branch of Healing"] = {
			["mr"] = 1250,
			["H3219"] = 1250,
		},
		["Phalanx Headguard of the Gorilla"] = {
			["mr"] = 10400,
			["H3219"] = 10400,
		},
		["Ranger Leggings of Agility"] = {
			["mr"] = 25000,
			["H3219"] = 25000,
		},
		["Raider's Shoulderpads"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Carving Knife of Arcane Wrath"] = {
			["mr"] = 920,
			["H3219"] = 920,
		},
		["Cadet Leggings of Power"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Infiltrator Cloak of Nature's Wrath"] = {
			["mr"] = 5073,
			["H3219"] = 5073,
		},
		["Banded Helm of the Gorilla"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Sequoia Hammer of Nature's Wrath"] = {
			["mr"] = 9937,
			["H3219"] = 9937,
		},
		["Defender Cloak of the Bear"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Dervish Bracers of the Eagle"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Aurora Gloves"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Raider's Shield of the Gorilla"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Reinforced Linen Cape"] = {
			["mr"] = 74,
			["H3219"] = 74,
		},
		["Hook Dagger of Power"] = {
			["mr"] = 2050,
			["H3219"] = 2050,
		},
		["Twin-bladed Axe of the Monkey"] = {
			["mr"] = 1730,
			["H3219"] = 1730,
		},
		["Soldier's Girdle of the Whale"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Durable Belt of Fiery Wrath"] = {
			["mr"] = 5313,
			["cc"] = 4,
			["id"] = "10404:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 5313,
		},
		["Gypsy Tunic of the Eagle"] = {
			["mr"] = 625,
			["H3219"] = 625,
		},
		["Diamond Hammer"] = {
			["mr"] = 11999,
			["H3219"] = 11999,
		},
		["Dwarven Magestaff of the Whale"] = {
			["mr"] = 4875,
			["H3219"] = 4875,
		},
		["Cold Basilisk Eye"] = {
			["mr"] = 49800,
			["sc"] = 0,
			["id"] = "5079:0:0:0:0",
			["H3219"] = 49800,
			["cc"] = 4,
		},
		["Gypsy Buckler of the Boar"] = {
			["mr"] = 372,
			["H3219"] = 372,
		},
		["Sorcerer Mantle of the Whale"] = {
			["mr"] = 8900,
			["H3219"] = 8900,
		},
		["Twin-bladed Axe of the Tiger"] = {
			["mr"] = 1750,
			["H3219"] = 1750,
		},
		["Pattern: Red Woolen Bag"] = {
			["mr"] = 890,
			["cc"] = 9,
			["id"] = "5772:0:0:0:0",
			["sc"] = 2,
			["H3224"] = 890,
		},
		["Savage Axe of the Bear"] = {
			["mr"] = 16028,
			["H3219"] = 16028,
		},
		["Conjurer's Shoes of Shadow Wrath"] = {
			["mr"] = 8166,
			["H3219"] = 8166,
		},
		["Savage Axe of Strength"] = {
			["mr"] = 17500,
			["H3219"] = 17500,
		},
		["Magefist Gloves"] = {
			["mr"] = 15098,
			["H3219"] = 15098,
		},
		["Pathfinder Vest of Stamina"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Deviate Scale"] = {
			["mr"] = 47,
			["H3219"] = 47,
		},
		["Conjurer's Sphere of Spirit"] = {
			["mr"] = 13559,
			["H3219"] = 13559,
		},
		["Bard's Gloves of Defense"] = {
			["mr"] = 687,
			["H3219"] = 687,
		},
		["Flimsy Chain Pants"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Geomancer's Cloak of the Whale"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Lupine Axe"] = {
			["mr"] = 1949,
			["H3219"] = 1949,
		},
		["Conjurer's Robe of the Eagle"] = {
			["mr"] = 30000,
			["H3219"] = 30000,
		},
		["Infiltrator Armor of Intellect"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["High Bergg Helm"] = {
			["mr"] = 35976,
			["H3219"] = 35976,
		},
		["Glinting Steel Dagger"] = {
			["mr"] = 21099,
			["H3219"] = 21099,
		},
		["Glimmering Flamberge of the Eagle"] = {
			["mr"] = 17500,
			["H3219"] = 17500,
		},
		["Infiltrator Pants of Power"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Superior Buckler of the Tiger"] = {
			["mr"] = 22488,
			["H3219"] = 22488,
		},
		["Infiltrator Shoulders of the Owl"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Dervish Gloves of Spirit"] = {
			["mr"] = 3045,
			["H3219"] = 3045,
		},
		["Blood Sausage"] = {
			["mr"] = 51,
			["H3219"] = 51,
		},
		["Sniper Rifle of the Wolf"] = {
			["mr"] = 43900,
			["H3219"] = 43900,
		},
		["Bard's Bracers of Arcane Wrath"] = {
			["mr"] = 1399,
			["H3219"] = 1399,
		},
		["Watcher's Mantle of Stamina"] = {
			["mr"] = 9956,
			["H3219"] = 9956,
		},
		["Willow Cape of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Cadet Leggings of the Gorilla"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Archer's Cap of the Eagle"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Lesser Astral Essence"] = {
			["mr"] = 600,
			["sc"] = 0,
			["id"] = "10998:0:0:0:0",
			["H3219"] = 600,
			["cc"] = 7,
		},
		["Flask of Mojo"] = {
			["mr"] = 263,
			["cc"] = 7,
			["id"] = "8151:0:0:0:0",
			["H3219"] = 263,
			["sc"] = 0,
		},
		["Black Mageweave Shoulders"] = {
			["mr"] = 17200,
			["H3219"] = 17200,
		},
		["Bandit Gloves of Healing"] = {
			["mr"] = 975,
			["H3219"] = 975,
		},
		["Plans: Runed Copper Breastplate"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Silksand Bracers"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Blackrock Boots"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Headstriker Sword of the Bear"] = {
			["mr"] = 50000,
			["H3219"] = 50000,
		},
		["Zircon Band of Frost Resistance"] = {
			["mr"] = 1398,
			["H3219"] = 1398,
		},
		["Cured Heavy Hide"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Hacking Cleaver of the Bear"] = {
			["mr"] = 15058,
			["H3219"] = 15058,
		},
		["Superior Belt of Intellect"] = {
			["mr"] = 2251,
			["H3219"] = 2251,
		},
		["Pattern: Boots of the Enchanter"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Nature Protection Potion"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Un'Goro Soil"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Mercenary Blade of the Monkey"] = {
			["mr"] = 12799,
			["H3219"] = 12799,
		},
		["Dokebi Bracers"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Grave Moss"] = {
			["mr"] = 158,
			["H3219"] = 158,
		},
		["Elixir of Detect Undead"] = {
			["H3223"] = 520,
			["mr"] = 520,
			["cc"] = 0,
			["id"] = "9154:0:0:0:0",
			["sc"] = 0,
		},
		["Large Venom Sac"] = {
			["mr"] = 185,
			["H3219"] = 185,
		},
		["Buccaneer's Cord of the Eagle"] = {
			["mr"] = 1656,
			["H3219"] = 1656,
		},
		["Ritual Leggings of Spirit"] = {
			["mr"] = 1621,
			["H3219"] = 1621,
		},
		["\"Mage-Eye\" Blunderbuss"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Antipodean Rod"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Recipe: Minor Magic Resistance Potion"] = {
			["mr"] = 993,
			["sc"] = 6,
			["id"] = "3393:0:0:0:0",
			["H3219"] = 993,
			["cc"] = 9,
		},
		["Dreamweave Circlet"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Sentinel Breastplate of the Eagle"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Conjurer's Hood of the Eagle"] = {
			["mr"] = 19999,
			["H3219"] = 19999,
		},
		["Durable Shoulders of Intellect"] = {
			["mr"] = 2532,
			["H3219"] = 2532,
		},
		["Superior Belt of the Eagle"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Recipe: Goretusk Liver Pie"] = {
			["mr"] = 100,
			["H3219"] = 100,
		},
		["Rigid Moccasins of the Owl"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Bloodwoven Bracers of Spirit"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Brutal War Axe of the Eagle"] = {
			["mr"] = 11641,
			["H3219"] = 11641,
		},
		["Bard's Boots of the Eagle"] = {
			["mr"] = 453,
			["H3219"] = 453,
		},
		["Raw Summer Bass"] = {
			["mr"] = 299,
			["H3219"] = 299,
		},
		["Infiltrator Pants of the Whale"] = {
			["mr"] = 6969,
			["H3219"] = 6969,
		},
		["Archer's Gloves of the Owl"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Raider's Legguards of the Bear"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Slayer's Shoulder Pads"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Mistscape Cloak"] = {
			["mr"] = 14000,
			["H3219"] = 14000,
		},
		["Deadly Kris of Healing"] = {
			["mr"] = 14500,
			["H3219"] = 14500,
		},
		["Elder's Amber Stave of Intellect"] = {
			["mr"] = 10475,
			["H3219"] = 10475,
		},
		["Formula: Enchant Bracer - Greater Spirit"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Raptor Hide"] = {
			["mr"] = 208,
			["H3219"] = 208,
		},
		["Shellfish"] = {
			["mr"] = 43,
			["H3219"] = 43,
		},
		["Savannah Ring of the Wolf"] = {
			["mr"] = 6900,
			["H3219"] = 6900,
		},
		["Bright Robe"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Veteran Shield"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Infiltrator Armor of Stamina"] = {
			["mr"] = 12064,
			["H3219"] = 12064,
		},
		["Pattern: Hands of Darkness"] = {
			["mr"] = 9750,
			["H3219"] = 9750,
		},
		["Fire Protection Potion"] = {
			["mr"] = 7600,
			["H3219"] = 7600,
		},
		["Shimmering Gloves of Healing"] = {
			["mr"] = 9050,
			["H3219"] = 9050,
		},
		["Short Bastard Sword of the Monkey"] = {
			["mr"] = 682,
			["H3219"] = 682,
		},
		["Riverpaw Leather Vest"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Barbarian War Axe of the Bear"] = {
			["mr"] = 5355,
			["H3219"] = 5355,
		},
		["Barbarian War Axe of the Eagle"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Oak Mallet of the Boar"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Strange Dust"] = {
			["mr"] = 49,
			["sc"] = 0,
			["id"] = "10940:0:0:0:0",
			["H3219"] = 49,
			["cc"] = 7,
		},
		["Cavalier Two-hander of Strength"] = {
			["mr"] = 9143,
			["H3219"] = 9143,
		},
		["Stonecloth Britches"] = {
			["mr"] = 6584,
			["H3219"] = 6584,
		},
		["Dervish Boots of Stamina"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Soldier's Leggings of the Bear"] = {
			["mr"] = 1109,
			["H3219"] = 1109,
		},
		["Willow Pants of the Whale"] = {
			["mr"] = 720,
			["H3219"] = 720,
		},
		["Ritual Gloves of the Eagle"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Conjurer's Hood of Intellect"] = {
			["mr"] = 22500,
			["H3219"] = 22500,
		},
		["Mistscape Gloves"] = {
			["mr"] = 7099,
			["H3219"] = 7099,
		},
		["River Pride Choker"] = {
			["mr"] = 72512,
			["H3219"] = 72512,
		},
		["Birchwood Maul of the Whale"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Blade of the Titans"] = {
			["mr"] = 300555,
			["H3219"] = 300555,
		},
		["Flying Tiger Goggles"] = {
			["mr"] = 1300,
			["H3219"] = 1300,
		},
		["Stonecloth Cape"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Gypsy Trousers of the Falcon"] = {
			["mr"] = 558,
			["H3219"] = 558,
		},
		["Trickster's Sash of the Eagle"] = {
			["mr"] = 7890,
			["H3219"] = 7890,
		},
		["Bard's Trousers of Power"] = {
			["mr"] = 1195,
			["H3219"] = 1195,
		},
		["Elixir of the Mongoose"] = {
			["H3223"] = 19500,
			["mr"] = 19500,
			["cc"] = 0,
			["id"] = "13452:0:0:0:0",
			["sc"] = 0,
		},
		["Stonecutter Claymore of Stamina"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Dwarven Magestaff of Frozen Wrath"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Sparkleshell Mantle"] = {
			["mr"] = 47500,
			["H3219"] = 47500,
		},
		["Crab Cake"] = {
			["mr"] = 36,
			["H3219"] = 36,
		},
		["Simple Branch of the Eagle"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Severing Axe of Stamina"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Chieftain's Headdress of the Bear"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Infiltrator Bracers of the Monkey"] = {
			["mr"] = 39900,
			["H3219"] = 39900,
		},
		["Buccaneer's Boots of Stamina"] = {
			["mr"] = 552,
			["H3219"] = 552,
		},
		["Bandit Gloves of the Bear"] = {
			["mr"] = 1050,
			["H3219"] = 1050,
		},
		["Coarse Stone"] = {
			["mr"] = 150,
			["H3219"] = 150,
		},
		["Dire Wand"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Small Glowing Shard"] = {
			["mr"] = 769,
			["sc"] = 0,
			["id"] = "11138:0:0:0:0",
			["H3219"] = 769,
			["cc"] = 7,
		},
		["Cutthroat's Boots of Agility"] = {
			["mr"] = 14105,
			["H3219"] = 14105,
		},
		["Murphstar of Power"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Acrobatic Staff of Healing"] = {
			["mr"] = 11799,
			["H3219"] = 11799,
		},
		["Raider's Shield of the Boar"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Fortified Leggings of the Bear"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Rigid Shoulders of the Owl"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Enchanted Thorium Bar"] = {
			["mr"] = 42199,
			["H3222"] = 42199,
			["id"] = "12655:0:0:0:0",
			["sc"] = 0,
			["cc"] = 7,
		},
		["Mild Spices"] = {
			["mr"] = 4,
			["H3219"] = 4,
		},
		["Beaded Orb of Spirit"] = {
			["mr"] = 1799,
			["H3219"] = 1799,
		},
		["Elixir of Lion's Strength"] = {
			["H3223"] = 20,
			["mr"] = 20,
			["sc"] = 0,
			["id"] = "2454:0:0:0:0",
			["cc"] = 0,
		},
		["Recipe: Seasoned Wolf Kabob"] = {
			["mr"] = 4699,
			["H3219"] = 4699,
		},
		["Pagan Belt of Intellect"] = {
			["mr"] = 1555,
			["H3219"] = 1555,
		},
		["Green Lens of Arcane Wrath"] = {
			["mr"] = 150000,
			["H3219"] = 150000,
		},
		["Blackened Defias Belt"] = {
			["mr"] = 890,
			["H3219"] = 890,
		},
		["Shimmering Cloak of the Owl"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Cadet Bracers"] = {
			["mr"] = 200,
			["H3219"] = 200,
		},
		["Fire Wand"] = {
			["mr"] = 494,
			["H3219"] = 494,
		},
		["Thorium Ore"] = {
			["mr"] = 6700,
			["H3219"] = 6700,
		},
		["Greenweave Cloak of Stamina"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Resilient Bands"] = {
			["mr"] = 3803,
			["H3219"] = 3803,
		},
		["Small Blue Pouch"] = {
			["mr"] = 370,
			["H3219"] = 370,
		},
		["White Linen Shirt"] = {
			["mr"] = 94,
			["H3219"] = 94,
		},
		["Durable Rod of the Falcon"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Lesser Stoneshield Potion"] = {
			["H3223"] = 705,
			["mr"] = 620,
			["cc"] = 0,
			["id"] = "4623:0:0:0:0",
			["sc"] = 0,
			["H3225"] = 620,
		},
		["Disciple's Stein of Intellect"] = {
			["mr"] = 550,
			["H3219"] = 550,
		},
		["Fish Oil"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["Staunch Hammer of Stamina"] = {
			["mr"] = 708,
			["H3219"] = 708,
		},
		["Barbaric Bracers"] = {
			["mr"] = 7495,
			["H3219"] = 7495,
		},
		["Shadow Goggles"] = {
			["mr"] = 4600,
			["H3219"] = 4600,
		},
		["Shadow Silk"] = {
			["mr"] = 1390,
			["H3222"] = 1390,
			["id"] = "10285:0:0:0:0",
			["cc"] = 7,
			["H3221"] = 1075,
			["sc"] = 0,
		},
		["Conjurer's Gloves of the Falcon"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Scouting Buckler of Stamina"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Massive Battle Axe of Power"] = {
			["mr"] = 4922,
			["H3219"] = 4922,
		},
		["Recipe: Elixir of Shadow Power"] = {
			["H3223"] = 25000,
			["mr"] = 25000,
			["sc"] = 6,
			["id"] = "9301:0:0:0:0",
			["cc"] = 9,
		},
		["Light Leather Bracers"] = {
			["mr"] = 198,
			["H3219"] = 198,
		},
		["Dervish Belt of the Whale"] = {
			["mr"] = 1975,
			["H3219"] = 1975,
		},
		["Dwarven Magestaff of the Wolf"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Ghostwalker Gloves of the Owl"] = {
			["mr"] = 9248,
			["H3219"] = 9248,
		},
		["Linen Boots"] = {
			["mr"] = 138,
			["H3219"] = 138,
		},
		["Dwarven Magestaff of the Bear"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Training Sword of the Whale"] = {
			["mr"] = 675,
			["H3219"] = 675,
		},
		["Pathfinder Guard of Fiery Wrath"] = {
			["mr"] = 6899,
			["cc"] = 4,
			["id"] = "15342:0:0:1880:0",
			["sc"] = 6,
			["H3220"] = 6899,
		},
		["Dragonmaw Chain Boots"] = {
			["mr"] = 2700,
			["H3219"] = 2700,
		},
		["Massive Battle Axe of the Wolf"] = {
			["mr"] = 3498,
			["H3219"] = 3498,
		},
		["Warbringer's Crown of the Bear"] = {
			["mr"] = 39900,
			["H3219"] = 39900,
		},
		["Raider's Shield of Stamina"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Buzzer Blade"] = {
			["mr"] = 1459,
			["H3219"] = 1459,
		},
		["Mystic's Woolies"] = {
			["mr"] = 555,
			["sc"] = 1,
			["id"] = "14370:0:0:0:0",
			["H3224"] = 555,
			["cc"] = 4,
		},
		["Heart of Fire"] = {
			["mr"] = 1383,
			["cc"] = 5,
			["id"] = "7077:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 1383,
		},
		["Soldier's Leggings of Power"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Battleforge Legguards of the Bear"] = {
			["mr"] = 3499,
			["H3219"] = 3499,
		},
		["Prospector's Boots"] = {
			["mr"] = 1380,
			["H3219"] = 1380,
		},
		["Lambent Scale Pauldrons"] = {
			["mr"] = 7100,
			["H3219"] = 7100,
		},
		["Sergeant's Warhammer of Power"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Goretusk Liver"] = {
			["mr"] = 99,
			["H3219"] = 99,
		},
		["Webwing Cloak"] = {
			["mr"] = 1550,
			["H3219"] = 1550,
		},
		["Banded Bracers of Power"] = {
			["mr"] = 6019,
			["H3219"] = 6019,
		},
		["Deadly Kris of Power"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Ranger Gloves of the Monkey"] = {
			["mr"] = 29500,
			["H3219"] = 29500,
		},
		["Viking Sword of the Monkey"] = {
			["mr"] = 9938,
			["H3219"] = 9938,
		},
		["Defender Girdle of the Bear"] = {
			["mr"] = 4206,
			["H3219"] = 4206,
		},
		["Hook Dagger of Frozen Wrath"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Acrobatic Staff of the Monkey"] = {
			["mr"] = 17000,
			["H3219"] = 17000,
		},
		["Heraldic Cloak"] = {
			["mr"] = 23299,
			["H3219"] = 23299,
		},
		["Elder's Mantle of the Owl"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Icemail Jerkin"] = {
			["mr"] = 450000,
			["H3219"] = 450000,
		},
		["Green Linen Shirt"] = {
			["mr"] = 452,
			["H3219"] = 452,
		},
		["Royal Sash of the Owl"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Willow Pants of the Eagle"] = {
			["mr"] = 1395,
			["H3219"] = 1395,
		},
		["Gypsy Tunic of the Falcon"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Gloom Reaper of the Wolf"] = {
			["mr"] = 14499,
			["H3219"] = 14499,
		},
		["Small Dagger"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Superior Belt of the Monkey"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Battleforge Cloak of the Boar"] = {
			["mr"] = 2697,
			["H3219"] = 2697,
		},
		["Blackrock Champion's Axe"] = {
			["mr"] = 3390,
			["H3219"] = 3390,
		},
		["Blackened Defias Boots"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Polished Zweihander of Stamina"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Wicked Claw"] = {
			["mr"] = 801,
			["cc"] = 7,
			["id"] = "8146:0:0:0:0",
			["H3219"] = 801,
			["sc"] = 0,
		},
		["Cutthroat's Belt of the Eagle"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Sentinel Shoulders of the Owl"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Ghostwalker Rags of the Eagle"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Raw Longjaw Mud Snapper"] = {
			["mr"] = 1,
			["H3219"] = 1,
		},
		["Battering Hammer of the Gorilla"] = {
			["mr"] = 8223,
			["H3219"] = 8223,
		},
		["Roasted Boar Meat"] = {
			["mr"] = 7,
			["H3219"] = 7,
		},
		["Superior Belt of the Owl"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Phalanx Bracers of Stamina"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Jade"] = {
			["mr"] = 1093,
			["sc"] = 0,
			["id"] = "1529:0:0:0:0",
			["H3219"] = 1093,
			["cc"] = 7,
		},
		["Tasty Lion Steak"] = {
			["mr"] = 380,
			["H3219"] = 380,
		},
		["Stone Hammer of the Bear"] = {
			["mr"] = 11734,
			["H3219"] = 11734,
		},
		["Rough Blasting Powder"] = {
			["mr"] = 6,
			["H3219"] = 6,
		},
		["Hook Dagger of Stamina"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Recipe: Curiously Tasty Omelet"] = {
			["mr"] = 525,
			["H3219"] = 525,
		},
		["Mistscape Mantle"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Lupine Vest of the Eagle"] = {
			["mr"] = 2118,
			["H3219"] = 2118,
		},
		["Jouster's Pauldrons"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Knight's Headguard of the Gorilla"] = {
			["mr"] = 57124,
			["H3219"] = 57124,
		},
		["Birchwood Maul of Spirit"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Archer's Gloves of the Bear"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Bard's Boots of Stamina"] = {
			["mr"] = 949,
			["H3219"] = 949,
		},
		["Conjurer's Gloves of the Whale"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Sentinel Cap of the Whale"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Inscribed Leather Breastplate"] = {
			["mr"] = 962,
			["H3219"] = 962,
		},
		["Knight's Gauntlets of the Bear"] = {
			["mr"] = 5800,
			["H3219"] = 5800,
		},
		["Silver Rod"] = {
			["mr"] = 298,
			["H3219"] = 298,
		},
		["Black Velvet Robes"] = {
			["mr"] = 33272,
			["H3219"] = 33272,
		},
		["Battle Chain Pants"] = {
			["mr"] = 373,
			["H3219"] = 373,
		},
		["Plans: Green Iron Shoulders"] = {
			["mr"] = 8700,
			["H3219"] = 8700,
		},
		["Battleforge Shield of the Boar"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Conjurer's Robe of the Owl"] = {
			["mr"] = 10600,
			["H3219"] = 10600,
		},
		["Aurora Armor"] = {
			["mr"] = 6100,
			["H3219"] = 6100,
		},
		["Honed Stiletto of Nature's Wrath"] = {
			["mr"] = 9625,
			["H3219"] = 9625,
		},
		["Soft Patch of Fur"] = {
			["mr"] = 1494,
			["H3219"] = 1494,
		},
		["Hacking Cleaver of the Monkey"] = {
			["mr"] = 8775,
			["H3219"] = 8775,
		},
		["Conjurer's Hood of the Owl"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Stonesplinter Rags"] = {
			["mr"] = 297,
			["H3219"] = 297,
		},
		["Renegade Belt of the Eagle"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Lupine Buckler of the Owl"] = {
			["mr"] = 1040,
			["H3219"] = 1040,
		},
		["Scaled Leather Bracers of the Eagle"] = {
			["mr"] = 2670,
			["H3219"] = 2670,
		},
		["Banded Helm of the Tiger"] = {
			["mr"] = 19800,
			["H3219"] = 19800,
		},
		["Birchwood Maul of the Monkey"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Ivycloth Cloak of the Owl"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Elemental Raiment"] = {
			["mr"] = 39800,
			["H3219"] = 39800,
		},
		["Short Bastard Sword of the Bear"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Buccaneer's Gloves of the Eagle"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Raider's Bracers of the Eagle"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Swiftthistle"] = {
			["mr"] = 149,
			["sc"] = 0,
			["id"] = "2452:0:0:0:0",
			["H3219"] = 149,
			["cc"] = 7,
		},
		["Durable Bracers of Healing"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Soldier's Armor of the Whale"] = {
			["mr"] = 1250,
			["H3219"] = 1250,
		},
		["Hunting Cloak"] = {
			["mr"] = 334,
			["H3219"] = 334,
		},
		["Lambent Scale Cloak"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Disciple's Vest of Stamina"] = {
			["mr"] = 499,
			["H3219"] = 499,
		},
		["Forester's Axe of the Boar"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Infiltrator Cloak of Agility"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Seer's Cuffs"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Elixir of Detect Lesser Invisibility"] = {
			["H3223"] = 369,
			["mr"] = 369,
			["cc"] = 0,
			["id"] = "3828:0:0:0:0",
			["sc"] = 0,
		},
		["Shiny Bauble"] = {
			["mr"] = 52,
			["H3219"] = 52,
		},
		["Prairie Ring of the Tiger"] = {
			["mr"] = 11100,
			["H3219"] = 11100,
		},
		["Enchanted Leather"] = {
			["mr"] = 38800,
			["H3219"] = 38800,
		},
		["Disciple's Stein of the Whale"] = {
			["mr"] = 890,
			["H3219"] = 890,
		},
		["Bandit Jerkin of Nature's Wrath"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Battlesmasher of Nature's Wrath"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Crusader Bow of Marksmanship"] = {
			["mr"] = 35000,
			["H3219"] = 35000,
		},
		["Mithril Gyro-Shot"] = {
			["mr"] = 50,
			["H3219"] = 50,
		},
		["Scaled Leather Shoulders of the Eagle"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Black Dragonscale"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Hacking Cleaver of the Whale"] = {
			["mr"] = 11082,
			["H3219"] = 11082,
		},
		["Dervish Cape of Stamina"] = {
			["mr"] = 1699,
			["H3219"] = 1699,
		},
		["Bandit Buckler of Strength"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Dervish Belt of the Owl"] = {
			["mr"] = 6999,
			["H3219"] = 6999,
		},
		["Basalt Ring of Strength"] = {
			["mr"] = 18400,
			["H3219"] = 18400,
		},
		["Jagged Star of the Monkey"] = {
			["mr"] = 3400,
			["H3219"] = 3400,
		},
		["Buccaneer's Cord of the Owl"] = {
			["mr"] = 1821,
			["H3219"] = 1821,
		},
		["Buccaneer's Cord of the Whale"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Dervish Boots of Spirit"] = {
			["mr"] = 3100,
			["H3219"] = 3100,
		},
		["Outrunner's Cloak of the Boar"] = {
			["mr"] = 1615,
			["H3219"] = 1615,
		},
		["Disciple's Pants of the Whale"] = {
			["mr"] = 383,
			["H3219"] = 383,
		},
		["Battlesmasher of the Tiger"] = {
			["mr"] = 4849,
			["H3219"] = 4849,
		},
		["Willow Vest of Spirit"] = {
			["mr"] = 1355,
			["H3219"] = 1355,
		},
		["Elder's Amber Stave of Arcane Wrath"] = {
			["mr"] = 11000,
			["H3219"] = 11000,
		},
		["Scouting Bracers of the Whale"] = {
			["mr"] = 3998,
			["H3219"] = 3998,
		},
		["Pattern: Runecloth Bag"] = {
			["H3225"] = 110000,
			["cc"] = 9,
			["H3224"] = 72500,
			["id"] = "14468:0:0:0:0",
			["sc"] = 2,
			["H3221"] = 189500,
			["mr"] = 110000,
		},
		["Runecloth Bag"] = {
			["H3225"] = 27999,
			["cc"] = 1,
			["id"] = "14046:0:0:0:0",
			["H3224"] = 27799,
			["sc"] = 0,
			["mr"] = 27999,
		},
		["Elder's Mantle of Stamina"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Severing Axe of Strength"] = {
			["mr"] = 990,
			["H3219"] = 990,
		},
		["Rigid Leggings of the Owl"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Formula: Enchant Bracer - Lesser Strength"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Soldier's Wristguards of the Whale"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Severing Axe of the Tiger"] = {
			["mr"] = 595,
			["H3219"] = 595,
		},
		["Raider's Boots of Defense"] = {
			["mr"] = 6396,
			["H3219"] = 6396,
		},
		["Bruiseweed"] = {
			["mr"] = 25,
			["H3219"] = 25,
		},
		["Spiritchaser Staff of Intellect"] = {
			["mr"] = 100000,
			["H3219"] = 100000,
		},
		["Banded Helm of Defense"] = {
			["mr"] = 16759,
			["H3219"] = 16759,
		},
		["Pattern: Dark Leather Gloves"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Scroll of Stamina"] = {
			["mr"] = 50,
			["H3219"] = 50,
		},
		["Infiltrator Cord of the Bear"] = {
			["mr"] = 2390,
			["H3219"] = 2390,
		},
		["Severing Axe of Agility"] = {
			["mr"] = 3180,
			["H3219"] = 3180,
		},
		["Ranger Gloves of Defense"] = {
			["mr"] = 22000,
			["H3219"] = 22000,
		},
		["Insignia Buckler"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Recipe: Transmute Mithril to Truesilver"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Rugged Leather"] = {
			["H3223"] = 1289,
			["H3224"] = 1215,
			["L3221"] = 1050,
			["id"] = "8170:0:0:0:0",
			["L3222"] = 545,
			["mr"] = 1215,
			["H3222"] = 1079,
			["cc"] = 7,
			["L3223"] = 994,
			["L3224"] = 1000,
			["H3221"] = 1889,
			["sc"] = 0,
		},
		["Barbaric Battle Axe of the Boar"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Barbarian War Axe of the Whale"] = {
			["mr"] = 4499,
			["H3219"] = 4499,
		},
		["Strong Fishing Pole"] = {
			["mr"] = 6349,
			["H3219"] = 6349,
		},
		["Copper Bar"] = {
			["mr"] = 47,
			["H3219"] = 47,
		},
		["Slayer's Skullcap"] = {
			["mr"] = 31935,
			["H3219"] = 31935,
		},
		["Battleforge Gauntlets of the Bear"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Stonescale Oil"] = {
			["mr"] = 5492,
			["H3219"] = 5492,
		},
		["Fortified Chain of the Bear"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Gypsy Tunic of Nature's Wrath"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Imperial Leather Belt"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Renegade Bracers of Stamina"] = {
			["mr"] = 5500,
			["H3219"] = 5500,
		},
		["Tracker's Boots of the Owl"] = {
			["mr"] = 16557,
			["H3219"] = 16557,
		},
		["Greenweave Sash of the Owl"] = {
			["mr"] = 720,
			["H3219"] = 720,
		},
		["Elder's Hat of the Eagle"] = {
			["mr"] = 22400,
			["H3219"] = 22400,
		},
		["Amber Hoop of Nature Resistance"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Green Hills of Stranglethorn - Page 20"] = {
			["mr"] = 700,
			["cc"] = 15,
			["id"] = "2744:0:0:0:0",
			["H3219"] = 700,
			["sc"] = 0,
		},
		["Stout Battlehammer of Power"] = {
			["mr"] = 2222,
			["H3219"] = 2222,
		},
		["Coral Band of the Boar"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Stylish Blue Shirt"] = {
			["mr"] = 3087,
			["H3219"] = 3087,
		},
		["Chrome Ring of the Whale"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Oak Mallet of the Gorilla"] = {
			["mr"] = 3689,
			["H3219"] = 3689,
		},
		["Merc Sword of the Wolf"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Zesty Clam Meat"] = {
			["mr"] = 190,
			["H3219"] = 190,
		},
		["Archer's Shoulderpads of the Boar"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Shimmering Cloak of Fiery Wrath"] = {
			["mr"] = 927,
			["cc"] = 4,
			["id"] = "6564:0:0:1877:0",
			["sc"] = 1,
			["H3220"] = 927,
		},
		["Pattern: Tough Scorpid Leggings"] = {
			["mr"] = 1745,
			["H3219"] = 1745,
		},
		["Defender Leggings of Strength"] = {
			["mr"] = 5372,
			["H3219"] = 5372,
		},
		["Gargoyle's Bite"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Infiltrator Pants of the Monkey"] = {
			["mr"] = 10164,
			["H3219"] = 10164,
		},
		["Elder's Boots of the Falcon"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Citrine"] = {
			["mr"] = 1090,
			["sc"] = 0,
			["id"] = "3864:0:0:0:0",
			["H3219"] = 1090,
			["cc"] = 7,
		},
		["Barbaric Cloth Vest"] = {
			["mr"] = 970,
			["H3219"] = 970,
		},
		["Pattern: Heavy Earthen Gloves"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Sentinel Cloak of Stamina"] = {
			["mr"] = 7862,
			["H3219"] = 7862,
		},
		["Scouting Bracers of the Monkey"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Bandit Cloak of the Monkey"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Dire Wolf Fang"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Pioneer Trousers of the Whale"] = {
			["mr"] = 200,
			["H3219"] = 200,
		},
		["Bandit Jerkin of the Whale"] = {
			["mr"] = 1850,
			["H3219"] = 1850,
		},
		["Sage's Pants of the Whale"] = {
			["mr"] = 3799,
			["H3219"] = 3799,
		},
		["Shimmering Robe of Spirit"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Barbaric Battle Axe of the Monkey"] = {
			["mr"] = 2374,
			["H3219"] = 2374,
		},
		["Archer's Shoulderpads of the Falcon"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Wool Cloth"] = {
			["mr"] = 99,
			["cc"] = 7,
			["id"] = "2592:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 99,
		},
		["Bandit Pants of the Falcon"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Iron Ore"] = {
			["mr"] = 870,
			["sc"] = 0,
			["id"] = "2772:0:0:0:0",
			["H3219"] = 870,
			["cc"] = 7,
		},
		["Durable Pants of the Eagle"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Recipe: Rage Potion"] = {
			["mr"] = 400,
			["sc"] = 6,
			["id"] = "5640:0:0:0:0",
			["cc"] = 9,
			["H3224"] = 400,
		},
		["Embossed Leather Cloak"] = {
			["mr"] = 219,
			["H3219"] = 219,
		},
		["Archer's Bracers of the Monkey"] = {
			["mr"] = 9600,
			["H3219"] = 9600,
		},
		["Scouting Belt of the Bear"] = {
			["mr"] = 4800,
			["H3219"] = 4800,
		},
		["Grunt's Cape of the Monkey"] = {
			["mr"] = 2499,
			["H3219"] = 2499,
		},
		["Gemmed Copper Gauntlets of Power"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Rough Stone"] = {
			["mr"] = 3,
			["H3219"] = 3,
		},
		["Furious Falchion of the Monkey"] = {
			["mr"] = 49498,
			["H3219"] = 49498,
		},
		["Tin Bar"] = {
			["mr"] = 278,
			["H3219"] = 278,
		},
		["Buccaneer's Boots of the Falcon"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Durable Tunic of the Owl"] = {
			["mr"] = 6945,
			["H3219"] = 6945,
		},
		["Ivory Band of the Bear"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Archer's Jerkin of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Bard's Trousers of the Gorilla"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Defender Cloak of the Boar"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Polished Zweihander of Strength"] = {
			["mr"] = 11631,
			["H3219"] = 11631,
		},
		["Pattern: Phoenix Gloves"] = {
			["mr"] = 4200,
			["H3219"] = 4200,
		},
		["Scaled Cloak of the Monkey"] = {
			["mr"] = 3499,
			["H3219"] = 3499,
		},
		["Ivory Band of the Boar"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Short Bastard Sword of the Boar"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Raider's Chestpiece of Power"] = {
			["mr"] = 1000,
			["H3219"] = 1000,
		},
		["Durable Hat of the Eagle"] = {
			["mr"] = 12500,
			["H3219"] = 12500,
		},
		["Magician Staff of Nature's Wrath"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Captain's Key"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Bloodspiller"] = {
			["mr"] = 22500,
			["H3219"] = 22500,
		},
		["Bard's Gloves of the Monkey"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Long Tail Feather"] = {
			["mr"] = 356,
			["sc"] = 0,
			["id"] = "5116:0:0:0:0",
			["H3219"] = 356,
			["cc"] = 5,
		},
		["Sequoia Hammer of the Monkey"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Greater Stoneshield Potion"] = {
			["mr"] = 39000,
			["sc"] = 0,
			["id"] = "13455:0:0:0:0",
			["H3225"] = 39000,
			["cc"] = 0,
		},
		["Archer's Shoulderpads of Intellect"] = {
			["mr"] = 9000,
			["H3219"] = 9000,
		},
		["Crusader Bow of the Whale"] = {
			["mr"] = 36271,
			["H3219"] = 36271,
		},
		["Infantry Leggings of Strength"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Sentinel Trousers of the Eagle"] = {
			["mr"] = 10200,
			["H3219"] = 10200,
		},
		["Formal White Shirt"] = {
			["mr"] = 589,
			["H3219"] = 589,
		},
		["Nightsky Mantle"] = {
			["mr"] = 2700,
			["H3219"] = 2700,
		},
		["Mystical Leggings of Fiery Wrath"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Scaled Cloak of the Whale"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Twilight Gloves of Healing"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Wildvine"] = {
			["mr"] = 7900,
			["cc"] = 7,
			["id"] = "8153:0:0:0:0",
			["H3216"] = 7900,
			["sc"] = 0,
		},
		["Pattern: Black Silk Pack"] = {
			["mr"] = 9263,
			["H3219"] = 9263,
		},
		["Polished Zweihander of the Monkey"] = {
			["mr"] = 5070,
			["H3219"] = 5070,
		},
		["Elder's Pants of the Owl"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["War Torn Shield of the Bear"] = {
			["mr"] = 49500,
			["H3219"] = 49500,
		},
		["Fortified Cloak of Strength"] = {
			["mr"] = 4999,
			["H3219"] = 4999,
		},
		["Hunting Tunic"] = {
			["mr"] = 495,
			["H3219"] = 495,
		},
		["Ivycloth Boots of the Eagle"] = {
			["mr"] = 9750,
			["H3219"] = 9750,
		},
		["Elder's Gloves of the Owl"] = {
			["mr"] = 4299,
			["H3219"] = 4299,
		},
		["Small Spider Leg"] = {
			["mr"] = 4,
			["H3219"] = 4,
		},
		["Elder's Gloves of Fiery Wrath"] = {
			["mr"] = 6500,
			["cc"] = 4,
			["id"] = "7366:0:0:1883:0",
			["sc"] = 1,
			["H3220"] = 6500,
		},
		["Thistle Tea"] = {
			["mr"] = 289,
			["H3219"] = 289,
		},
		["Wicked Spiked Mace"] = {
			["mr"] = 3799,
			["H3219"] = 3799,
		},
		["Arcane Crystal"] = {
			["mr"] = 495000,
			["H3219"] = 495000,
		},
		["War Knife of Fiery Wrath"] = {
			["mr"] = 2500,
			["cc"] = 2,
			["id"] = "4571:0:0:1876:0",
			["sc"] = 15,
			["H3220"] = 2500,
		},
		["Rageclaw Cloak of Stamina"] = {
			["mr"] = 10000,
			["sc"] = 1,
			["id"] = "15382:0:0:186:0",
			["H3224"] = 10000,
			["cc"] = 4,
		},
		["Fire Oil"] = {
			["mr"] = 295,
			["H3219"] = 295,
		},
		["Soldier's Shield of the Monkey"] = {
			["mr"] = 869,
			["H3219"] = 869,
		},
		["Dervish Gloves of the Whale"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Nimble Leather Gloves"] = {
			["mr"] = 795,
			["H3219"] = 795,
		},
		["Scroll of Agility II"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Buccaneer's Orb of the Wolf"] = {
			["mr"] = 13776,
			["H3219"] = 13776,
		},
		["Brown Linen Robe"] = {
			["mr"] = 205,
			["H3219"] = 205,
		},
		["Torn Bear Pelt"] = {
			["mr"] = 114,
			["H3219"] = 114,
		},
		["Silver-thread Cloak"] = {
			["mr"] = 1095,
			["H3219"] = 1095,
		},
		["Defender Tunic of Strength"] = {
			["mr"] = 3900,
			["H3219"] = 3900,
		},
		["Dry Pork Ribs"] = {
			["mr"] = 30,
			["H3219"] = 30,
		},
		["Infiltrator Cord of the Whale"] = {
			["mr"] = 3600,
			["H3219"] = 3600,
		},
		["Pattern: Wicked Leather Bracers"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Crimson Silk Shoulders"] = {
			["mr"] = 7499,
			["H3219"] = 7499,
		},
		["Rough Bronze Boots"] = {
			["mr"] = 855,
			["H3219"] = 855,
		},
		["Dazzling Longsword"] = {
			["mr"] = 399999,
			["H3219"] = 399999,
		},
		["Dervish Boots of the Gorilla"] = {
			["mr"] = 1950,
			["H3219"] = 1950,
		},
		["Defender Cloak of Stamina"] = {
			["mr"] = 1438,
			["H3219"] = 1438,
		},
		["Embersilk Bracelets of Fiery Wrath"] = {
			["mr"] = 5000,
			["cc"] = 4,
			["id"] = "14226:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 5000,
		},
		["Battleforge Boots of the Monkey"] = {
			["mr"] = 8000,
			["H3219"] = 8000,
		},
		["Spiked Club of the Gorilla"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Zircon Band of Nature Resistance"] = {
			["mr"] = 6960,
			["H3219"] = 6960,
		},
		["Skullance Shield"] = {
			["mr"] = 37500,
			["H3219"] = 37500,
		},
		["Gloom Reaper of the Bear"] = {
			["mr"] = 11400,
			["H3219"] = 11400,
		},
		["Infiltrator Cord of Intellect"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Viridian Band of the Eagle"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Khan's Cloak"] = {
			["mr"] = 9999,
			["H3219"] = 9999,
		},
		["Infiltrator Armor of the Eagle"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Pagan Belt of the Whale"] = {
			["mr"] = 2178,
			["H3219"] = 2178,
		},
		["Raptor Egg"] = {
			["mr"] = 106,
			["sc"] = 0,
			["id"] = "3685:0:0:0:0",
			["H3219"] = 106,
			["cc"] = 7,
		},
		["Felcloth Shoulders"] = {
			["mr"] = 699000,
			["cc"] = 4,
			["id"] = "14112:0:0:0:0",
			["sc"] = 1,
			["H3226"] = 699000,
		},
		["Burnished Shield"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Sungrass"] = {
			["mr"] = 2466,
			["cc"] = 7,
			["id"] = "8838:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 2466,
		},
		["Shimmering Bracers of the Whale"] = {
			["mr"] = 990,
			["H3219"] = 990,
		},
		["Lupine Mantle"] = {
			["mr"] = 2573,
			["H3219"] = 2573,
		},
		["Imposing Belt of the Monkey"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Renegade Leggings of Power"] = {
			["mr"] = 20000,
			["H3219"] = 20000,
		},
		["Ez-Thro Dynamite"] = {
			["mr"] = 899,
			["H3219"] = 899,
		},
		["Scouting Buckler of the Bear"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Soldier's Wristguards of the Monkey"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Mithril Spurs"] = {
			["mr"] = 9800,
			["H3219"] = 9800,
		},
		["Superior Shoulders of the Wolf"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Infantry Leggings of the Bear"] = {
			["mr"] = 350,
			["H3219"] = 350,
		},
		["Rigid Belt of the Whale"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Rawhide Shoulderpads"] = {
			["mr"] = 722,
			["H3219"] = 722,
		},
		["Jazeraint Cloak of the Whale"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Spiked Club of Stamina"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Thick Armor Kit"] = {
			["mr"] = 3000,
			["sc"] = 0,
			["id"] = "8173:0:0:0:0",
			["H3219"] = 3000,
			["cc"] = 0,
		},
		["Hops"] = {
			["mr"] = 17,
			["H3219"] = 17,
		},
		["Aboriginal Rod of the Falcon"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Feral Gloves of the Eagle"] = {
			["mr"] = 799,
			["H3219"] = 799,
		},
		["Bandit Cloak of Healing"] = {
			["mr"] = 4995,
			["H3219"] = 4995,
		},
		["Bolt of Woolen Cloth"] = {
			["mr"] = 399,
			["cc"] = 7,
			["id"] = "2997:0:0:0:0",
			["sc"] = 0,
			["H3224"] = 399,
		},
		["Ballast Maul of the Boar"] = {
			["mr"] = 25335,
			["H3219"] = 25335,
		},
		["Lesser Eternal Essence"] = {
			["mr"] = 12000,
			["cc"] = 7,
			["id"] = "16202:0:0:0:0",
			["H3221"] = 12000,
			["sc"] = 0,
		},
		["Superior Leggings of Power"] = {
			["mr"] = 8999,
			["H3219"] = 8999,
		},
		["Soldier's Gauntlets of Strength"] = {
			["mr"] = 910,
			["H3219"] = 910,
		},
		["Thorium Bar"] = {
			["H3223"] = 7500,
			["mr"] = 7500,
			["H3222"] = 5400,
			["id"] = "12359:0:0:0:0",
			["sc"] = 0,
			["cc"] = 7,
		},
		["Knight's Pauldrons of the Boar"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Red Fireworks Rocket"] = {
			["mr"] = 72,
			["H3219"] = 72,
		},
		["Fen Ring of Eluding"] = {
			["mr"] = 10000,
			["H3219"] = 10000,
		},
		["Gnoll War Harness"] = {
			["mr"] = 520,
			["H3219"] = 520,
		},
		["Spellbinder Orb"] = {
			["mr"] = 970,
			["H3219"] = 970,
		},
		["Oak Mallet of Strength"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Lupine Leggings of Healing"] = {
			["mr"] = 1400,
			["H3219"] = 1400,
		},
		["Giant Clam Meat"] = {
			["mr"] = 308,
			["H3219"] = 308,
		},
		["Pattern: Deviate Scale Belt"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Edged Bastard Sword of the Whale"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Banded Bracers of Strength"] = {
			["mr"] = 4200,
			["H3219"] = 4200,
		},
		["Black Pearl"] = {
			["mr"] = 1300,
			["sc"] = 0,
			["id"] = "7971:0:0:0:0",
			["H3219"] = 1300,
			["cc"] = 7,
		},
		["Burnished Tunic"] = {
			["mr"] = 1695,
			["H3219"] = 1695,
		},
		["Brown Linen Shirt"] = {
			["mr"] = 19,
			["H3219"] = 19,
		},
		["Banded Leggings of the Bear"] = {
			["mr"] = 4078,
			["H3219"] = 4078,
		},
		["Hematite Link of Fire Resistance"] = {
			["mr"] = 150000,
			["sc"] = 0,
			["id"] = "11973:0:0:1412:0",
			["H3224"] = 150000,
			["cc"] = 4,
		},
		["Green Lens of Fiery Wrath"] = {
			["mr"] = 149500,
			["cc"] = 4,
			["id"] = "10504:0:0:1899:0",
			["sc"] = 1,
			["H3220"] = 149500,
		},
		["Heavy Bronze Mace"] = {
			["mr"] = 6999,
			["H3219"] = 6999,
		},
		["Battleforge Shoulderguards of Stamina"] = {
			["mr"] = 12600,
			["H3219"] = 12600,
		},
		["Scaled Leather Tunic of the Whale"] = {
			["mr"] = 6556,
			["H3219"] = 6556,
		},
		["Black Mageweave Leggings"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Cross-stitched Shoulderpads"] = {
			["mr"] = 1093,
			["H3219"] = 1093,
		},
		["Shimmering Armor of the Whale"] = {
			["mr"] = 1999,
			["H3219"] = 1999,
		},
		["Fortified Gauntlets of the Bear"] = {
			["mr"] = 1900,
			["H3219"] = 1900,
		},
		["Carving Knife of Power"] = {
			["mr"] = 550,
			["H3219"] = 550,
		},
		["Black Metal War Axe"] = {
			["mr"] = 4777,
			["H3219"] = 4777,
		},
		["Polished Zweihander of the Wolf"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Vibrant Plume"] = {
			["mr"] = 919,
			["cc"] = 15,
			["id"] = "5117:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 919,
		},
		["Spiritchaser Staff of Healing"] = {
			["mr"] = 70000,
			["H3219"] = 70000,
		},
		["Target Dummy"] = {
			["mr"] = 1166,
			["H3219"] = 1166,
		},
		["Massive Battle Axe of the Whale"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Forest Leather Boots"] = {
			["mr"] = 975,
			["H3219"] = 975,
		},
		["Ranger Gloves of the Whale"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Thick Wolfhide"] = {
			["mr"] = 4300,
			["H3219"] = 4300,
		},
		["Battle Slayer of Strength"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Bandit Cloak of Agility"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Elder's Mantle of Arcane Wrath"] = {
			["mr"] = 3500,
			["H3219"] = 3500,
		},
		["Lupine Vest of Spirit"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Scimitar of Atun"] = {
			["mr"] = 4550,
			["H3219"] = 4550,
		},
		["Lupine Leggings of the Monkey"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Greenstone Talisman of Spirit"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Edged Bastard Sword of the Boar"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Twilight Mantle of Stamina"] = {
			["mr"] = 10072,
			["H3219"] = 10072,
		},
		["Traveler's Gloves"] = {
			["mr"] = 20000,
			["cc"] = 4,
			["id"] = "8298:0:0:0:0",
			["sc"] = 2,
			["H3226"] = 20000,
		},
		["Shadoweave Mask"] = {
			["mr"] = 39624,
			["H3219"] = 39624,
		},
		["Pagan Shoes of the Owl"] = {
			["mr"] = 4638,
			["H3219"] = 4638,
		},
		["Ridge Cleaver of the Boar"] = {
			["mr"] = 4144,
			["H3219"] = 4144,
		},
		["Gypsy Trousers of the Wolf"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Sorcerer Gloves of Fiery Wrath"] = {
			["mr"] = 3900,
			["cc"] = 4,
			["id"] = "9880:0:0:1886:0",
			["sc"] = 1,
			["H3220"] = 3900,
		},
		["Bard's Bracers of the Whale"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Knight's Boots of the Gorilla"] = {
			["mr"] = 24999,
			["H3219"] = 24999,
		},
		["Fletcher's Gloves"] = {
			["mr"] = 1990,
			["H3219"] = 1990,
		},
		["Red Power Crystal"] = {
			["mr"] = 709,
			["H3219"] = 709,
		},
		["Dervish Belt of the Monkey"] = {
			["mr"] = 11900,
			["H3219"] = 11900,
		},
		["Pioneer Trousers of Spirit"] = {
			["mr"] = 489,
			["H3219"] = 489,
		},
		["Basalt Necklace of the Bear"] = {
			["mr"] = 45000,
			["H3219"] = 45000,
		},
		["Renegade Bracers of Power"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Carving Knife of Stamina"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Defender Boots of the Bear"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Acrobatic Staff of Arcane Wrath"] = {
			["mr"] = 11800,
			["H3219"] = 11800,
		},
		["Merc Sword of Agility"] = {
			["mr"] = 4500,
			["H3219"] = 4500,
		},
		["Ancestral Woollies"] = {
			["mr"] = 2500,
			["cc"] = 4,
			["id"] = "3291:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 2500,
		},
		["Battle Slayer of the Tiger"] = {
			["mr"] = 2900,
			["H3219"] = 2900,
		},
		["Jacinth Circle of Shadow Resistance"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Curved Dagger of Stamina"] = {
			["mr"] = 1100,
			["H3219"] = 1100,
		},
		["Peacebloom"] = {
			["mr"] = 9,
			["H3219"] = 9,
		},
		["Sorcerer Cloak of the Eagle"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Runed Copper Breastplate"] = {
			["mr"] = 1015,
			["H3219"] = 1015,
		},
		["Sturdy Quarterstaff of Power"] = {
			["mr"] = 700,
			["H3219"] = 700,
		},
		["Raider's Chestpiece of the Boar"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Phalanx Headguard of the Monkey"] = {
			["mr"] = 8500,
			["H3219"] = 8500,
		},
		["Barbed Club of Power"] = {
			["mr"] = 1828,
			["H3219"] = 1828,
		},
		["Buccaneer's Pants of the Owl"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Cerulean Ring of Spirit"] = {
			["mr"] = 14999,
			["H3219"] = 14999,
		},
		["Scroll of Agility III"] = {
			["mr"] = 1995,
			["H3219"] = 1995,
		},
		["Ivycloth Cloak of the Eagle"] = {
			["mr"] = 2799,
			["H3219"] = 2799,
		},
		["Lesser Healing Potion"] = {
			["mr"] = 32,
			["cc"] = 0,
			["id"] = "858:0:0:0:0",
			["H3219"] = 32,
			["sc"] = 0,
		},
		["Skystriker Bow"] = {
			["mr"] = 49800,
			["H3219"] = 49800,
		},
		["Battlesmasher of Power"] = {
			["mr"] = 4199,
			["H3219"] = 4199,
		},
		["Sequoia Hammer of the Bear"] = {
			["mr"] = 11600,
			["H3219"] = 11600,
		},
		["Elixir of Agility"] = {
			["H3223"] = 499,
			["mr"] = 499,
			["cc"] = 0,
			["id"] = "8949:0:0:0:0",
			["sc"] = 0,
		},
		["Short Bastard Sword of the Wolf"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Ivycloth Pants of Fiery Wrath"] = {
			["mr"] = 6666,
			["cc"] = 4,
			["id"] = "9797:0:0:1884:0",
			["sc"] = 1,
			["H3220"] = 6666,
		},
		["Prospector's Cloak"] = {
			["mr"] = 1195,
			["H3219"] = 1195,
		},
		["Wolf Rider's Shoulder Pads of the Monkey"] = {
			["mr"] = 22000,
			["H3219"] = 22000,
		},
		["Splitting Hatchet of the Bear"] = {
			["mr"] = 8899,
			["H3219"] = 8899,
		},
		["Rigid Shoulders of the Whale"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Archer's Cap of the Whale"] = {
			["mr"] = 8356,
			["H3219"] = 8356,
		},
		["Barbed Club of Stamina"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Fadeleaf"] = {
			["mr"] = 223,
			["sc"] = 0,
			["id"] = "3818:0:0:0:0",
			["H3219"] = 223,
			["cc"] = 7,
		},
		["Schematic: Catseye Ultra Goggles"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Sylvan Cloak"] = {
			["mr"] = 8796,
			["H3219"] = 8796,
		},
		["Blackwater Cutlass"] = {
			["mr"] = 1600,
			["H3219"] = 1600,
		},
		["Superior Buckler of Agility"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Outrunner's Slippers of the Whale"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Scaled Leather Gloves of Spirit"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Dwarven Magestaff of the Monkey"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Small Hand Blade"] = {
			["mr"] = 1800,
			["H3219"] = 1800,
		},
		["Bloodforged Shoulder Pads of Defense"] = {
			["mr"] = 43414,
			["H3219"] = 43414,
		},
		["Scouting Boots of the Gorilla"] = {
			["mr"] = 999,
			["H3219"] = 999,
		},
		["Grizzly Buckler of the Owl"] = {
			["mr"] = 600,
			["H3219"] = 600,
		},
		["Jacinth Circle of Frost Resistance"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Regal Mantle of the Owl"] = {
			["mr"] = 13999,
			["H3219"] = 13999,
		},
		["Dark Leather Tunic"] = {
			["mr"] = 800,
			["H3219"] = 800,
		},
		["Brutal War Axe of the Whale"] = {
			["mr"] = 7000,
			["H3219"] = 7000,
		},
		["Tender Crocolisk Meat"] = {
			["mr"] = 136,
			["H3219"] = 136,
		},
		["Silver-linked Footguards"] = {
			["mr"] = 12800,
			["H3219"] = 12800,
		},
		["Pattern: Green Leather Armor"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Murloc Eye"] = {
			["mr"] = 16,
			["H3219"] = 16,
		},
		["Gaea's Tunic of Spirit"] = {
			["mr"] = 56796,
			["H3219"] = 56796,
		},
		["Mutton Chop"] = {
			["mr"] = 38,
			["H3219"] = 38,
		},
		["Looming Gavel"] = {
			["mr"] = 32499,
			["H3219"] = 32499,
		},
		["Cat Carrier (White Kitten)"] = {
			["mr"] = 44800,
			["cc"] = 15,
			["id"] = "8489:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 44800,
		},
		["Bandit Cinch of the Whale"] = {
			["mr"] = 650,
			["H3219"] = 650,
		},
		["Drakewing Bands"] = {
			["mr"] = 2400,
			["H3219"] = 2400,
		},
		["Scroll of Intellect II"] = {
			["mr"] = 435,
			["H3219"] = 435,
		},
		["Spiked Chain Cloak of Defense"] = {
			["mr"] = 1500,
			["H3219"] = 1500,
		},
		["Bonelink Sabatons of the Owl"] = {
			["mr"] = 26361,
			["H3219"] = 26361,
		},
		["Vital Boots of the Falcon"] = {
			["mr"] = 6436,
			["H3219"] = 6436,
		},
		["Twilight Robe of the Owl"] = {
			["mr"] = 12000,
			["H3219"] = 12000,
		},
		["Brutal War Axe of the Wolf"] = {
			["mr"] = 10696,
			["H3219"] = 10696,
		},
		["Shadowgem"] = {
			["mr"] = 250,
			["H3219"] = 250,
		},
		["Shimmering Boots of Spirit"] = {
			["mr"] = 1299,
			["H3219"] = 1299,
		},
		["Holy Shroud"] = {
			["mr"] = 52500,
			["H3219"] = 52500,
		},
		["Sturdy Quarterstaff of Spirit"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Scaled Leather Tunic of Agility"] = {
			["mr"] = 9900,
			["H3219"] = 9900,
		},
		["Jacinth Circle of Nature Resistance"] = {
			["mr"] = 3300,
			["H3219"] = 3300,
		},
		["Elixir of Greater Defense"] = {
			["H3223"] = 449,
			["mr"] = 449,
			["cc"] = 0,
			["id"] = "8951:0:0:0:0",
			["sc"] = 0,
		},
		["Robe of the Magi"] = {
			["mr"] = 138240,
			["H3219"] = 138240,
		},
		["Recipe: Ghost Dye"] = {
			["mr"] = 43000,
			["H3219"] = 43000,
		},
		["Honed Stiletto of Power"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Scalping Tomahawk of Strength"] = {
			["mr"] = 500,
			["H3219"] = 500,
		},
		["Spider's Silk"] = {
			["mr"] = 1190,
			["sc"] = 0,
			["id"] = "3182:0:0:0:0",
			["H3219"] = 1190,
			["cc"] = 7,
		},
		["Glyphed Epaulets"] = {
			["mr"] = 7300,
			["H3219"] = 7300,
		},
		["Buccaneer's Mantle"] = {
			["mr"] = 1450,
			["H3219"] = 1450,
		},
		["Formula: Enchant Bracer - Lesser Deflection"] = {
			["mr"] = 2800,
			["H3219"] = 2800,
		},
		["Superior Cloak of the Wolf"] = {
			["mr"] = 1988,
			["H3219"] = 1988,
		},
		["Pagan Cape of the Eagle"] = {
			["mr"] = 1665,
			["H3219"] = 1665,
		},
		["Silverleaf"] = {
			["mr"] = 10,
			["H3219"] = 10,
		},
		["Leaden Mace of the Monkey"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Soldier's Wristguards of Stamina"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Bard's Belt of the Tiger"] = {
			["mr"] = 900,
			["H3219"] = 900,
		},
		["Superior Healing Potion"] = {
			["mr"] = 1500,
			["sc"] = 0,
			["id"] = "3928:0:0:0:0",
			["cc"] = 0,
			["H3224"] = 1500,
		},
		["Elder's Bracers of the Owl"] = {
			["mr"] = 2100,
			["H3219"] = 2100,
		},
		["Rigid Shoulders of Intellect"] = {
			["mr"] = 5900,
			["H3219"] = 5900,
		},
		["Bloodspattered Surcoat of Stamina"] = {
			["mr"] = 1763,
			["H3219"] = 1763,
		},
		["Heraldic Boots"] = {
			["mr"] = 18800,
			["H3219"] = 18800,
		},
		["Ranger Gloves of the Falcon"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Hulking Belt"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Durable Rod of the Eagle"] = {
			["mr"] = 7500,
			["H3219"] = 7500,
		},
		["Spiritchaser Staff of the Eagle"] = {
			["mr"] = 53500,
			["H3219"] = 53500,
		},
		["Superior Cloak of Intellect"] = {
			["mr"] = 2127,
			["H3219"] = 2127,
		},
		["Nightsky Gloves"] = {
			["mr"] = 4900,
			["H3219"] = 4900,
		},
		["Lupine Leggings of the Owl"] = {
			["mr"] = 1674,
			["H3219"] = 1674,
		},
		["Captain's Cloak of the Whale"] = {
			["mr"] = 4998,
			["H3219"] = 4998,
		},
		["Sentry's Cape of the Bear"] = {
			["mr"] = 2999,
			["H3219"] = 2999,
		},
		["Crocolisk Meat"] = {
			["mr"] = 498,
			["H3219"] = 498,
		},
		["Stringy Wolf Meat"] = {
			["mr"] = 194,
			["H3219"] = 194,
		},
		["Shimmering Gloves of the Monkey"] = {
			["mr"] = 1200,
			["H3219"] = 1200,
		},
		["Gypsy Buckler of Defense"] = {
			["mr"] = 963,
			["H3219"] = 963,
		},
		["Lupine Cord of the Monkey"] = {
			["mr"] = 2000,
			["H3219"] = 2000,
		},
		["Cutthroat's Armguards of the Monkey"] = {
			["mr"] = 17000,
			["H3219"] = 17000,
		},
		["Sage's Sash of Fiery Wrath"] = {
			["mr"] = 4769,
			["cc"] = 4,
			["id"] = "6611:0:0:1882:0",
			["sc"] = 1,
			["H3220"] = 4769,
		},
		["Phalanx Girdle of the Monkey"] = {
			["mr"] = 15000,
			["H3219"] = 15000,
		},
		["Edged Bastard Sword of the Tiger"] = {
			["mr"] = 3200,
			["H3219"] = 3200,
		},
		["Thallium Hoop of the Owl"] = {
			["mr"] = 12035,
			["H3219"] = 12035,
		},
		["Defender Cloak of Defense"] = {
			["mr"] = 675,
			["H3219"] = 675,
		},
		["Pattern: Murloc Scale Belt"] = {
			["mr"] = 399,
			["H3219"] = 399,
		},
		["Snickerfang Jowl"] = {
			["mr"] = 1194,
			["cc"] = 12,
			["id"] = "8391:0:0:0:0",
			["sc"] = 0,
			["H3220"] = 1194,
		},
		["Foamspittle Staff"] = {
			["mr"] = 4000,
			["H3219"] = 4000,
		},
		["Jouster's Visor"] = {
			["mr"] = 15500,
			["H3219"] = 15500,
		},
		["Tomb Dust"] = {
			["mr"] = 290,
			["H3219"] = 290,
		},
		["Scroll of Spirit II"] = {
			["mr"] = 157,
			["H3219"] = 157,
		},
		["Polished Zweihander of the Boar"] = {
			["mr"] = 6500,
			["H3219"] = 6500,
		},
		["Lesser Mystic Essence"] = {
			["mr"] = 715,
			["sc"] = 0,
			["id"] = "11134:0:0:0:0",
			["H3219"] = 715,
			["cc"] = 7,
		},
		["Sanguine Handwraps"] = {
			["mr"] = 2600,
			["H3219"] = 2600,
		},
		["Ballast Maul of the Gorilla"] = {
			["mr"] = 18900,
			["H3219"] = 18900,
		},
		["Merc Sword of the Whale"] = {
			["mr"] = 2200,
			["H3219"] = 2200,
		},
		["Twilight Belt of Healing"] = {
			["mr"] = 14900,
			["H3219"] = 14900,
		},
		["Giant Tarantula Fang"] = {
			["mr"] = 2300,
			["H3219"] = 2300,
		},
		["Murloc Fin"] = {
			["mr"] = 97,
			["H3219"] = 97,
		},
		["Nightscape Tunic"] = {
			["mr"] = 7799,
			["H3219"] = 7799,
		},
		["Scroll of Stamina II"] = {
			["mr"] = 329,
			["H3219"] = 329,
		},
		["Plans: Gemmed Copper Gauntlets"] = {
			["mr"] = 494,
			["H3219"] = 494,
		},
		["Blue Leather Bag"] = {
			["mr"] = 885,
			["H3219"] = 885,
		},
		["Birchwood Maul of the Tiger"] = {
			["mr"] = 1390,
			["H3219"] = 1390,
		},
		["Bloodforged Belt of the Bear"] = {
			["mr"] = 40000,
			["H3219"] = 40000,
		},
		["Conjurer's Breeches of Spirit"] = {
			["mr"] = 5000,
			["H3219"] = 5000,
		},
		["Starsight Tunic"] = {
			["mr"] = 3000,
			["H3219"] = 3000,
		},
		["Geomancer's Gloves of the Eagle"] = {
			["mr"] = 10447,
			["H3219"] = 10447,
		},
		["Firebloom"] = {
			["mr"] = 298,
			["H3219"] = 298,
		},
		["Battleforge Shield of Stamina"] = {
			["mr"] = 9400,
			["H3219"] = 9400,
		},
		["Seer's Robe"] = {
			["mr"] = 2500,
			["H3219"] = 2500,
		},
		["Twilight Cuffs of Spirit"] = {
			["mr"] = 6000,
			["H3219"] = 6000,
		},
		["Bard's Buckler of the Gorilla"] = {
			["mr"] = 1480,
			["H3219"] = 1480,
		},
		["Woolen Cape"] = {
			["mr"] = 196,
			["cc"] = 4,
			["id"] = "2584:0:0:0:0",
			["sc"] = 1,
			["H3224"] = 196,
		},
	},
}
AUCTIONATOR_LAST_SCAN_TIME = 1567993084
AUCTIONATOR_TOONS = {
	["Flidrobank"] = {
		["firstSeen"] = 1567119042,
		["guid"] = "Player-4385-0093005E",
		["firstVersion"] = "8.1.0",
	},
	["Flidro"] = {
		["firstSeen"] = 1567119780,
		["firstVersion"] = "8.1.0",
		["guid"] = "Player-4385-0039C104",
	},
	["Wahaha"] = {
		["firstSeen"] = 1568465277,
		["firstVersion"] = "8.1.0",
		["guid"] = "Player-4385-0121AA80",
	},
}
AUCTIONATOR_STACKING_PREFS = {
	["green hills of stranglethorn - page 21"] = {
		["numstacks"] = 0,
		["stacksize"] = 1,
	},
	["black pearl"] = {
		["numstacks"] = 0,
		["stacksize"] = 1,
	},
	["green hills of stranglethorn - page 20"] = {
		["stacksize"] = 1,
		["numstacks"] = 0,
	},
	["green hills of stranglethorn - page 10"] = {
		["stacksize"] = 1,
		["numstacks"] = 0,
	},
	["green hills of stranglethorn - page 26"] = {
		["numstacks"] = 0,
		["stacksize"] = 1,
	},
	["thick leather"] = {
		["stacksize"] = 20,
		["numstacks"] = 0,
	},
}
AUCTIONATOR_SCAN_MINLEVEL = 1
AUCTIONATOR_DB_MAXITEM_AGE = 180
AUCTIONATOR_DB_MAXHIST_AGE = -1
AUCTIONATOR_DB_MAXHIST_DAYS = 5
AUCTIONATOR_FS_CHUNK = nil
AUCTIONATOR_DE_DATA = nil
AUCTIONATOR_DE_DATA_BAK = nil
ITEM_ID_VERSION = "3.2.6"
AUCTIONATOR_SHOW_MAILBOX_TIPS = nil
