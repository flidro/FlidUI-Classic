
AtlasLootClassicDB = {
	["global"] = {
		["__addonrevision"] = 1010011,
	},
	["profileKeys"] = {
		["Flidro - Pagle"] = "Flidro - Pagle",
		["Flidrobank - Pagle"] = "Flidrobank - Pagle",
	},
	["profiles"] = {
		["Flidro - Pagle"] = {
			["GUI"] = {
				["point"] = {
					"LEFT", -- [1]
					nil, -- [2]
					"LEFT", -- [3]
					183.174499511719, -- [4]
					47.6986045837402, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"Stratholme", -- [2]
					12, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 175.867728368935,
			},
			["Addons"] = {
				["Favourites"] = {
					["lists"] = {
						["ProfileBase"] = {
							[12927] = true,
							[11684] = true,
						},
					},
				},
			},
		},
		["Flidrobank - Pagle"] = {
		},
	},
}
