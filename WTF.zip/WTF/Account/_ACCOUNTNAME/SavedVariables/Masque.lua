
MasqueDB = {
	["profileKeys"] = {
		["Flidro - Pagle"] = "Default",
		["Flidro - Stalagg"] = "Default",
		["Flidrobank - Pagle"] = "Default",
		["Wahaha - Pagle"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["Raven_Debuffs"] = {
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["Dominos_Action Bar"] = {
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
				["Masque"] = {
					["SkinID"] = "Apathy",
				},
				["Raven_Buffs"] = {
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["WeakAuras_warrior_-_no_weapon"] = {
					["Disabled"] = true,
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
				["WeakAuras_warrior_-_battle_shout_missing"] = {
					["Disabled"] = true,
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["WeakAuras_warrior_-_overpower"] = {
					["Disabled"] = true,
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["Dominos_Bag Bar"] = {
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
				["Raven"] = {
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["Raven_Long Debuffs"] = {
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["WeakAuras_new"] = {
					["Disabled"] = true,
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["Dominos"] = {
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
				["Dominos_Class Bar"] = {
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
				["WeakAuras"] = {
					["Disabled"] = true,
					["SkinID"] = "Apathy",
					["Inherit"] = false,
				},
				["Dominos_Pet Bar"] = {
					["Inherit"] = false,
					["SkinID"] = "Apathy",
				},
			},
		},
	},
}
