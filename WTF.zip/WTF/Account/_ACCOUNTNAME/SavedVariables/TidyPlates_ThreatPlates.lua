
ThreatPlatesDB = {
	["char"] = {
		["Flidro - Pagle"] = {
			["welcome"] = true,
		},
		["Flidro - Stalagg"] = {
			["welcome"] = true,
		},
		["Flidrobank - Pagle"] = {
			["welcome"] = true,
		},
		["Wahaha - Pagle"] = {
			["welcome"] = true,
		},
	},
	["global"] = {
		["version"] = "1.2.3",
	},
	["profileKeys"] = {
		["Flidro - Pagle"] = "Default",
		["Flidro - Stalagg"] = "Default",
		["Flidrobank - Pagle"] = "Default",
		["Wahaha - Pagle"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["uniqueSettings"] = {
				["map"] = {
					["Fanged Pit Viper"] = {
					},
					["Empowered Adherent"] = {
					},
					["Kinetic Bomb"] = {
					},
					["Marked Immortal Guardian"] = {
					},
					["Shadow Fiend"] = {
					},
					["Viper"] = {
					},
					["Web Wrap"] = {
					},
					["Muddy Crawfish"] = {
					},
					["Reanimated Fanatic"] = {
					},
					["Water Elemental"] = {
					},
					["Spirit Wolf"] = {
					},
					["Darnavan"] = {
					},
					["Treant"] = {
					},
					["Volatile Ooze"] = {
					},
					["Living Ember"] = {
					},
					["Gas Cloud"] = {
					},
					["Ebon Gargoyle"] = {
					},
					["Shadowy Apparition"] = {
					},
					["Drudge Ghoul"] = {
					},
					["Raging Spirit"] = {
					},
					["Bone Spike"] = {
					},
					["Deformed Fanatic"] = {
					},
					["Val'kyr Shadowguard"] = {
					},
					["Lich King"] = {
					},
					["Army of the Dead Ghoul"] = {
					},
					["Shambling Horror"] = {
					},
					["Living Inferno"] = {
					},
					["Onyxian Whelp"] = {
					},
					["Venomous Snake"] = {
					},
					["Reanimated Adherent"] = {
					},
					["Canal Crab"] = {
					},
					["Immortal Guardian"] = {
					},
				},
			},
			["cache"] = {
			},
			["settings"] = {
				["customtext"] = {
					["typeface"] = "Accidental Presidency",
				},
				["elitehealthborder"] = {
					["texture"] = "TP_EliteBorder_Thin",
				},
				["level"] = {
					["typeface"] = "Accidental Presidency",
				},
				["healthbar"] = {
					["backdrop"] = "Flat",
					["texture"] = "Flat",
				},
				["healthborder"] = {
					["EdgeSize"] = 2,
					["Offset"] = 2,
					["texture"] = "TP_Border_Default",
				},
				["name"] = {
					["typeface"] = "Accidental Presidency",
				},
			},
		},
	},
}
