
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
			["profiles"] = {
				["Tank"] = {
					["remainingtext"] = false,
					["barcolor"] = {
						0.482352941176471, -- [1]
						0.71764705882353, -- [2]
						0.96078431372549, -- [3]
						1, -- [4]
					},
					["durationtext"] = false,
					["swingheight"] = 10,
				},
				["Default"] = {
					["barcolor"] = {
						0.482352941176471, -- [1]
						0.71764705882353, -- [2]
						0.96078431372549, -- [3]
						1, -- [4]
					},
					["swingheight"] = 7,
					["remainingtext"] = false,
					["durationtext"] = false,
				},
				["Fliddot"] = {
					["y"] = 163.171890258789,
					["durationtext"] = false,
					["swingheight"] = 6,
					["barcolor"] = {
						0.482352941176471, -- [1]
						0.71764705882353, -- [2]
						0.96078431372549, -- [3]
						1, -- [4]
					},
					["x"] = 809.987670898438,
					["swingposition"] = "bottom",
				},
			},
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Tank"] = {
					["x"] = 860.00001313035,
				},
				["Default"] = {
					["x"] = 860.00001313035,
				},
				["Fliddot"] = {
					["x"] = 860.00001313035,
				},
			},
		},
		["Player"] = {
			["profiles"] = {
				["Tank"] = {
					["hideicon"] = true,
					["h"] = 17,
					["y"] = 296.999725341797,
					["w"] = 300,
					["x"] = 805.000244140625,
					["border"] = "None",
					["texture"] = "Flat",
				},
				["Default"] = {
					["h"] = 17,
					["w"] = 309,
					["y"] = 230,
					["font"] = "Accidental Presidency",
					["border"] = "None",
					["x"] = 816,
					["texture"] = "Flat",
					["hideicon"] = true,
				},
				["Fliddot"] = {
					["hideicon"] = true,
					["h"] = 17,
					["y"] = 170,
					["border"] = "None",
					["font"] = "Accidental Presidency",
					["x"] = 804,
					["w"] = 300,
					["texture"] = "Flat",
				},
			},
		},
		["EnemyCasts"] = {
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Tank"] = {
					["hideicon"] = true,
					["h"] = 17,
					["y"] = 275.5,
					["w"] = 123,
					["x"] = 1405,
					["border"] = "None",
					["texture"] = "Minimalist",
				},
				["Default"] = {
					["hideicon"] = true,
					["h"] = 17,
					["y"] = 280,
					["w"] = 135,
					["x"] = 1403.00012207031,
					["border"] = "None",
					["texture"] = "Flat",
				},
				["Fliddot"] = {
					["y"] = 280,
					["h"] = 17,
					["hideicon"] = true,
					["w"] = 135,
					["x"] = 1403.00012207031,
					["border"] = "None",
					["texture"] = "Flat",
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Tank"] = {
					["noInterruptBorderColor"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["noInterruptChangeBorder"] = true,
					["w"] = 610,
					["noInterruptChangeColor"] = true,
					["hideicon"] = true,
					["x"] = 655.00001313035,
					["y"] = 718,
					["noInterruptColor"] = {
						nil, -- [1]
						0, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["noInterruptBorder"] = "Square Clean",
					["border"] = "None",
					["texture"] = "Flat",
				},
				["Default"] = {
					["iconposition"] = "left",
					["noInterruptBorderColor"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["x"] = 653.801452636719,
					["icongap"] = 3,
					["noInterruptChangeBorder"] = true,
					["w"] = 610,
					["noInterruptChangeColor"] = true,
					["y"] = 715,
					["font"] = "Accidental Presidency",
					["border"] = "None",
					["noInterruptColor"] = {
						nil, -- [1]
						0, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["h"] = 19,
					["noInterruptBorder"] = "Square Clean",
					["hideicon"] = true,
					["texture"] = "Flat",
				},
				["Fliddot"] = {
					["iconposition"] = "left",
					["noInterruptBorderColor"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["x"] = 653.801452636719,
					["icongap"] = 3,
					["noInterruptChangeBorder"] = true,
					["w"] = 610,
					["noInterruptChangeColor"] = true,
					["y"] = 745,
					["font"] = "Accidental Presidency",
					["border"] = "None",
					["noInterruptColor"] = {
						nil, -- [1]
						0, -- [2]
						nil, -- [3]
						1, -- [4]
					},
					["h"] = 19,
					["noInterruptBorder"] = "Square Clean",
					["hideicon"] = true,
					["texture"] = "Flat",
				},
			},
		},
		["Mirror"] = {
			["profiles"] = {
				["Tank"] = {
					["mirroricons"] = false,
					["mirrortexture"] = "Bars",
					["mirrorfontsize"] = 12,
					["mirrory"] = 334,
					["mirroranchor"] = "free",
					["mirrorx"] = 810,
					["mirrorheight"] = 19,
					["mirrorwidth"] = 300,
				},
				["Default"] = {
					["mirroricons"] = false,
					["mirroroffset"] = 0,
					["mirroranchor"] = "target",
					["mirrory"] = 692,
					["mirrorgap"] = 3,
					["mirrorheight"] = 21,
					["mirrortexture"] = "Raven Mesh",
					["mirrorfont"] = "Accidental Presidency",
					["mirrorx"] = 810,
					["mirrorposition"] = "bottom",
					["mirrorwidth"] = 300,
					["mirrorfontsize"] = 12,
				},
				["Fliddot"] = {
					["mirroricons"] = false,
					["mirrorposition"] = "bottom",
					["mirrorwidth"] = 300,
					["mirroroffset"] = 0,
					["mirrorfontsize"] = 12,
					["mirrortexture"] = "Raven Mesh",
					["mirrorfont"] = "Accidental Presidency",
					["mirrory"] = 692,
					["mirroranchor"] = "target",
					["mirrorx"] = 810,
					["mirrorgap"] = 3,
					["mirrorheight"] = 21,
				},
			},
		},
		["Range"] = {
			["profiles"] = {
				["Tank"] = {
					["rangecolor"] = {
						0.847058823529412, -- [1]
						0, -- [2]
						0.0431372549019608, -- [3]
						1, -- [4]
					},
				},
				["Default"] = {
					["rangecolor"] = {
						0.847058823529412, -- [1]
						0, -- [2]
						0.0431372549019608, -- [3]
						1, -- [4]
					},
				},
				["Fliddot"] = {
					["rangecolor"] = {
						0.847058823529412, -- [1]
						0, -- [2]
						0.0431372549019608, -- [3]
						1, -- [4]
					},
				},
			},
		},
		["Latency"] = {
			["profiles"] = {
				["Fliddot"] = {
					["lagcolor"] = {
						0.549019607843137, -- [1]
						0.568627450980392, -- [2]
						0.486274509803922, -- [3]
						1, -- [4]
					},
					["lagtext"] = false,
					["lagfont"] = "Accidental Presidency",
					["lagalpha"] = 0.25,
				},
			},
		},
	},
	["profileKeys"] = {
		["Fyldro - Mannoroth"] = "Default",
		["Flyddi - Mannoroth"] = "Default",
		["Smooshin - Rexxar"] = "Default",
		["Iliketocluck - Mal'Ganis"] = "Default",
		["Frente - Magtheridon"] = "Default",
		["Fliddot - Malygos"] = "Default",
		["Flidro - Mal'Ganis"] = "Fliddot",
		["Lusbank - Chromaggus"] = "Default",
		["Flidrobank - Magtheridon"] = "Default",
		["Johric - Malygos"] = "Default",
		["Wahaha - Pagle"] = "Default",
		["Fliddums - Mal'Ganis"] = "Default",
		["Fliddy - Mannoroth"] = "Default",
		["Phlydro - Mannoroth"] = "Default",
		["Flidiot - Mal'Ganis"] = "Default",
		["Flidrogue - Mal'Ganis"] = "Fliddot",
		["Frente - Emerald Dream"] = "Default",
		["Flidrobank - Mannoroth"] = "Default",
		["Flidrobank - Pagle"] = "Default",
		["Scydro - Mannoroth"] = "Default",
		["Notflidro - Mal'Ganis"] = "Default",
		["Flidrobank - Mal'Ganis"] = "Default",
		["Flid - Mal'Ganis"] = "Default",
		["Slydro - Mannoroth"] = "Default",
		["Fliddy - Mal'Ganis"] = "Default",
		["Flidro - Emerald Dream"] = "Default",
		["Fliddo - Kel'Thuzad"] = "Default",
		["Priceofevil - Rexxar"] = "Default",
		["Hoyt - Rexxar"] = "Default",
		["Bismal - Malygos"] = "Default",
		["Lolbadpally - Rexxar"] = "Default",
		["Treefliddy - Mal'Ganis"] = "Default",
		["Zulamari - Malygos"] = "Default",
		["Flydro - Kel'Thuzad"] = "Default",
		["Flidro - Mannoroth"] = "Default",
		["Fliddot - Mal'Ganis"] = "Fliddot",
		["Fliddo - Mal'Ganis"] = "Default",
		["Flydro - Mannoroth"] = "Default",
		["Flidro - Bleeding Hollow"] = "Default",
		["Flidro - Magtheridon"] = "Default",
		["Pepto - Emerald Dream"] = "Default",
		["Flidro - Kel'Thuzad"] = "Tank",
		["Lusankya - Rexxar"] = "Default",
		["Awesww - Mal'Ganis"] = "Default",
		["Fwt - Mannoroth"] = "Default",
		["Flypato - Mal'Ganis"] = "Default",
		["Slydro - Mal'Ganis"] = "Default",
		["Flidro - Draenor"] = "Default",
		["Flidro - Stalagg"] = "Default",
		["Lusankya - Area 52"] = "Default",
		["Flidro - Malygos"] = "Default",
		["Flidro - Pagle"] = "Default",
	},
	["profiles"] = {
		["Tank"] = {
			["channelingcolor"] = {
				0.749019607843137, -- [1]
				0.756862745098039, -- [2]
				0.705882352941177, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Tradeskill"] = false,
				["GCD"] = false,
				["Buff"] = false,
				["Timer"] = false,
				["Pet"] = false,
				["Range"] = false,
				["Latency"] = false,
			},
			["castingcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["completecolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["sparkcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0, -- [4]
			},
			["casttimeprecision"] = 2,
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
			["failcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
		},
		["Default"] = {
			["channelingcolor"] = {
				0.96078431372549, -- [1]
				1, -- [2]
				0.850980392156863, -- [3]
				1, -- [4]
			},
			["completecolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
			["failcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Tradeskill"] = false,
				["GCD"] = false,
				["Buff"] = false,
				["Timer"] = false,
				["Range"] = false,
				["Pet"] = false,
				["Latency"] = false,
			},
			["castingcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["sparkcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0, -- [4]
			},
			["casttimeprecision"] = 2,
		},
		["Fliddot"] = {
			["channelingcolor"] = {
				0.96078431372549, -- [1]
				1, -- [2]
				0.850980392156863, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Swing"] = false,
				["GCD"] = false,
				["Buff"] = false,
				["Timer"] = false,
				["Tradeskill"] = false,
				["Range"] = false,
				["Pet"] = false,
			},
			["castingcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["completecolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
			["sparkcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				0, -- [4]
			},
			["casttimeprecision"] = 2,
			["backgroundcolor"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1, -- [4]
			},
			["failcolor"] = {
				0.815686274509804, -- [1]
				0.847058823529412, -- [2]
				0.72156862745098, -- [3]
				1, -- [4]
			},
		},
	},
}
