
CoordinatesDB = {
	["minimap"] = true,
	["worldmap"] = true,
}
