
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["Flidro - Stalagg"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["Flidro - Pagle"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["Wahaha - Pagle"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "reputation",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "8.2.25",
	},
	["profileKeys"] = {
		["Flidro - Pagle"] = "Warrior",
		["Flidro - Stalagg"] = "Hunter",
		["Flidrobank - Pagle"] = "Priest",
		["Wahaha - Pagle"] = "Mage",
	},
	["profiles"] = {
		["Priest"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["icon"] = false,
						["time"] = true,
						["border"] = true,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["alwaysShowText"] = true,
					["padW"] = 2,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["y"] = 0,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["minimap"] = {
				["minimapPos"] = 194.794276709666,
			},
		},
		["Hunter"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["y"] = 0,
					["x"] = 0,
					["font"] = "Friz Quadrata TT",
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["lockMode"] = true,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
		},
		["Warrior"] = {
			["linkedOpacity"] = true,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.76,
					["showInOverrideUI"] = false,
					["padW"] = 3,
					["showstates"] = "",
					["y"] = 199,
					["spacing"] = -4,
					["padH"] = 3,
					["pages"] = {
						["WARRIOR"] = {
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["berserker"] = 8,
							["battle"] = 6,
							["defensive"] = 7,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["columns"] = 6,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.6,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = -586,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeAlpha"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.6,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 571,
					["y"] = 40,
					["spacing"] = 4,
					["anchor"] = "2TR",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.6,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = -557,
					["y"] = 80,
					["spacing"] = 4,
					["anchor"] = "3TC",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 0.6,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = -557,
					["y"] = 120,
					["spacing"] = 4,
					["anchor"] = "4TC",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 6,
					["scale"] = 0.76,
					["showInOverrideUI"] = false,
					["padW"] = -3,
					["y"] = 89,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["spacing"] = -4,
					["anchor"] = "1BC",
					["padH"] = -3,
					["numButtons"] = 12,
					["point"] = "BOTTOM",
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = -220,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = -180,
					["spacing"] = 4,
					["anchor"] = "9BC",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "LEFT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 283,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 221,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 2,
					["scale"] = 0.7,
					["showInOverrideUI"] = false,
					["padW"] = -3,
					["point"] = "LEFT",
					["spacing"] = -2,
					["padH"] = -3,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = -286,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["w"] = 145,
					["y"] = 157,
					["h"] = 18,
					["hidden"] = true,
					["font"] = "Friz Quadrata TT",
					["anchor"] = "1TC",
					["display"] = {
						["time"] = true,
						["border"] = true,
						["icon"] = false,
					},
					["latencyPadding"] = 0,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["x"] = 378,
					["columns"] = 1,
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["y"] = 130,
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["y"] = 15,
					["showstates"] = "",
					["spacing"] = 0,
					["anchor"] = "bagsBR",
					["disabled"] = {
						["WorldMapMicroButton"] = false,
					},
				},
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 1.35,
					["lockMode"] = true,
					["padW"] = 2,
					["spacing"] = 1,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "Flat",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["width"] = 377,
					["font"] = "Accidental Presidency",
					["height"] = 7,
					["alwaysShowText"] = true,
					["display"] = {
						["remaining"] = true,
						["label"] = true,
						["max"] = true,
						["value"] = true,
						["percent"] = true,
						["bonus"] = true,
					},
					["padH"] = 2,
				},
				["bags"] = {
					["y"] = 37,
					["showstates"] = "",
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -202,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
					["y"] = 206,
				},
				["pet"] = {
					["y"] = 15,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["anchor"] = "expTC",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 167,
					["x"] = -172,
					["point"] = "BOTTOM",
					["anchor"] = "classBR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["minimap"] = {
				["minimapPos"] = 185.444734238661,
				["hide"] = true,
			},
		},
		["Mage"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["showInOverrideUI"] = false,
					["y"] = 0,
					["padH"] = 2,
					["padW"] = 2,
					["x"] = 0,
					["font"] = "Friz Quadrata TT",
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["lockMode"] = true,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
			},
		},
	},
}
