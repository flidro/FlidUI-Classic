
MSBTProfiles_SavedVars = {
	["profiles"] = {
		["Default"] = {
			["powerThrottleDuration"] = 0,
			["damageColoringDisabled"] = true,
			["partialColoringDisabled"] = true,
			["gameDamageEnabled"] = true,
			["regenAbilitiesDisabled"] = true,
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILL_SHOT"] = {
					["disabled"] = true,
				},
				["Custom2"] = {
					["classes"] = "DEATHKNIGHT",
					["colorB"] = 0.282352941176471,
					["colorG"] = 0,
					["message"] = "Hysteria Ready",
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Hysteria}",
					["alwaysSticky"] = true,
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["colorB"] = 0.0588235294117647,
					["colorG"] = 0.266666666666667,
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["alwaysSticky"] = true,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["iconSkill"] = "3273",
					["colorG"] = 0.501960784313726,
					["colorB"] = 0.501960784313726,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["soundFile"] = "Magic Click",
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
			},
			["critFontName"] = "Friz Quadrata TT",
			["enableBlizzardHealing"] = true,
			["skillIconsDisabled"] = true,
			["creationVersion"] = "5.3.36",
			["enableBlizzardDamage"] = true,
			["hotThrottleDuration"] = 0,
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["INCOMING_ABSORB"] = {
					["colorG"] = 0.258823529411765,
					["colorR"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorB"] = 0.956862745098039,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["colorG"] = 0.364705882352941,
					["colorR"] = 0.364705882352941,
				},
				["PET_OUTGOING_MISS"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_MISS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["disabled"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["PET_OUTGOING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
			},
			["stickyCritsDisabled"] = true,
			["dotThrottleDuration"] = 0,
			["normalFontName"] = "Friz Quadrata TT",
			["scrollAreas"] = {
				["Incoming"] = {
					["direction"] = "Up",
					["stickyTextAlignIndex"] = 2,
					["stickyBehavior"] = "Normal",
					["textAlignIndex"] = 2,
					["behavior"] = "MSBT_NORMAL",
					["animationSpeed"] = 60,
					["stickyDirection"] = "Up",
					["scrollWidth"] = 90,
					["offsetX"] = -355,
					["scrollHeight"] = 165,
					["critFontSize"] = 11,
					["offsetY"] = -162,
					["animationStyle"] = "Straight",
					["normalFontSize"] = 13,
				},
				["Static"] = {
					["offsetY"] = -1,
					["offsetX"] = -19,
					["disabled"] = true,
				},
				["Notification"] = {
					["scrollWidth"] = 10,
					["scrollHeight"] = 90,
					["offsetX"] = -5,
					["offsetY"] = -61,
				},
				["Outgoing"] = {
					["offsetY"] = -168,
					["disabled"] = true,
					["offsetX"] = 284,
				},
			},
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
		},
		["Healing"] = {
			["HUNTER"] = {
				["colorR"] = 0.674509803921569,
				["colorG"] = 0.831372549019608,
				["colorB"] = 0.458823529411765,
			},
			["powerThrottleDuration"] = 0,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["hideNames"] = true,
			["enableBlizzardDamage"] = false,
			["partialColoringDisabled"] = true,
			["normalFontName"] = "visitor1",
			["nature"] = {
				["colorB"] = 0,
				["colorR"] = 1,
			},
			["throttleList"] = {
				["Flurry of Xuen"] = 3,
				["Beast Cleave"] = 1,
				["Ignite"] = 1,
				["Claw"] = 1,
				["Combustion"] = 2,
				["Barrage"] = 4,
			},
			["frost"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["critFontName"] = "visitor1",
			["arcane"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["scrollAreas"] = {
				["Incoming"] = {
					["direction"] = "Up",
					["behavior"] = "MSBT_NORMAL",
					["normalFontSize"] = 15,
					["animationStyle"] = "Straight",
					["stickyDirection"] = "Up",
					["critFontSize"] = 16,
					["scrollWidth"] = 250,
					["offsetX"] = -484,
					["scrollHeight"] = 110,
					["stickyBehavior"] = "MSBT_NORMAL",
					["offsetY"] = 230,
					["textAlignIndex"] = 1,
					["stickyAnimationStyle"] = "Static",
				},
				["Custom2"] = {
					["stickyTextAlignIndex"] = 1,
					["animationSpeed"] = 250,
					["direction"] = "Up",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 85,
					["name"] = "Dots",
					["textAlignIndex"] = 1,
					["offsetX"] = 371,
					["offsetY"] = -138,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Notification"] = {
					["stickyDirection"] = "Up",
					["direction"] = "Up",
					["offsetX"] = -4,
					["scrollWidth"] = 10,
					["scrollHeight"] = 90,
					["offsetY"] = -128,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Static"] = {
					["offsetY"] = -1,
					["disabled"] = true,
					["offsetX"] = -19,
				},
				["Custom1"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 100,
					["name"] = "Pet",
					["offsetX"] = 589,
					["offsetY"] = -148,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Outgoing"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["behavior"] = "MSBT_NORMAL",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 155,
					["offsetX"] = 215,
					["stickyBehavior"] = "MSBT_NORMAL",
					["iconAlign"] = "Left",
					["offsetY"] = -176,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
			},
			["block"] = {
				["trailer"] = " <[%a]>",
			},
			["regenAbilitiesDisabled"] = true,
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["Custom2"] = {
					["message"] = "Hysteria Ready",
					["colorB"] = 0.282352941176471,
					["alwaysSticky"] = true,
					["classes"] = "DEATHKNIGHT",
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Hysteria}",
					["colorG"] = 0,
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
					["colorB"] = 0.0588235294117647,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["colorG"] = 0.266666666666667,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ULTIMATUM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["Custom3"] = {
					["message"] = "20%",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILL_SHOT"] = {
					["message"] = " ",
					["iconSkill"] = "61006",
					["soundFile"] = "Shing!",
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["disabled"] = true,
					["iconSkill"] = "3273",
					["colorG"] = 0.501960784313726,
					["colorB"] = 0.501960784313726,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["iconSkill"] = "24275",
					["soundFile"] = "Shing!",
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["soundFile"] = "Magic Click",
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
			},
			["groupNumbers"] = true,
			["holy"] = {
				["colorR"] = 0.984313725490196,
				["colorB"] = 0.984313725490196,
			},
			["hotThrottleDuration"] = 0,
			["critOutlineIndex"] = 3,
			["normalOutlineIndex"] = 2,
			["gameDamageEnabled"] = true,
			["dotThrottleDuration"] = 0,
			["creationVersion"] = "5.3.36",
			["critFontSize"] = 18,
			["absorb"] = {
				["trailer"] = " <%a ABSORBED>",
			},
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["INCOMING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_ABSORB"] = {
					["message"] = "<%a>",
					["colorR"] = 0.258823529411765,
					["colorG"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_DISPEL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom2",
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorB"] = 0.956862745098039,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CHI_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["message"] = "(%s) <%a>",
					["colorR"] = 0.364705882352941,
					["colorG"] = 0.364705882352941,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT_CRIT"] = {
					["scrollArea"] = "Custom2",
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_CHANGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["message"] = "<%a> Absorbed!",
					["alwaysSticky"] = true,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
			},
			["enableBlizzardHealing"] = true,
			["shadow"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["fire"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["healThreshold"] = 1400,
			["normalFontSize"] = 16,
		},
		["Lusankya"] = {
			["HUNTER"] = {
				["colorR"] = 0.674509803921569,
				["colorG"] = 0.831372549019608,
				["colorB"] = 0.458823529411765,
			},
			["shadow"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["normalOutlineIndex"] = 2,
			["partialColoringDisabled"] = true,
			["nature"] = {
				["colorR"] = 1,
				["colorB"] = 0,
			},
			["normalFontSize"] = 16,
			["frost"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["enableBlizzardHealing"] = true,
			["arcane"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["scrollAreas"] = {
				["Outgoing"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyBehavior"] = "MSBT_NORMAL",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 110,
					["offsetX"] = 214,
					["behavior"] = "MSBT_NORMAL",
					["iconAlign"] = "Left",
					["offsetY"] = -124,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Custom2"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 125,
					["offsetX"] = 407,
					["name"] = "Dots",
					["offsetY"] = -39,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Incoming"] = {
					["direction"] = "Up",
					["behavior"] = "MSBT_NORMAL",
					["scrollHeight"] = 165,
					["offsetX"] = -377,
					["textAlignIndex"] = 2,
					["stickyTextAlignIndex"] = 2,
					["critFontName"] = "MSBT Transformers",
					["animationSpeed"] = 60,
					["stickyAnimationStyle"] = "Static",
					["stickyDirection"] = "Up",
					["scrollWidth"] = 90,
					["critFontSize"] = 11,
					["normalFontName"] = "MSBT Transformers",
					["stickyBehavior"] = "MSBT_NORMAL",
					["offsetY"] = -81,
					["animationStyle"] = "Straight",
					["normalFontSize"] = 11,
				},
				["Static"] = {
					["offsetY"] = -1,
					["offsetX"] = -19,
					["disabled"] = true,
				},
				["Custom1"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 100,
					["name"] = "Pet",
					["offsetX"] = 589,
					["offsetY"] = -148,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Notification"] = {
					["stickyDirection"] = "Up",
					["direction"] = "Up",
					["offsetX"] = -4,
					["scrollWidth"] = 10,
					["scrollHeight"] = 90,
					["offsetY"] = -128,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
			},
			["block"] = {
				["trailer"] = " <[%a]>",
			},
			["regenAbilitiesDisabled"] = true,
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILL_SHOT"] = {
					["message"] = " ",
					["iconSkill"] = "61006",
					["soundFile"] = "Shing!",
				},
				["Custom2"] = {
					["message"] = "Hysteria Ready",
					["colorB"] = 0.282352941176471,
					["colorG"] = 0,
					["alwaysSticky"] = true,
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Hysteria}",
					["classes"] = "DEATHKNIGHT",
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["fontSize"] = 26,
					["colorG"] = 0.266666666666667,
					["alwaysSticky"] = true,
					["colorB"] = 0.0588235294117647,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["soundFile"] = "Magic Click",
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["Custom3"] = {
					["message"] = "20%",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["iconSkill"] = "3273",
					["colorB"] = 0.501960784313726,
					["colorG"] = 0.501960784313726,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["soundFile"] = "Shing!",
					["iconSkill"] = "24275",
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
			},
			["fire"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["holy"] = {
				["colorB"] = 0.984313725490196,
				["colorR"] = 0.984313725490196,
			},
			["hotThrottleDuration"] = 0,
			["critOutlineIndex"] = 3,
			["critFontName"] = "visitor1",
			["enableBlizzardDamage"] = false,
			["dotThrottleDuration"] = 0,
			["creationVersion"] = "5.3.36",
			["critFontSize"] = 18,
			["hideNames"] = true,
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom1",
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom1",
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom1",
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["colorG"] = 0.364705882352941,
					["colorR"] = 0.364705882352941,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_ABSORB"] = {
					["colorG"] = 0.258823529411765,
					["colorR"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_DISPEL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["scrollArea"] = "Custom1",
				},
				["OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorB"] = 0.956862745098039,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_OUTGOING_SPELL_DAMAGE_CRIT"] = {
					["scrollArea"] = "Custom1",
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom1",
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom1",
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["OUTGOING_SPELL_DOT_CRIT"] = {
					["scrollArea"] = "Custom2",
				},
				["OUTGOING_SPELL_RESIST"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_DOT_CRIT"] = {
					["scrollArea"] = "Custom1",
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom2",
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
			},
			["gameDamageEnabled"] = true,
			["absorb"] = {
				["trailer"] = " <%a ABSORBED>",
			},
			["normalFontName"] = "visitor1",
			["powerThrottleDuration"] = 0,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
		},
		["Flidrov2"] = {
			["HUNTER"] = {
				["colorR"] = 0.674509803921569,
				["colorG"] = 0.831372549019608,
				["colorB"] = 0.458823529411765,
			},
			["shadow"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["normalOutlineIndex"] = 2,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["partialColoringDisabled"] = true,
			["hideNames"] = true,
			["nature"] = {
				["colorB"] = 0,
				["colorR"] = 1,
			},
			["fire"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["frost"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["gameDamageEnabled"] = true,
			["arcane"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["enableBlizzardHealing"] = true,
			["block"] = {
				["trailer"] = " <[%a]>",
			},
			["regenAbilitiesDisabled"] = true,
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILL_SHOT"] = {
					["message"] = " ",
					["iconSkill"] = "61006",
					["soundFile"] = "Shing!",
				},
				["Custom2"] = {
					["classes"] = "DEATHKNIGHT",
					["colorB"] = 0.282352941176471,
					["colorG"] = 0,
					["message"] = "Hysteria Ready",
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Hysteria}",
					["alwaysSticky"] = true,
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["fontSize"] = 26,
					["disabled"] = true,
					["colorG"] = 0.266666666666667,
					["colorB"] = 0.0588235294117647,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["alwaysSticky"] = true,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ULTIMATUM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["Custom3"] = {
					["message"] = "20%",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["disabled"] = true,
					["iconSkill"] = "3273",
					["colorG"] = 0.501960784313726,
					["colorB"] = 0.501960784313726,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["iconSkill"] = "24275",
					["soundFile"] = "Shing!",
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["soundFile"] = "Magic Click",
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
			},
			["holy"] = {
				["colorR"] = 0.984313725490196,
				["colorB"] = 0.984313725490196,
			},
			["absorb"] = {
				["trailer"] = " <%a ABSORBED>",
			},
			["hotThrottleDuration"] = 0,
			["critOutlineIndex"] = 3,
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["INCOMING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_ABSORB"] = {
					["message"] = "<%a>",
					["colorR"] = 0.258823529411765,
					["colorG"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["OUTGOING_DISPEL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_CHANGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CHI_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["message"] = "(%s) <%a>",
					["colorR"] = 0.364705882352941,
					["colorG"] = 0.364705882352941,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_FULL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorB"] = 0.956862745098039,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["message"] = "<%a> Absorbed!",
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_CHANGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
			},
			["throttleList"] = {
				["Flurry of Xuen"] = 3,
				["Beast Cleave"] = 1,
				["Ignite"] = 1,
				["Claw"] = 1,
				["Combustion"] = 2,
				["Barrage"] = 4,
			},
			["dotThrottleDuration"] = 0,
			["creationVersion"] = "5.3.36",
			["critFontSize"] = 18,
			["critFontName"] = "visitor1",
			["groupNumbers"] = true,
			["powerThrottleDuration"] = 0,
			["scrollAreas"] = {
				["Notification"] = {
					["stickyDirection"] = "Up",
					["direction"] = "Up",
					["offsetX"] = -4,
					["scrollWidth"] = 10,
					["scrollHeight"] = 90,
					["offsetY"] = -128,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Custom2"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyTextAlignIndex"] = 1,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 85,
					["offsetX"] = 448,
					["textAlignIndex"] = 1,
					["name"] = "Dots",
					["offsetY"] = -166,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Outgoing"] = {
					["direction"] = "Up",
					["animationSpeed"] = 500,
					["behavior"] = "MSBT_NORMAL",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 200,
					["offsetX"] = 227,
					["stickyBehavior"] = "MSBT_NORMAL",
					["iconAlign"] = "Left",
					["offsetY"] = -161,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Static"] = {
					["offsetY"] = -1,
					["offsetX"] = -19,
					["disabled"] = true,
				},
				["Custom1"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 100,
					["offsetX"] = 589,
					["name"] = "Pet",
					["offsetY"] = -148,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Incoming"] = {
					["direction"] = "Up",
					["stickyBehavior"] = "Normal",
					["critFontSize"] = 16,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 180,
					["offsetX"] = -267,
					["scrollWidth"] = 10,
					["animationSpeed"] = 50,
					["offsetY"] = -84,
					["textAlignIndex"] = 1,
					["normalFontSize"] = 15,
				},
			},
			["normalFontName"] = "visitor1",
			["enableBlizzardDamage"] = true,
			["normalFontSize"] = 16,
		},
		["Flidro-v3"] = {
			["HUNTER"] = {
				["colorR"] = 0.674509803921569,
				["colorG"] = 0.831372549019608,
				["colorB"] = 0.458823529411765,
			},
			["shadow"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["normalOutlineIndex"] = 2,
			["normalFontSize"] = 16,
			["partialColoringDisabled"] = true,
			["hideNames"] = true,
			["nature"] = {
				["colorR"] = 1,
				["colorB"] = 0,
			},
			["normalFontName"] = "visitor1",
			["frost"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["scrollAreas"] = {
				["Incoming"] = {
					["direction"] = "Up",
					["normalFontSize"] = 12,
					["behavior"] = "MSBT_NORMAL",
					["stickyBehavior"] = "MSBT_NORMAL",
					["animationSpeed"] = 50,
					["scrollWidth"] = 10,
					["critFontSize"] = 16,
					["scrollHeight"] = 130,
					["offsetX"] = -330,
					["name"] = "Incoming Damage",
					["stickyDirection"] = "Up",
					["offsetY"] = -275,
					["animationStyle"] = "Straight",
					["stickyAnimationStyle"] = "Static",
				},
				["Outgoing"] = {
					["direction"] = "Up",
					["behavior"] = "MSBT_NORMAL",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 200,
					["offsetX"] = 232,
					["stickyBehavior"] = "MSBT_NORMAL",
					["iconAlign"] = "Left",
					["offsetY"] = -237,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Static"] = {
					["offsetX"] = -1,
					["offsetY"] = -16,
				},
				["Notification"] = {
					["direction"] = "Up",
					["stickyTextAlignIndex"] = 1,
					["stickyDirection"] = "Up",
					["scrollWidth"] = 10,
					["offsetX"] = -847,
					["name"] = "Incoming Heals",
					["scrollHeight"] = 90,
					["offsetY"] = 60,
					["textAlignIndex"] = 1,
					["stickyAnimationStyle"] = "Static",
				},
			},
			["arcane"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["enableBlizzardHealing"] = false,
			["block"] = {
				["trailer"] = " <[%a]>",
			},
			["throttleList"] = {
				["Flurry of Xuen"] = 3,
				["Beast Cleave"] = 1,
				["Ignite"] = 1,
				["Drain Life"] = 1,
				["Combustion"] = 2,
				["Claw"] = 1,
				["Barrage"] = 4,
			},
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
					["colorB"] = 0.0588235294117647,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["colorG"] = 0.266666666666667,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["soundFile"] = "Magic Click",
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ULTIMATUM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ELUSIVE_BREW"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LAVA_SURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["Custom3"] = {
					["message"] = "20%",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = false,
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["colorB"] = 0.501960784313726,
					["iconSkill"] = "3273",
					["disabled"] = true,
					["colorG"] = 0.501960784313726,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["soundFile"] = "Shing!",
					["disabled"] = true,
					["iconSkill"] = "24275",
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
			},
			["gameDamageEnabled"] = true,
			["holy"] = {
				["colorB"] = 0.984313725490196,
				["colorR"] = 0.984313725490196,
			},
			["hotThrottleDuration"] = 0,
			["critOutlineIndex"] = 3,
			["groupNumbers"] = true,
			["powerThrottleDuration"] = 0,
			["dotThrottleDuration"] = 0,
			["creationVersion"] = "5.3.36",
			["critFontSize"] = 18,
			["absorb"] = {
				["trailer"] = " <%a ABSORBED>",
			},
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["INCOMING_HOT"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Notification",
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["SELF_HOT"] = {
					["scrollArea"] = "Notification",
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Notification",
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["INCOMING_HOT_CRIT"] = {
					["scrollArea"] = "Notification",
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_ABSORB"] = {
					["message"] = "<%a>",
					["colorR"] = 0.258823529411765,
					["colorG"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_DISPEL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["SELF_HOT_CRIT"] = {
					["scrollArea"] = "Notification",
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_CHANGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CHI_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_FULL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["scrollArea"] = "Static",
				},
				["SELF_HEAL_CRIT"] = {
					["scrollArea"] = "Notification",
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["SELF_HEAL"] = {
					["scrollArea"] = "Notification",
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CURRENCY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_CHANGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["message"] = "(%s) <%a>",
					["colorR"] = 0.364705882352941,
					["colorG"] = 0.364705882352941,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_COOLDOWN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_CHANGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_ABSORB"] = {
					["message"] = "<%a> Absorbed!",
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorR"] = 0.988235294117647,
					["colorG"] = 1,
					["colorB"] = 0.956862745098039,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL_CRIT"] = {
					["scrollArea"] = "Notification",
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
			},
			["critFontName"] = "visitor1",
			["regenAbilitiesDisabled"] = true,
			["fire"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["enableBlizzardDamage"] = true,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
		},
		["Flidro"] = {
			["HUNTER"] = {
				["colorR"] = 0.674509803921569,
				["colorG"] = 0.831372549019608,
				["colorB"] = 0.458823529411765,
			},
			["shadow"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["normalFontSize"] = 16,
			["enableBlizzardDamage"] = false,
			["powerThrottleDuration"] = 0,
			["partialColoringDisabled"] = true,
			["fire"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["nature"] = {
				["colorR"] = 1,
				["colorB"] = 0,
			},
			["normalOutlineIndex"] = 2,
			["frost"] = {
				["colorR"] = 1,
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["critFontName"] = "visitor1",
			["arcane"] = {
				["colorG"] = 1,
				["colorB"] = 0,
			},
			["scrollAreas"] = {
				["Outgoing"] = {
					["direction"] = "Up",
					["stickyBehavior"] = "MSBT_NORMAL",
					["behavior"] = "MSBT_NORMAL",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 145,
					["offsetX"] = 213,
					["animationSpeed"] = 250,
					["iconAlign"] = "Left",
					["offsetY"] = -142,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Custom2"] = {
					["stickyTextAlignIndex"] = 1,
					["animationSpeed"] = 250,
					["direction"] = "Up",
					["stickyDirection"] = "Up",
					["scrollHeight"] = 85,
					["offsetX"] = 448,
					["animationStyle"] = "Static",
					["name"] = "Dots",
					["offsetY"] = -166,
					["textAlignIndex"] = 1,
					["stickyAnimationStyle"] = "Static",
				},
				["Incoming"] = {
					["direction"] = "Up",
					["stickyBehavior"] = "MSBT_NORMAL",
					["stickyAnimationStyle"] = "Static",
					["textAlignIndex"] = 1,
					["critFontSize"] = 16,
					["stickyDirection"] = "Up",
					["scrollWidth"] = 250,
					["offsetX"] = -698,
					["scrollHeight"] = 180,
					["behavior"] = "MSBT_NORMAL",
					["offsetY"] = -54,
					["animationStyle"] = "Straight",
					["normalFontSize"] = 15,
				},
				["Static"] = {
					["offsetY"] = -1,
					["disabled"] = true,
					["offsetX"] = -19,
				},
				["Custom1"] = {
					["direction"] = "Up",
					["animationSpeed"] = 250,
					["stickyDirection"] = "Up",
					["scrollHeight"] = 100,
					["offsetX"] = 589,
					["name"] = "Pet",
					["offsetY"] = -148,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
				["Notification"] = {
					["stickyDirection"] = "Up",
					["direction"] = "Up",
					["offsetX"] = -4,
					["scrollWidth"] = 10,
					["scrollHeight"] = 90,
					["offsetY"] = -128,
					["animationStyle"] = "Static",
					["stickyAnimationStyle"] = "Static",
				},
			},
			["block"] = {
				["trailer"] = " <[%a]>",
			},
			["throttleList"] = {
				["Flurry of Xuen"] = 3,
				["Beast Cleave"] = 1,
				["Ignite"] = 1,
				["Claw"] = 1,
				["Combustion"] = 2,
				["Barrage"] = 4,
			},
			["triggers"] = {
				["MSBT_TRIGGER_RIPOSTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_IMPACT"] = {
					["disabled"] = true,
				},
				["Custom2"] = {
					["message"] = "Hysteria Ready",
					["colorB"] = 0.282352941176471,
					["colorG"] = 0,
					["alwaysSticky"] = true,
					["fontSize"] = 26,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Hysteria}",
					["classes"] = "DEATHKNIGHT",
				},
				["MSBT_TRIGGER_DECIMATION"] = {
					["disabled"] = true,
				},
				["Custom1"] = {
					["message"] = "Flare ready",
					["fontSize"] = 26,
					["colorG"] = 0.266666666666667,
					["alwaysSticky"] = true,
					["colorB"] = 0.0588235294117647,
					["mainEvents"] = "SKILL_COOLDOWN{skillName;;eq;;Flare}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MAELSTROM_WEAPON"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OVERPOWER"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ERADICATION"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RAMPAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RIME"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_THE_ART_OF_WAR"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FINGERS_OF_FROST"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PREDATORS_SWIFTNESS"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ECLIPSE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_EXECUTE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_MANA"] = {
					["soundFile"] = "Magic Click",
					["mainEvents"] = "UNIT_MANA{unitID;;eq;;player;;threshold;;lt;;10}",
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLACKOUT"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BRAIN_FREEZE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOCK_AND_LOAD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TIDAL_WAVES"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VIPER_STING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_ULTIMATUM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_FROSTBITE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_PVP_TRINKET"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SWORD_AND_BOARD"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BACKLASH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DEATH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_OWLKIN_FRENZY"] = {
					["disabled"] = true,
				},
				["Custom3"] = {
					["message"] = "20%",
					["fontSize"] = 26,
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_RUNE_STRIKE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILLING_MACHINE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_BLOODSURGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MOLTEN_CORE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_NIGHTFALL"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_MISSILE_BARRAGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_VICTORY_RUSH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_HEALTH"] = {
					["iconSkill"] = "3273",
					["colorB"] = 0.501960784313726,
					["colorG"] = 0.501960784313726,
					["disabled"] = true,
				},
				["MSBT_TRIGGER_CLEARCASTING"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_LOW_PET_HEALTH"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_KILL_SHOT"] = {
					["message"] = " ",
					["iconSkill"] = "61006",
					["soundFile"] = "Shing!",
				},
				["MSBT_TRIGGER_COUNTER_ATTACK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HAMMER_OF_WRATH"] = {
					["soundFile"] = "Shing!",
					["iconSkill"] = "24275",
				},
				["MSBT_TRIGGER_REVENGE"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_HOT_STREAK"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_SUDDEN_DOOM"] = {
					["disabled"] = true,
				},
				["MSBT_TRIGGER_TASTE_FOR_BLOOD"] = {
					["disabled"] = true,
				},
			},
			["events"] = {
				["PET_INCOMING_HOT_CRIT"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_MONEY"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_PARRY"] = {
					["colorR"] = 0.67843137254902,
					["colorG"] = 0.670588235294118,
					["colorB"] = 0.674509803921569,
				},
				["INCOMING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_SPELL_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DEFLECT"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_MISS"] = {
					["colorR"] = 0.694117647058824,
					["colorG"] = 0.698039215686275,
					["colorB"] = 0.67843137254902,
				},
				["PET_OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_PARRY"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_ABSORB"] = {
					["message"] = "<%a>",
					["colorR"] = 0.258823529411765,
					["colorG"] = 0.258823529411765,
				},
				["PET_INCOMING_SPELL_DOT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ENEMY_BUFF"] = {
					["disabled"] = true,
				},
				["OUTGOING_PARRY"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CP_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_FADE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DAMAGE"] = {
					["colorG"] = 0.886274509803922,
				},
				["NOTIFICATION_PET_COOLDOWN"] = {
					["disabled"] = true,
				},
				["OUTGOING_EVADE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_MISS"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DODGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DODGE"] = {
					["disabled"] = true,
				},
				["INCOMING_DAMAGE"] = {
					["colorB"] = 0.952941176470588,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["OUTGOING_DISPEL"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_DISPEL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_PC_KILLING_BLOW"] = {
					["colorB"] = 0.00784313725490196,
					["colorG"] = 0,
					["colorR"] = 0.705882352941177,
				},
				["NOTIFICATION_REP_LOSS"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_RESIST"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_INTERRUPT"] = {
					["colorG"] = 0.964705882352941,
					["disabled"] = true,
				},
				["OUTGOING_IMMUNE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_HOLY_POWER_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_REFLECT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COOLDOWN"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HOT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_ABSORB"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
					["scrollArea"] = "Custom2",
				},
				["NOTIFICATION_ITEM_BUFF"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_CHANGE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SOUL_SHARD_CREATED"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_GAIN"] = {
					["disabled"] = true,
				},
				["OUTGOING_HEAL"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_CHI_FULL"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HONOR_GAIN"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ITEM_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_LOOT"] = {
					["disabled"] = true,
				},
				["INCOMING_IMMUNE"] = {
					["colorG"] = 0.227450980392157,
					["colorR"] = 0.227450980392157,
				},
				["OUTGOING_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_AC_FULL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DOT_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["INCOMING_DODGE"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.662745098039216,
					["colorB"] = 0.643137254901961,
				},
				["NOTIFICATION_REP_GAIN"] = {
					["disabled"] = true,
				},
				["INCOMING_PARRY"] = {
					["colorR"] = 0.658823529411765,
					["colorG"] = 0.674509803921569,
					["colorB"] = 0.658823529411765,
				},
				["PET_INCOMING_SPELL_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_FADE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_DEFLECT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_ABSORB"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_IMMUNE"] = {
					["disabled"] = true,
				},
				["INCOMING_BLOCK"] = {
					["colorR"] = 0.709803921568628,
					["colorG"] = 0.709803921568628,
					["colorB"] = 0.694117647058824,
				},
				["OUTGOING_SPELL_DODGE"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_ABSORB"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_DAMAGE_CRIT"] = {
					["colorB"] = 0.956862745098039,
					["colorG"] = 1,
					["colorR"] = 0.988235294117647,
				},
				["OUTGOING_ABSORB"] = {
					["message"] = "<%a> Absorbed!",
					["alwaysSticky"] = true,
				},
				["OUTGOING_SPELL_DAMAGE_SHIELD"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_OUTGOING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_EVADE"] = {
					["disabled"] = true,
				},
				["OUTGOING_DAMAGE"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_MISS"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_DODGE"] = {
					["colorR"] = 0.686274509803922,
					["colorG"] = 0.658823529411765,
					["colorB"] = 0.647058823529412,
				},
				["PET_INCOMING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_POWER_GAIN"] = {
					["alwaysSticky"] = true,
					["disabled"] = true,
				},
				["PET_OUTGOING_ABSORB"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_ALT_POWER_LOSS"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_SHIELD_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SKILL_GAIN"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_BLOCK"] = {
					["colorR"] = 0.682352941176471,
					["colorG"] = 0.686274509803922,
					["colorB"] = 0.682352941176471,
				},
				["NOTIFICATION_COMBAT_ENTER"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_SHADOW_ORBS_CHANGE"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_INTERRUPT"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_DAMAGE_CRIT"] = {
					["colorG"] = 0.835294117647059,
				},
				["PET_OUTGOING_SPELL_DOT"] = {
					["alwaysSticky"] = true,
				},
				["NOTIFICATION_COMBAT_LEAVE"] = {
					["disabled"] = true,
				},
				["INCOMING_SPELL_ABSORB"] = {
					["message"] = "(%s) <%a>",
					["colorR"] = 0.364705882352941,
					["colorG"] = 0.364705882352941,
				},
				["INCOMING_SPELL_DOT"] = {
					["colorB"] = 0.603921568627451,
				},
				["OUTGOING_SPELL_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_MISS"] = {
					["colorR"] = 0.701960784313726,
					["colorG"] = 0.690196078431373,
					["colorB"] = 0.662745098039216,
				},
				["PET_INCOMING_SPELL_BLOCK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_MONSTER_EMOTE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_HEAL"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_CHI_CHANGE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_DEBUFF_STACK"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_SPELL_RESIST"] = {
					["disabled"] = true,
				},
				["PET_OUTGOING_EVADE"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_HOLY_POWER_FULL"] = {
					["disabled"] = true,
				},
				["OUTGOING_HOT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_BLOCK"] = {
					["alwaysSticky"] = true,
				},
				["INCOMING_SPELL_IMMUNE"] = {
					["colorG"] = 0.376470588235294,
					["colorR"] = 0.376470588235294,
				},
				["NOTIFICATION_CP_FULL"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_BUFF_STACK"] = {
					["disabled"] = true,
				},
				["NOTIFICATION_EXTRA_ATTACK"] = {
					["disabled"] = true,
				},
				["OUTGOING_DEFLECT"] = {
					["alwaysSticky"] = true,
				},
				["OUTGOING_MISS"] = {
					["alwaysSticky"] = true,
				},
				["PET_INCOMING_IMMUNE"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_DAMAGE_CRIT"] = {
					["disabled"] = true,
				},
				["PET_INCOMING_SPELL_PARRY"] = {
					["disabled"] = true,
				},
				["OUTGOING_SPELL_DOT_CRIT"] = {
					["scrollArea"] = "Custom2",
				},
				["NOTIFICATION_DEBUFF"] = {
					["disabled"] = true,
				},
			},
			["holy"] = {
				["colorB"] = 0.984313725490196,
				["colorR"] = 0.984313725490196,
			},
			["hotThrottleDuration"] = 0,
			["critOutlineIndex"] = 3,
			["enableBlizzardHealing"] = true,
			["hideNames"] = true,
			["dotThrottleDuration"] = 0,
			["creationVersion"] = "5.3.36",
			["critFontSize"] = 18,
			["absorb"] = {
				["trailer"] = " <%a ABSORBED>",
			},
			["groupNumbers"] = true,
			["regenAbilitiesDisabled"] = true,
			["gameDamageEnabled"] = true,
			["normalFontName"] = "visitor1",
			["healThreshold"] = 1400,
			["qualityExclusions"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
		},
	},
}
MSBT_SavedMedia = {
	["fonts"] = {
		["Myriad Condensed Web"] = "Interface\\AddOns\\SharedMedia_MyMedia\\font\\Myriad Condensed Web.ttf",
		["visitor1"] = "Interface\\AddOns\\SharedMedia_MyMedia\\font\\visitor1.ttf",
	},
	["sounds"] = {
	},
}
