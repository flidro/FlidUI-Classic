
betterVendorPriceSaved = {
	["addonVersion"] = "v1.08.00-classic",
	["addonHash"] = "1b9de11",
	["showFullStack"] = true,
}
