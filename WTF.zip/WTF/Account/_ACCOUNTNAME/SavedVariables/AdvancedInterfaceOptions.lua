
AdvancedInterfaceOptionsSaved = {
	["CustomVars"] = {
	},
	["DBVersion"] = 3,
	["ModifiedCVars"] = {
		["chatstyle"] = "Interface\\FrameXML\\InterfaceOptionsPanels.lua:897",
		["ffxdeath"] = "Interface\\AddOns\\Leatrix_Plus\\Leatrix_Plus.lua:2308",
		["activecufprofile"] = "...rd_CUFProfiles\\Blizzard_CompactUnitFrameProfiles.lua:261",
		["sound_mastervolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["camerapitchmovespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:470",
		["sound_ambiencevolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["cameradistancemaxzoomfactor"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:470",
		["raidgraphicsgroundclutter"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:380",
		["countdownforcooldowns"] = "Interface\\AddOns\\OmniCC\\main.lua:68",
		["graphicsgroundclutter"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:380",
		["raidgraphicsenvironmentdetail"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:380",
		["lastselectedclubid"] = "...ace\\AddOns\\Blizzard_Communities\\CommunitiesFrame.lua:401",
		["mousespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:470",
		["camerayawsmoothspeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:470",
		["nameplatemaxdistance"] = "Interface\\FrameXML\\ChatFrame.lua:2033",
		["blockchannelinvites"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["ffxglow"] = "Interface\\AddOns\\Leatrix_Plus\\Leatrix_Plus.lua:2287",
		["unitnamefriendlyplayername"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["camerayawmovespeed"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:470",
		["unitnameplayerpvptitle"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["ffxnether"] = "Interface\\AddOns\\Leatrix_Plus\\Leatrix_Plus.lua:2309",
		["minicommunitiesframe"] = "Interface\\SharedXML\\SharedUIPanelTemplates.lua:834",
		["graphicsenvironmentdetail"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:380",
		["sound_musicvolume"] = "Interface\\FrameXML\\OptionsPanelTemplates.lua:204",
		["graphicsliquiddetail"] = "Interface\\SharedXML\\VideoOptionsPanels.lua:380",
	},
	["CharVars"] = {
	},
	["AccountVars"] = {
	},
	["EnforceSettings"] = false,
}
