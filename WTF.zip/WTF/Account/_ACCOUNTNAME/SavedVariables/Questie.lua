
QuestieConfig = {
	["char"] = {
		["Flidro - Stalagg"] = {
			["journey"] = {
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 1,
					["Quest"] = 4641,
					["Timestamp"] = 1568049751,
				}, -- [1]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 1,
					["Quest"] = 4641,
					["Timestamp"] = 1568049762,
				}, -- [2]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 1,
					["Quest"] = 788,
					["Timestamp"] = 1568049762,
				}, -- [3]
			},
			["complete"] = {
				[4641] = true,
			},
		},
		["Flidro - Pagle"] = {
			["journey"] = {
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 1,
						}, -- [1]
					},
					["Timestamp"] = 1566857066,
					["Quest"] = 783,
					["Level"] = 1,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 1,
						}, -- [1]
					},
					["Timestamp"] = 1566857086,
					["Quest"] = 783,
					["Level"] = 1,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 1,
						}, -- [1]
					},
					["Timestamp"] = 1566857099,
					["Quest"] = 7,
					["Level"] = 1,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [3]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 1,
						}, -- [1]
					},
					["Timestamp"] = 1566857120,
					["Quest"] = 33,
					["Level"] = 1,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [4]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 1,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 1,
						}, -- [2]
					},
					["Timestamp"] = 1566858000,
					["Event"] = "Level",
					["NewLevel"] = 2,
				}, -- [5]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566858480,
					["Quest"] = 18,
					["Level"] = 2,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [6]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566858532,
					["Quest"] = 33,
					["Level"] = 2,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [7]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566859192,
					["Quest"] = 7,
					["Level"] = 2,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [8]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566859192,
					["Event"] = "Level",
					["NewLevel"] = 3,
				}, -- [9]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566859199,
					["Quest"] = 3100,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [10]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566859201,
					["Quest"] = 15,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [11]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 2,
						}, -- [2]
					},
					["Timestamp"] = 1566859213,
					["Quest"] = 3100,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [12]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [2]
					},
					["Timestamp"] = 1566859372,
					["Quest"] = 2158,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [13]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [2]
					},
					["Timestamp"] = 1566860452,
					["Quest"] = 15,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [14]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [2]
					},
					["Timestamp"] = 1566860454,
					["Quest"] = 21,
					["Level"] = 3,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [15]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 3,
						}, -- [2]
					},
					["Timestamp"] = 1566860630,
					["Event"] = "Level",
					["NewLevel"] = 4,
				}, -- [16]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [2]
					},
					["Timestamp"] = 1566861069,
					["Quest"] = 21,
					["Level"] = 4,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [17]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [2]
					},
					["Timestamp"] = 1566861074,
					["Quest"] = 54,
					["Level"] = 4,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [18]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 4,
						}, -- [2]
					},
					["Timestamp"] = 1566862487,
					["Event"] = "Level",
					["NewLevel"] = 5,
				}, -- [19]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566862706,
					["Quest"] = 18,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [20]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566862709,
					["Quest"] = 3903,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [21]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566862711,
					["Quest"] = 6,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [22]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566862742,
					["Quest"] = 3903,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [23]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566862743,
					["Quest"] = 3904,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [24]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566863384,
					["Quest"] = 3904,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [25]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566863387,
					["Quest"] = 3905,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [26]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566863486,
					["Quest"] = 3905,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [27]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566863685,
					["Quest"] = 54,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [28]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 5,
						}, -- [2]
					},
					["Timestamp"] = 1566863687,
					["Quest"] = 62,
					["Level"] = 5,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [29]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566864719,
					["Event"] = "Level",
					["NewLevel"] = 6,
				}, -- [30]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865236,
					["Quest"] = 60,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [31]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865260,
					["Quest"] = 2158,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [32]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865295,
					["Quest"] = 47,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [33]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865385,
					["Quest"] = 106,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [34]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865611,
					["Quest"] = 85,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [35]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865613,
					["Quest"] = 88,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [36]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865823,
					["Quest"] = 106,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [37]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566865825,
					["Quest"] = 111,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [38]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866048,
					["Quest"] = 111,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [39]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866052,
					["Quest"] = 107,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [40]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866105,
					["Quest"] = 85,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [41]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866108,
					["Quest"] = 86,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [42]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866165,
					["Quest"] = 86,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [43]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866168,
					["Quest"] = 84,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [44]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866254,
					["Quest"] = 84,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [45]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 6,
						}, -- [2]
					},
					["Timestamp"] = 1566866255,
					["Quest"] = 87,
					["Level"] = 6,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [46]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566867740,
					["Event"] = "Level",
					["NewLevel"] = 7,
				}, -- [47]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868605,
					["Quest"] = 87,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [48]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868750,
					["Quest"] = 47,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [49]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868752,
					["Quest"] = 40,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [50]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868757,
					["Quest"] = 62,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [51]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868759,
					["Quest"] = 76,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [52]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868767,
					["Quest"] = 40,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [53]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868768,
					["Quest"] = 35,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [54]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868791,
					["Quest"] = 60,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [55]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868792,
					["Quest"] = 61,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [56]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868795,
					["Quest"] = 107,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [57]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Sarian",
							["Level"] = 7,
						}, -- [2]
					},
					["Timestamp"] = 1566868797,
					["Quest"] = 112,
					["Level"] = 7,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [58]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870540,
					["Event"] = "Level",
					["NewLevel"] = 8,
				}, -- [59]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870897,
					["Quest"] = 52,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [60]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870901,
					["Quest"] = 35,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [61]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870902,
					["Quest"] = 37,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [62]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870963,
					["Quest"] = 37,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [63]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566870964,
					["Quest"] = 45,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [64]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566871049,
					["Quest"] = 5545,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [65]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566871109,
					["Quest"] = 45,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [66]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566871110,
					["Quest"] = 71,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [67]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566871635,
					["Quest"] = 5545,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [68]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566871691,
					["Quest"] = 6,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [69]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566872022,
					["Quest"] = 71,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [70]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566872026,
					["Quest"] = 52,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [71]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566872028,
					["Quest"] = 39,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [72]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 8,
						}, -- [1]
					},
					["Timestamp"] = 1566872347,
					["Quest"] = 39,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [73]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872350,
					["Quest"] = 59,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [74]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872351,
					["Quest"] = 76,
					["Level"] = 8,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [75]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872351,
					["Event"] = "Level",
					["NewLevel"] = 9,
				}, -- [76]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872354,
					["Quest"] = 109,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [77]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872357,
					["Quest"] = 239,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [78]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872367,
					["Quest"] = 1097,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [79]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872533,
					["Quest"] = 88,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [80]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872659,
					["Quest"] = 239,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [81]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872662,
					["Quest"] = 11,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [82]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566872666,
					["Quest"] = 176,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [83]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566873464,
					["Quest"] = 61,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [84]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566873599,
					["Quest"] = 1097,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [85]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566873603,
					["Quest"] = 353,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [86]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566873631,
					["Quest"] = 59,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [87]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566873635,
					["Quest"] = 112,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [88]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566874084,
					["Quest"] = 314,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [89]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Attina",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Attina",
							["Level"] = 9,
						}, -- [2]
					},
					["Timestamp"] = 1566874392,
					["Quest"] = 314,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [90]
				{
					["Party"] = {
					},
					["Timestamp"] = 1566875116,
					["Quest"] = 433,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [91]
				{
					["Party"] = {
					},
					["Timestamp"] = 1566875145,
					["Quest"] = 11,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [92]
				{
					["Party"] = {
					},
					["Timestamp"] = 1566875324,
					["Quest"] = 432,
					["Level"] = 9,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [93]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566914179,
					["Event"] = "Level",
					["NewLevel"] = 10,
				}, -- [94]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566915582,
					["Quest"] = 433,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [95]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 9,
						}, -- [1]
					},
					["Timestamp"] = 1566915586,
					["Quest"] = 432,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [96]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566915842,
					["Quest"] = 419,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [97]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566915879,
					["Quest"] = 419,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [98]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566915880,
					["Quest"] = 417,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [99]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566916023,
					["Quest"] = 417,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [100]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566916273,
					["Quest"] = 224,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [101]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566916296,
					["Quest"] = 267,
					["Level"] = 10,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [102]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918125,
					["Event"] = "Level",
					["NewLevel"] = 11,
				}, -- [103]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918591,
					["Quest"] = 298,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [104]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918655,
					["Quest"] = 418,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [105]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918675,
					["Quest"] = 298,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [106]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918675,
					["Quest"] = 301,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [107]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918702,
					["Quest"] = 1339,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [108]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Timestamp"] = 1566918705,
					["Quest"] = 416,
					["Level"] = 11,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [109]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 10,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 11,
					["Quest"] = 224,
					["Timestamp"] = 1566919197,
				}, -- [110]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 11,
					["Quest"] = 237,
					["Timestamp"] = 1566919209,
				}, -- [111]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 11,
					["Quest"] = 267,
					["Timestamp"] = 1566919223,
				}, -- [112]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 11,
					["Quest"] = 1339,
					["Timestamp"] = 1566919563,
				}, -- [113]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 11,
					["Quest"] = 1338,
					["Timestamp"] = 1566919564,
				}, -- [114]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 11,
					["Quest"] = 307,
					["Timestamp"] = 1566919566,
				}, -- [115]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 11,
					["Quest"] = 353,
					["Timestamp"] = 1566919570,
				}, -- [116]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Level"] = 11,
					["Quest"] = 307,
					["Timestamp"] = 1566921258,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [117]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 11,
						}, -- [1]
					},
					["Timestamp"] = 1566921258,
					["Event"] = "Level",
					["NewLevel"] = 12,
				}, -- [118]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 416,
					["Timestamp"] = 1566922240,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [119]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 418,
					["Timestamp"] = 1566922253,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [120]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 301,
					["Timestamp"] = 1566922558,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [121]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 302,
					["Timestamp"] = 1566922559,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [122]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 302,
					["Timestamp"] = 1566923132,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [123]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 273,
					["Timestamp"] = 1566923133,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [124]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 963,
					["Timestamp"] = 1566924457,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [125]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 3524,
					["Timestamp"] = 1566924484,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [126]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 983,
					["Timestamp"] = 1566924504,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [127]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 947,
					["Timestamp"] = 1566924517,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [128]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 4811,
					["Timestamp"] = 1566924521,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [129]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 2178,
					["Timestamp"] = 1566924541,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [130]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 954,
					["Timestamp"] = 1566924546,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [131]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 958,
					["Timestamp"] = 1566924548,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [132]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 2118,
					["Timestamp"] = 1566924583,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [133]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 984,
					["Timestamp"] = 1566924590,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [134]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 2118,
					["Timestamp"] = 1566926723,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [135]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 2138,
					["Timestamp"] = 1566926725,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [136]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Timestamp"] = 1566926734,
					["Event"] = "Level",
					["NewLevel"] = 13,
				}, -- [137]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 12,
					["Quest"] = 984,
					["Timestamp"] = 1566926734,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [138]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 985,
					["Timestamp"] = 1566926736,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [139]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 4761,
					["Timestamp"] = 1566926742,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [140]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 2178,
					["Timestamp"] = 1566926777,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [141]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 4761,
					["Timestamp"] = 1566926786,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [142]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 4762,
					["Timestamp"] = 1566926788,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [143]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 3524,
					["Timestamp"] = 1566926831,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [144]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 4681,
					["Timestamp"] = 1566926832,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [145]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 983,
					["Timestamp"] = 1566926854,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [146]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 12,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 1001,
					["Timestamp"] = 1566926856,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [147]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566927169,
					["Quest"] = 4681,
					["Level"] = 13,
				}, -- [148]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Timestamp"] = 1566927525,
					["Quest"] = 954,
					["Level"] = 13,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [149]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Timestamp"] = 1566927528,
					["Quest"] = 955,
					["Level"] = 13,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [150]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 13,
					["Quest"] = 955,
					["Timestamp"] = 1566928829,
				}, -- [151]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 13,
					["Quest"] = 956,
					["Timestamp"] = 1566928832,
				}, -- [152]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 956,
					["Timestamp"] = 1566932217,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [153]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Level"] = 13,
					["Quest"] = 957,
					["Timestamp"] = 1566932220,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [154]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Timestamp"] = 1566932520,
					["Event"] = "Level",
					["NewLevel"] = 14,
				}, -- [155]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 13,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 953,
					["Timestamp"] = 1566932655,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [156]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 953,
					["Timestamp"] = 1566933733,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [157]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4722,
					["Timestamp"] = 1566933824,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [158]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4728,
					["Timestamp"] = 1566933943,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [159]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4728,
					["Timestamp"] = 1566934909,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [160]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4722,
					["Timestamp"] = 1566934912,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [161]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 963,
					["Timestamp"] = 1566934933,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [162]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4811,
					["Timestamp"] = 1566934968,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [163]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 4812,
					["Timestamp"] = 1566934969,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [164]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 985,
					["Timestamp"] = 1566935002,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [165]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 986,
					["Timestamp"] = 1566935005,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [166]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 965,
					["Timestamp"] = 1566935015,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [167]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1684,
					["Timestamp"] = 1566935018,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [168]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 982,
					["Timestamp"] = 1566935042,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [169]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 958,
					["Timestamp"] = 1566935056,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [170]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1684,
					["Timestamp"] = 1566935591,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [171]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1683,
					["Timestamp"] = 1566935599,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [172]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1683,
					["Timestamp"] = 1566936090,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [173]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1686,
					["Timestamp"] = 1566936094,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [174]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 2519,
					["Timestamp"] = 1566936511,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [175]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 2519,
					["Timestamp"] = 1566936599,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [176]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 2518,
					["Timestamp"] = 1566936604,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [177]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 2518,
					["Timestamp"] = 1566936647,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [178]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 730,
					["Timestamp"] = 1566936651,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [179]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1686,
					["Timestamp"] = 1566937479,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [180]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1692,
					["Timestamp"] = 1566937482,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [181]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1692,
					["Timestamp"] = 1566937499,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [182]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Timestamp"] = 1566937507,
					["Event"] = "Level",
					["NewLevel"] = 15,
				}, -- [183]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 14,
					["Quest"] = 1693,
					["Timestamp"] = 1566937507,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [184]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 730,
					["Timestamp"] = 1566937706,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [185]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 1001,
					["Timestamp"] = 1566938032,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [186]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4723,
					["Timestamp"] = 1566938079,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [187]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 957,
					["Timestamp"] = 1566938183,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [188]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4812,
					["Timestamp"] = 1566938464,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [189]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 14,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4813,
					["Timestamp"] = 1566938464,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [190]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 1002,
					["Timestamp"] = 1566939735,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [191]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 965,
					["Timestamp"] = 1566939747,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [192]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 966,
					["Timestamp"] = 1566939748,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [193]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 966,
					["Timestamp"] = 1566940350,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [194]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 967,
					["Timestamp"] = 1566940351,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [195]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4727,
					["Timestamp"] = 1566940418,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [196]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4725,
					["Timestamp"] = 1566941126,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [197]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 1002,
					["Timestamp"] = 1566941545,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [198]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 1003,
					["Timestamp"] = 1566941552,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [199]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4723,
					["Timestamp"] = 1566941618,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [200]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4725,
					["Timestamp"] = 1566941621,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [201]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 4727,
					["Timestamp"] = 1566941624,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [202]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Timestamp"] = 1566941644,
					["Event"] = "Level",
					["NewLevel"] = 16,
				}, -- [203]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 15,
					["Quest"] = 947,
					["Timestamp"] = 1566941644,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [204]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 948,
					["Timestamp"] = 1566941648,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [205]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 4813,
					["Timestamp"] = 1566941674,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [206]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 2138,
					["Timestamp"] = 1566941690,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [207]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 2139,
					["Timestamp"] = 1566941694,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [208]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 982,
					["Timestamp"] = 1566941719,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [209]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 4762,
					["Timestamp"] = 1566941763,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [210]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 15,
						}, -- [1]
					},
					["Level"] = 16,
					["Quest"] = 4763,
					["Timestamp"] = 1566941767,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [211]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Timestamp"] = 1566943130,
					["Quest"] = 4763,
					["Level"] = 16,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [212]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Timestamp"] = 1566943267,
					["Quest"] = 436,
					["Level"] = 16,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [213]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Timestamp"] = 1566944460,
					["Quest"] = 237,
					["Level"] = 16,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [214]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Timestamp"] = 1566944468,
					["Quest"] = 263,
					["Level"] = 16,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [215]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 273,
					["Timestamp"] = 1566944684,
				}, -- [216]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 454,
					["Timestamp"] = 1566944684,
				}, -- [217]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 454,
					["Timestamp"] = 1566944687,
				}, -- [218]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 309,
					["Timestamp"] = 1566944687,
				}, -- [219]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 436,
					["Timestamp"] = 1566944931,
				}, -- [220]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 297,
					["Timestamp"] = 1566944933,
				}, -- [221]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 309,
					["Timestamp"] = 1566944943,
				}, -- [222]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 385,
					["Timestamp"] = 1566945450,
				}, -- [223]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 257,
					["Timestamp"] = 1566945465,
				}, -- [224]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 257,
					["Timestamp"] = 1566945670,
				}, -- [225]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 258,
					["Timestamp"] = 1566945670,
				}, -- [226]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 16,
					["Quest"] = 258,
					["Timestamp"] = 1566946034,
				}, -- [227]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 271,
					["Timestamp"] = 1566946051,
				}, -- [228]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 16,
					["Quest"] = 2038,
					["Timestamp"] = 1566946211,
				}, -- [229]
				{
					["Timestamp"] = 1566947344,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 17,
				}, -- [230]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 17,
					["Quest"] = 250,
					["Timestamp"] = 1566947906,
				}, -- [231]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 250,
					["Timestamp"] = 1566947992,
				}, -- [232]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 17,
					["Quest"] = 199,
					["Timestamp"] = 1566948001,
				}, -- [233]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 199,
					["Timestamp"] = 1566948056,
				}, -- [234]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 16,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 17,
					["Quest"] = 161,
					["Timestamp"] = 1566948060,
				}, -- [235]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 2038,
					["Timestamp"] = 1566948515,
				}, -- [236]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 297,
					["Timestamp"] = 1566949540,
				}, -- [237]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 263,
					["Timestamp"] = 1566949982,
				}, -- [238]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 17,
					["Quest"] = 217,
					["Timestamp"] = 1566949993,
				}, -- [239]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 217,
					["Timestamp"] = 1566950314,
				}, -- [240]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 385,
					["Timestamp"] = 1566950634,
				}, -- [241]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 271,
					["Timestamp"] = 1566950647,
				}, -- [242]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 17,
					["Quest"] = 531,
					["Timestamp"] = 1566950647,
				}, -- [243]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 17,
					["Quest"] = 531,
					["Timestamp"] = 1566950664,
				}, -- [244]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566953793,
					["Quest"] = 1138,
					["Level"] = 17,
				}, -- [245]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566953826,
					["Quest"] = 4740,
					["Level"] = 17,
				}, -- [246]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566953845,
					["Quest"] = 729,
					["Level"] = 17,
				}, -- [247]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566953859,
					["Quest"] = 4763,
					["Level"] = 17,
				}, -- [248]
				{
					["Timestamp"] = 1566955048,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 18,
				}, -- [249]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566955048,
					["Quest"] = 2139,
					["Level"] = 17,
				}, -- [250]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 17,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566955121,
					["Quest"] = 4763,
					["Level"] = 18,
				}, -- [251]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Descending",
							["Level"] = 16,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Descending",
							["Level"] = 16,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566955968,
					["Quest"] = 4730,
					["Level"] = 18,
				}, -- [252]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Descending",
							["Level"] = 16,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Descending",
							["Level"] = 16,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566956089,
					["Quest"] = 4731,
					["Level"] = 18,
				}, -- [253]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566956177,
					["Quest"] = 4732,
					["Level"] = 18,
				}, -- [254]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566956259,
					["Quest"] = 4733,
					["Level"] = 18,
				}, -- [255]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [3]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566956333,
					["Quest"] = 729,
					["Level"] = 18,
				}, -- [256]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 17,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566956341,
					["Quest"] = 731,
					["Level"] = 18,
				}, -- [257]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1566957144,
					["Quest"] = 731,
					["Level"] = 18,
				}, -- [258]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566957537,
					["Quest"] = 731,
					["Level"] = 18,
				}, -- [259]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566957972,
					["Quest"] = 1003,
					["Level"] = 18,
				}, -- [260]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566958028,
					["Quest"] = 948,
					["Level"] = 18,
				}, -- [261]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566958061,
					["Quest"] = 944,
					["Level"] = 18,
				}, -- [262]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Druid",
							["Name"] = "Djuno",
							["Level"] = 17,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566958065,
					["Quest"] = 5321,
					["Level"] = 18,
				}, -- [263]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566958447,
					["Quest"] = 944,
					["Level"] = 18,
				}, -- [264]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566958448,
					["Quest"] = 949,
					["Level"] = 18,
				}, -- [265]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566958454,
					["Quest"] = 949,
					["Level"] = 18,
				}, -- [266]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566958455,
					["Quest"] = 950,
					["Level"] = 18,
				}, -- [267]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566960495,
					["Quest"] = 945,
					["Level"] = 18,
				}, -- [268]
				{
					["Timestamp"] = 1566961215,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 19,
				}, -- [269]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566961215,
					["Quest"] = 950,
					["Level"] = 18,
				}, -- [270]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566961327,
					["Quest"] = 951,
					["Level"] = 19,
				}, -- [271]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [3]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1566961371,
					["Quest"] = 5321,
					["Level"] = 19,
				}, -- [272]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566961515,
					["Quest"] = 5321,
					["Level"] = 19,
				}, -- [273]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [3]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566962026,
					["Quest"] = 967,
					["Level"] = 19,
				}, -- [274]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 18,
						}, -- [3]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1566962027,
					["Quest"] = 970,
					["Level"] = 19,
				}, -- [275]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [3]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566962092,
					["Quest"] = 5321,
					["Level"] = 19,
				}, -- [276]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1566962233,
					["Quest"] = 945,
					["Level"] = 19,
				}, -- [277]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1566962314,
					["Quest"] = 970,
					["Level"] = 19,
				}, -- [278]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 4730,
					["Timestamp"] = 1566962680,
				}, -- [279]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 4731,
					["Timestamp"] = 1566962684,
				}, -- [280]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 4733,
					["Timestamp"] = 1566962686,
				}, -- [281]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 4732,
					["Timestamp"] = 1566962694,
				}, -- [282]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 1138,
					["Timestamp"] = 1566962722,
				}, -- [283]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 4740,
					["Timestamp"] = 1566962762,
				}, -- [284]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 986,
					["Timestamp"] = 1566962783,
				}, -- [285]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 993,
					["Timestamp"] = 1566962790,
				}, -- [286]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 731,
					["Timestamp"] = 1566962837,
				}, -- [287]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 741,
					["Timestamp"] = 1566962837,
				}, -- [288]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 741,
					["Timestamp"] = 1566963055,
				}, -- [289]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 942,
					["Timestamp"] = 1566963067,
				}, -- [290]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 19,
					["Quest"] = 993,
					["Timestamp"] = 1566963404,
				}, -- [291]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 942,
					["Timestamp"] = 1566963630,
				}, -- [292]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 943,
					["Timestamp"] = 1566963633,
				}, -- [293]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 2041,
					["Timestamp"] = 1566963904,
				}, -- [294]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 2041,
					["Timestamp"] = 1566964064,
				}, -- [295]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 19,
					["Quest"] = 2040,
					["Timestamp"] = 1566964068,
				}, -- [296]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 19,
					["Quest"] = 1338,
					["Timestamp"] = 1566964104,
				}, -- [297]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Level"] = 19,
					["Quest"] = 11,
					["Timestamp"] = 1567004011,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [298]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Level"] = 19,
					["Quest"] = 109,
					["Timestamp"] = 1567004236,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [299]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Level"] = 19,
					["Quest"] = 65,
					["Timestamp"] = 1567004240,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [300]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["Level"] = 19,
					["Quest"] = 12,
					["Timestamp"] = 1567004244,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [301]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567005759,
					["Quest"] = 12,
					["Level"] = 19,
				}, -- [302]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567005762,
					["Quest"] = 13,
					["Level"] = 19,
				}, -- [303]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567005896,
					["Quest"] = 13,
					["Level"] = 19,
				}, -- [304]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567005900,
					["Quest"] = 13,
					["Level"] = 19,
				}, -- [305]
				{
					["Timestamp"] = 1567006237,
					["Party"] = {
						{
							["Class"] = "Rogue",
							["Name"] = "Canaan",
							["Level"] = 13,
						}, -- [1]
						{
							["Class"] = "Rogue",
							["Name"] = "Canaan",
							["Level"] = 13,
						}, -- [2]
					},
					["Event"] = "Level",
					["NewLevel"] = 20,
				}, -- [306]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567006751,
					["Quest"] = 13,
					["Level"] = 20,
				}, -- [307]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567006756,
					["Quest"] = 14,
					["Level"] = 20,
				}, -- [308]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 19,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567006780,
					["Quest"] = 153,
					["Level"] = 20,
				}, -- [309]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567008312,
					["Quest"] = 14,
					["Level"] = 20,
				}, -- [310]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567008575,
					["Quest"] = 11,
					["Level"] = 20,
				}, -- [311]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567008768,
					["Quest"] = 65,
					["Level"] = 20,
				}, -- [312]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567008771,
					["Quest"] = 132,
					["Level"] = 20,
				}, -- [313]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009021,
					["Quest"] = 132,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [314]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009022,
					["Quest"] = 135,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [315]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009250,
					["Quest"] = 135,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [316]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009251,
					["Quest"] = 141,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [317]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009569,
					["Quest"] = 141,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [318]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Timestamp"] = 1567009569,
					["Quest"] = 142,
					["Level"] = 20,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [319]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 20,
					["Quest"] = 142,
					["Timestamp"] = 1567010024,
				}, -- [320]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Schlomo",
							["Level"] = 17,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Schlomo",
							["Level"] = 17,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Schlomo",
							["Level"] = 17,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Schlomo",
							["Level"] = 17,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 20,
					["Quest"] = 155,
					["Timestamp"] = 1567010103,
				}, -- [321]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Level"] = 20,
					["Quest"] = 155,
					["Timestamp"] = 1567010459,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [322]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Level"] = 20,
					["Quest"] = 166,
					["Timestamp"] = 1567010460,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [323]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
					},
					["Level"] = 20,
					["Quest"] = 214,
					["Timestamp"] = 1567010502,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [324]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [3]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 20,
						}, -- [4]
					},
					["Timestamp"] = 1567014712,
					["Event"] = "Level",
					["NewLevel"] = 21,
				}, -- [325]
				{
					["Party"] = {
					},
					["Level"] = 21,
					["Quest"] = 166,
					["Timestamp"] = 1567017401,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [326]
				{
					["Party"] = {
					},
					["Level"] = 21,
					["Quest"] = 214,
					["Timestamp"] = 1567017437,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [327]
				{
					["Party"] = {
					},
					["Level"] = 21,
					["Quest"] = 153,
					["Timestamp"] = 1567017459,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [328]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 2040,
					["Timestamp"] = 1567017661,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [329]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 2928,
					["Timestamp"] = 1567017662,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [330]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 373,
					["Timestamp"] = 1567017761,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [331]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 373,
					["Timestamp"] = 1567017851,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [332]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 389,
					["Timestamp"] = 1567017852,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [333]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 389,
					["Timestamp"] = 1567017951,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [334]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Level"] = 21,
					["Quest"] = 391,
					["Timestamp"] = 1567017951,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [335]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567020935,
					["Quest"] = 244,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [336]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021056,
					["Quest"] = 244,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [337]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021057,
					["Quest"] = 246,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [338]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021066,
					["Quest"] = 128,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [339]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021087,
					["Quest"] = 20,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [340]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021095,
					["Quest"] = 125,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [341]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021101,
					["Quest"] = 118,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [342]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021129,
					["Quest"] = 3741,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [343]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021158,
					["Quest"] = 91,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [344]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021166,
					["Quest"] = 120,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [345]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021179,
					["Quest"] = 169,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [346]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021209,
					["Quest"] = 1699,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [347]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021228,
					["Quest"] = 127,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [348]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021230,
					["Quest"] = 150,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [349]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021253,
					["Quest"] = 129,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [350]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021277,
					["Quest"] = 34,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [351]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Sid",
							["Level"] = 18,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Sid",
							["Level"] = 18,
						}, -- [2]
					},
					["Timestamp"] = 1567021522,
					["Quest"] = 1699,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [352]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021868,
					["Quest"] = 34,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [353]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021986,
					["Quest"] = 129,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [354]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567021987,
					["Quest"] = 130,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [355]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567022047,
					["Quest"] = 246,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [356]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567024822,
					["Quest"] = 150,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [357]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567024824,
					["Quest"] = 127,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [358]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567024859,
					["Quest"] = 20,
					["Level"] = 21,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [359]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567024859,
					["Event"] = "Level",
					["NewLevel"] = 22,
				}, -- [360]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 21,
						}, -- [1]
					},
					["Timestamp"] = 1567024860,
					["Quest"] = 19,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [361]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024953,
					["Quest"] = 3741,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [362]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024969,
					["Quest"] = 115,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [363]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024973,
					["Quest"] = 125,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [364]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024973,
					["Quest"] = 89,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [365]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024991,
					["Quest"] = 89,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [366]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567024995,
					["Quest"] = 386,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [367]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567025010,
					["Quest"] = 130,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [368]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567025010,
					["Quest"] = 131,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [369]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Timestamp"] = 1567025046,
					["Quest"] = 131,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [370]
				{
					["Party"] = {
					},
					["Timestamp"] = 1567027651,
					["Quest"] = 19,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [371]
				{
					["Party"] = {
					},
					["Timestamp"] = 1567027652,
					["Quest"] = 115,
					["Level"] = 22,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [372]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 66,
					["Timestamp"] = 1567040475,
				}, -- [373]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 101,
					["Timestamp"] = 1567040477,
				}, -- [374]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 174,
					["Timestamp"] = 1567040524,
				}, -- [375]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 174,
					["Timestamp"] = 1567040538,
				}, -- [376]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 175,
					["Timestamp"] = 1567040538,
				}, -- [377]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 120,
					["Timestamp"] = 1567040711,
				}, -- [378]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 121,
					["Timestamp"] = 1567040712,
				}, -- [379]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 176,
					["Timestamp"] = 1567040909,
				}, -- [380]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 59,
					["Timestamp"] = 1567040910,
				}, -- [381]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 118,
					["Timestamp"] = 1567040915,
				}, -- [382]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 119,
					["Timestamp"] = 1567040916,
				}, -- [383]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 121,
					["Timestamp"] = 1567041053,
				}, -- [384]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 143,
					["Timestamp"] = 1567041053,
				}, -- [385]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 119,
					["Timestamp"] = 1567041082,
				}, -- [386]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 122,
					["Timestamp"] = 1567041083,
				}, -- [387]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 22,
					["Quest"] = 59,
					["Timestamp"] = 1567041104,
				}, -- [388]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 163,
					["Timestamp"] = 1567041235,
				}, -- [389]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 165,
					["Timestamp"] = 1567041236,
				}, -- [390]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 164,
					["Timestamp"] = 1567041237,
				}, -- [391]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 56,
					["Timestamp"] = 1567041250,
				}, -- [392]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 245,
					["Timestamp"] = 1567041521,
				}, -- [393]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 163,
					["Timestamp"] = 1567041642,
				}, -- [394]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 5,
					["Timestamp"] = 1567041643,
				}, -- [395]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 164,
					["Timestamp"] = 1567041769,
				}, -- [396]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 95,
					["Timestamp"] = 1567041771,
				}, -- [397]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 226,
					["Timestamp"] = 1567041773,
				}, -- [398]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 165,
					["Timestamp"] = 1567042686,
				}, -- [399]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 148,
					["Timestamp"] = 1567042688,
				}, -- [400]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 22,
					["Quest"] = 161,
					["Timestamp"] = 1567044136,
				}, -- [401]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 148,
					["Timestamp"] = 1567044379,
				}, -- [402]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 149,
					["Timestamp"] = 1567044380,
				}, -- [403]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 5,
					["Timestamp"] = 1567044398,
				}, -- [404]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 93,
					["Timestamp"] = 1567044399,
				}, -- [405]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 66,
					["Timestamp"] = 1567044445,
				}, -- [406]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 67,
					["Timestamp"] = 1567044446,
				}, -- [407]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 149,
					["Timestamp"] = 1567044582,
				}, -- [408]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 154,
					["Timestamp"] = 1567044583,
				}, -- [409]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 175,
					["Timestamp"] = 1567044584,
				}, -- [410]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 22,
					["Quest"] = 177,
					["Timestamp"] = 1567044585,
				}, -- [411]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 22,
					["Quest"] = 177,
					["Timestamp"] = 1567045239,
				}, -- [412]
				{
					["Timestamp"] = 1567045239,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 23,
				}, -- [413]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 181,
					["Timestamp"] = 1567045240,
				}, -- [414]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 56,
					["Timestamp"] = 1567045280,
				}, -- [415]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 57,
					["Timestamp"] = 1567045281,
				}, -- [416]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 154,
					["Timestamp"] = 1567045292,
				}, -- [417]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 22,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 157,
					["Timestamp"] = 1567045293,
				}, -- [418]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 93,
					["Timestamp"] = 1567045483,
				}, -- [419]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 240,
					["Timestamp"] = 1567045484,
				}, -- [420]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 143,
					["Timestamp"] = 1567045677,
				}, -- [421]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 144,
					["Timestamp"] = 1567045678,
				}, -- [422]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 226,
					["Timestamp"] = 1567045903,
				}, -- [423]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 157,
					["Timestamp"] = 1567046021,
				}, -- [424]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 158,
					["Timestamp"] = 1567046022,
				}, -- [425]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 240,
					["Timestamp"] = 1567046119,
				}, -- [426]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 245,
					["Timestamp"] = 1567046240,
				}, -- [427]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 124,
					["Timestamp"] = 1567046298,
				}, -- [428]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 144,
					["Timestamp"] = 1567046319,
				}, -- [429]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 145,
					["Timestamp"] = 1567046320,
				}, -- [430]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 89,
					["Timestamp"] = 1567046339,
				}, -- [431]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 180,
					["Timestamp"] = 1567046361,
				}, -- [432]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 23,
					["Quest"] = 951,
					["Timestamp"] = 1567046377,
				}, -- [433]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 7,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 23,
					["Quest"] = 943,
					["Timestamp"] = 1567046380,
				}, -- [434]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 91,
					["Timestamp"] = 1567049918,
				}, -- [435]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 180,
					["Timestamp"] = 1567049920,
				}, -- [436]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 128,
					["Timestamp"] = 1567049968,
				}, -- [437]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 158,
					["Timestamp"] = 1567050059,
				}, -- [438]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 156,
					["Timestamp"] = 1567050060,
				}, -- [439]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 23,
					["Quest"] = 145,
					["Timestamp"] = 1567050093,
				}, -- [440]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 9,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 23,
					["Quest"] = 146,
					["Timestamp"] = 1567050094,
				}, -- [441]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 23,
					["Quest"] = 67,
					["Timestamp"] = 1567089613,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [442]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 23,
					["Quest"] = 68,
					["Timestamp"] = 1567089614,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [443]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 23,
					["Quest"] = 68,
					["Timestamp"] = 1567089662,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [444]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 23,
					["Quest"] = 69,
					["Timestamp"] = 1567089663,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [445]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Timestamp"] = 1567089942,
					["Event"] = "Level",
					["NewLevel"] = 24,
				}, -- [446]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 95,
					["Timestamp"] = 1567090054,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [447]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 23,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 230,
					["Timestamp"] = 1567090055,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [448]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 337,
					["Timestamp"] = 1567093733,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [449]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 230,
					["Timestamp"] = 1567093887,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [450]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 262,
					["Timestamp"] = 1567093888,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [451]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 69,
					["Timestamp"] = 1567094089,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [452]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 70,
					["Timestamp"] = 1567094090,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [453]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 70,
					["Timestamp"] = 1567094372,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [454]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 72,
					["Timestamp"] = 1567094373,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [455]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 72,
					["Timestamp"] = 1567094403,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [456]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 74,
					["Timestamp"] = 1567094404,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [457]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 337,
					["Timestamp"] = 1567094592,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [458]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 538,
					["Timestamp"] = 1567094593,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [459]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 156,
					["Timestamp"] = 1567094708,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [460]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 159,
					["Timestamp"] = 1567094709,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [461]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 57,
					["Timestamp"] = 1567094725,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [462]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 58,
					["Timestamp"] = 1567094726,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [463]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 262,
					["Timestamp"] = 1567094737,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [464]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 265,
					["Timestamp"] = 1567094738,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [465]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 101,
					["Timestamp"] = 1567094739,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [466]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 265,
					["Timestamp"] = 1567094754,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [467]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 266,
					["Timestamp"] = 1567094755,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [468]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 266,
					["Timestamp"] = 1567094819,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [469]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 453,
					["Timestamp"] = 1567094828,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [470]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 24,
					["Quest"] = 74,
					["Timestamp"] = 1567105541,
				}, -- [471]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 24,
					["Quest"] = 75,
					["Timestamp"] = 1567105542,
				}, -- [472]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 24,
					["Quest"] = 75,
					["Timestamp"] = 1567105605,
				}, -- [473]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 24,
					["Quest"] = 78,
					["Timestamp"] = 1567105606,
				}, -- [474]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 24,
					["Quest"] = 146,
					["Timestamp"] = 1567105796,
				}, -- [475]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 122,
					["Timestamp"] = 1567106363,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [476]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 124,
					["Timestamp"] = 1567106367,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [477]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 89,
					["Timestamp"] = 1567106371,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [478]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 169,
					["Timestamp"] = 1567106373,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [479]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 288,
					["Timestamp"] = 1567106427,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [480]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 463,
					["Timestamp"] = 1567106429,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [481]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["Level"] = 24,
					["Quest"] = 470,
					["Timestamp"] = 1567106443,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [482]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567106502,
					["Quest"] = 279,
					["Level"] = 24,
				}, -- [483]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567106784,
					["Quest"] = 294,
					["Level"] = 24,
				}, -- [484]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567107462,
					["Quest"] = 294,
					["Level"] = 24,
				}, -- [485]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567107463,
					["Quest"] = 295,
					["Level"] = 24,
				}, -- [486]
				{
					["Timestamp"] = 1567107734,
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Kyphos",
							["Level"] = 25,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Kyphos",
							["Level"] = 25,
						}, -- [2]
					},
					["Event"] = "Level",
					["NewLevel"] = 25,
				}, -- [487]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567108031,
					["Quest"] = 295,
					["Level"] = 25,
				}, -- [488]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567108032,
					["Quest"] = 296,
					["Level"] = 25,
				}, -- [489]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 24,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567108050,
					["Quest"] = 299,
					["Level"] = 25,
				}, -- [490]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567109049,
					["Quest"] = 296,
					["Level"] = 25,
				}, -- [491]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567109058,
					["Quest"] = 299,
					["Level"] = 25,
				}, -- [492]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567109932,
					["Quest"] = 469,
					["Level"] = 25,
				}, -- [493]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567109976,
					["Quest"] = 463,
					["Level"] = 25,
				}, -- [494]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567109976,
					["Quest"] = 276,
					["Level"] = 25,
				}, -- [495]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567110764,
					["Quest"] = 276,
					["Level"] = 25,
				}, -- [496]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567110765,
					["Quest"] = 277,
					["Level"] = 25,
				}, -- [497]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567112104,
					["Quest"] = 277,
					["Level"] = 25,
				}, -- [498]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567112105,
					["Quest"] = 275,
					["Level"] = 25,
				}, -- [499]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567112197,
					["Quest"] = 469,
					["Level"] = 25,
				}, -- [500]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567112198,
					["Quest"] = 484,
					["Level"] = 25,
				}, -- [501]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567112274,
					["Quest"] = 279,
					["Level"] = 25,
				}, -- [502]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567112274,
					["Quest"] = 281,
					["Level"] = 25,
				}, -- [503]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113017,
					["Quest"] = 1008,
					["Level"] = 25,
				}, -- [504]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113020,
					["Quest"] = 4581,
					["Level"] = 25,
				}, -- [505]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113030,
					["Quest"] = 1070,
					["Level"] = 25,
				}, -- [506]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567113052,
					["Quest"] = 1070,
					["Level"] = 25,
				}, -- [507]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113068,
					["Quest"] = 991,
					["Level"] = 25,
				}, -- [508]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113078,
					["Quest"] = 1054,
					["Level"] = 25,
				}, -- [509]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567113177,
					["Quest"] = 4581,
					["Level"] = 25,
				}, -- [510]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113286,
					["Quest"] = 1010,
					["Level"] = 25,
				}, -- [511]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567113301,
					["Quest"] = 970,
					["Level"] = 25,
				}, -- [512]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567113997,
					["Quest"] = 970,
					["Level"] = 25,
				}, -- [513]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567114041,
					["Quest"] = 1010,
					["Level"] = 25,
				}, -- [514]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567114042,
					["Quest"] = 1020,
					["Level"] = 25,
				}, -- [515]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567114138,
					["Quest"] = 991,
					["Level"] = 25,
				}, -- [516]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567114139,
					["Quest"] = 1023,
					["Level"] = 25,
				}, -- [517]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567114257,
					["Quest"] = 1007,
					["Level"] = 25,
				}, -- [518]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567114520,
					["Quest"] = 1007,
					["Level"] = 25,
				}, -- [519]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567114520,
					["Quest"] = 1009,
					["Level"] = 25,
				}, -- [520]
				{
					["Timestamp"] = 1567115389,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 26,
				}, -- [521]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567115389,
					["Quest"] = 1009,
					["Level"] = 25,
				}, -- [522]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567115654,
					["Quest"] = 1008,
					["Level"] = 26,
				}, -- [523]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567115686,
					["Quest"] = 1023,
					["Level"] = 26,
				}, -- [524]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567115687,
					["Quest"] = 1024,
					["Level"] = 26,
				}, -- [525]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 25,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567115688,
					["Quest"] = 1025,
					["Level"] = 26,
				}, -- [526]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567115746,
					["Quest"] = 1020,
					["Level"] = 26,
				}, -- [527]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567115747,
					["Quest"] = 1033,
					["Level"] = 26,
				}, -- [528]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567116507,
					["Quest"] = 1033,
					["Level"] = 26,
				}, -- [529]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567116563,
					["Quest"] = 1054,
					["Level"] = 26,
				}, -- [530]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567116597,
					["Quest"] = 1024,
					["Level"] = 26,
				}, -- [531]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567116599,
					["Quest"] = 1025,
					["Level"] = 26,
				}, -- [532]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567116622,
					["Quest"] = 943,
					["Level"] = 26,
				}, -- [533]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567116777,
					["Quest"] = 971,
					["Level"] = 26,
				}, -- [534]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567117567,
					["Quest"] = 3765,
					["Level"] = 26,
				}, -- [535]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Timestamp"] = 1567121917,
					["Quest"] = 3765,
					["Level"] = 26,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [536]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Timestamp"] = 1567121917,
					["Quest"] = 1275,
					["Level"] = 26,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [537]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Timestamp"] = 1567122126,
					["Quest"] = 2925,
					["Level"] = 26,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [538]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Timestamp"] = 1567122168,
					["Quest"] = 1199,
					["Level"] = 26,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [539]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Timestamp"] = 1567122170,
					["Quest"] = 1198,
					["Level"] = 26,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [540]
				{
					["Party"] = {
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 26,
					["Quest"] = 1198,
					["Timestamp"] = 1567126616,
				}, -- [541]
				{
					["Party"] = {
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 26,
					["Quest"] = 1200,
					["Timestamp"] = 1567126617,
				}, -- [542]
				{
					["Party"] = {
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Rogue",
							["Name"] = "Antidotes",
							["Level"] = 26,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 26,
					["Quest"] = 1200,
					["Timestamp"] = 1567131106,
				}, -- [543]
				{
					["Timestamp"] = 1567131346,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 27,
				}, -- [544]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 26,
					["Quest"] = 1275,
					["Timestamp"] = 1567131346,
				}, -- [545]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 27,
					["Quest"] = 1199,
					["Timestamp"] = 1567131427,
				}, -- [546]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 26,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 27,
					["Quest"] = 971,
					["Timestamp"] = 1567131631,
				}, -- [547]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 27,
					["Quest"] = 2925,
					["Timestamp"] = 1567131754,
				}, -- [548]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 27,
					["Quest"] = 2924,
					["Timestamp"] = 1567131755,
				}, -- [549]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 288,
					["Timestamp"] = 1567132070,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [550]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 289,
					["Timestamp"] = 1567132070,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [551]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 472,
					["Timestamp"] = 1567132102,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [552]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 484,
					["Timestamp"] = 1567132115,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [553]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 464,
					["Timestamp"] = 1567132132,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [554]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 305,
					["Timestamp"] = 1567132187,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [555]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 281,
					["Timestamp"] = 1567132244,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [556]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 284,
					["Timestamp"] = 1567132245,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [557]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 284,
					["Timestamp"] = 1567132282,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [558]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 285,
					["Timestamp"] = 1567132283,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [559]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 285,
					["Timestamp"] = 1567132299,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [560]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 286,
					["Timestamp"] = 1567132300,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [561]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 472,
					["Timestamp"] = 1567133642,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [562]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 304,
					["Timestamp"] = 1567133642,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [563]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 303,
					["Timestamp"] = 1567133643,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [564]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 275,
					["Timestamp"] = 1567133779,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [565]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 305,
					["Timestamp"] = 1567135793,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [566]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 306,
					["Timestamp"] = 1567135794,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [567]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 306,
					["Timestamp"] = 1567136247,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [568]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 464,
					["Timestamp"] = 1567136296,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [569]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 465,
					["Timestamp"] = 1567136297,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [570]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 470,
					["Timestamp"] = 1567136332,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [571]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 289,
					["Timestamp"] = 1567136357,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [572]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 290,
					["Timestamp"] = 1567136358,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [573]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 943,
					["Timestamp"] = 1567136438,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [574]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 286,
					["Timestamp"] = 1567136484,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [575]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Thorn",
							["Level"] = 32,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Thorn",
							["Level"] = 32,
						}, -- [2]
					},
					["Level"] = 27,
					["Quest"] = 290,
					["Timestamp"] = 1567137158,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [576]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Thorn",
							["Level"] = 32,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Thorn",
							["Level"] = 32,
						}, -- [2]
					},
					["Level"] = 27,
					["Quest"] = 292,
					["Timestamp"] = 1567137159,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [577]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 27,
					["Quest"] = 465,
					["Timestamp"] = 1567137607,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [578]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Timestamp"] = 1567137607,
					["Event"] = "Level",
					["NewLevel"] = 28,
				}, -- [579]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 27,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 474,
					["Timestamp"] = 1567137608,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [580]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [3]
					},
					["Level"] = 28,
					["Quest"] = 292,
					["Timestamp"] = 1567137807,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [581]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Whipper",
							["Level"] = 29,
						}, -- [3]
					},
					["Level"] = 28,
					["Quest"] = 293,
					["Timestamp"] = 1567137808,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [582]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [2]
					},
					["Level"] = 28,
					["Quest"] = 474,
					["Timestamp"] = 1567137869,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [583]
				{
					["Party"] = {
					},
					["Level"] = 28,
					["Quest"] = 467,
					["Timestamp"] = 1567138271,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [584]
				{
					["Party"] = {
					},
					["Level"] = 28,
					["Quest"] = 1179,
					["Timestamp"] = 1567138273,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [585]
				{
					["Party"] = {
					},
					["Level"] = 28,
					["Quest"] = 467,
					["Timestamp"] = 1567138303,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [586]
				{
					["Party"] = {
					},
					["Level"] = 28,
					["Quest"] = 293,
					["Timestamp"] = 1567138362,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [587]
				{
					["Party"] = {
					},
					["Level"] = 28,
					["Quest"] = 293,
					["Timestamp"] = 1567138498,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [588]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 293,
					["Timestamp"] = 1567139074,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [589]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 1274,
					["Timestamp"] = 1567139079,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [590]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 2923,
					["Timestamp"] = 1567139085,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [591]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 1274,
					["Timestamp"] = 1567139753,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [592]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Level"] = 28,
					["Quest"] = 1241,
					["Timestamp"] = 1567139753,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [593]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 1241,
					["Timestamp"] = 1567140685,
				}, -- [594]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 1242,
					["Timestamp"] = 1567140686,
				}, -- [595]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 1242,
					["Timestamp"] = 1567140736,
				}, -- [596]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 1243,
					["Timestamp"] = 1567140737,
				}, -- [597]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 78,
					["Timestamp"] = 1567140917,
				}, -- [598]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 79,
					["Timestamp"] = 1567140918,
				}, -- [599]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 79,
					["Timestamp"] = 1567140926,
				}, -- [600]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 80,
					["Timestamp"] = 1567140926,
				}, -- [601]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 80,
					["Timestamp"] = 1567140934,
				}, -- [602]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 97,
					["Timestamp"] = 1567140935,
				}, -- [603]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 97,
					["Timestamp"] = 1567140942,
				}, -- [604]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 98,
					["Timestamp"] = 1567140943,
				}, -- [605]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 1243,
					["Timestamp"] = 1567140978,
				}, -- [606]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 1244,
					["Timestamp"] = 1567140979,
				}, -- [607]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 98,
					["Timestamp"] = 1567141489,
				}, -- [608]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 173,
					["Timestamp"] = 1567141500,
				}, -- [609]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 453,
					["Timestamp"] = 1567142329,
				}, -- [610]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 268,
					["Timestamp"] = 1567142330,
				}, -- [611]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 268,
					["Timestamp"] = 1567142406,
				}, -- [612]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 323,
					["Timestamp"] = 1567142406,
				}, -- [613]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 323,
					["Timestamp"] = 1567143097,
				}, -- [614]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 269,
					["Timestamp"] = 1567143098,
				}, -- [615]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 225,
					["Timestamp"] = 1567143145,
				}, -- [616]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 159,
					["Timestamp"] = 1567143197,
				}, -- [617]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 133,
					["Timestamp"] = 1567143197,
				}, -- [618]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Fate",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Fate",
							["Level"] = 26,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 133,
					["Timestamp"] = 1567143872,
				}, -- [619]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Fate",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Fate",
							["Level"] = 26,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 134,
					["Timestamp"] = 1567143873,
				}, -- [620]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 134,
					["Timestamp"] = 1567144694,
				}, -- [621]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 160,
					["Timestamp"] = 1567144695,
				}, -- [622]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 173,
					["Timestamp"] = 1567145078,
				}, -- [623]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 221,
					["Timestamp"] = 1567145079,
				}, -- [624]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 181,
					["Timestamp"] = 1567145111,
				}, -- [625]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 58,
					["Timestamp"] = 1567145146,
				}, -- [626]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 225,
					["Timestamp"] = 1567145160,
				}, -- [627]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 227,
					["Timestamp"] = 1567145161,
				}, -- [628]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 160,
					["Timestamp"] = 1567145167,
				}, -- [629]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 251,
					["Timestamp"] = 1567145168,
				}, -- [630]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 251,
					["Timestamp"] = 1567145173,
				}, -- [631]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 28,
					["Quest"] = 401,
					["Timestamp"] = 1567145173,
				}, -- [632]
				{
					["Timestamp"] = 1567145175,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 29,
				}, -- [633]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 28,
					["Quest"] = 401,
					["Timestamp"] = 1567145175,
				}, -- [634]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 29,
					["Quest"] = 252,
					["Timestamp"] = 1567145176,
				}, -- [635]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 29,
					["Quest"] = 252,
					["Timestamp"] = 1567145182,
				}, -- [636]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 29,
					["Quest"] = 253,
					["Timestamp"] = 1567145182,
				}, -- [637]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 29,
					["Quest"] = 227,
					["Timestamp"] = 1567145193,
				}, -- [638]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 28,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 29,
					["Quest"] = 228,
					["Timestamp"] = 1567145193,
				}, -- [639]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567181195,
					["Quest"] = 1244,
					["Level"] = 29,
				}, -- [640]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567181195,
					["Quest"] = 1245,
					["Level"] = 29,
				}, -- [641]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567181696,
					["Quest"] = 221,
					["Level"] = 29,
				}, -- [642]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567181697,
					["Quest"] = 222,
					["Level"] = 29,
				}, -- [643]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567182815,
					["Quest"] = 254,
					["Level"] = 29,
				}, -- [644]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183212,
					["Quest"] = 222,
					["Level"] = 29,
				}, -- [645]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567183213,
					["Quest"] = 223,
					["Level"] = 29,
				}, -- [646]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183228,
					["Quest"] = 223,
					["Level"] = 29,
				}, -- [647]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183252,
					["Quest"] = 228,
					["Level"] = 29,
				}, -- [648]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567183253,
					["Quest"] = 229,
					["Level"] = 29,
				}, -- [649]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183271,
					["Quest"] = 253,
					["Level"] = 29,
				}, -- [650]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183318,
					["Quest"] = 229,
					["Level"] = 29,
				}, -- [651]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567183319,
					["Quest"] = 231,
					["Level"] = 29,
				}, -- [652]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567183701,
					["Quest"] = 231,
					["Level"] = 29,
				}, -- [653]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567184097,
					["Quest"] = 1245,
					["Level"] = 29,
				}, -- [654]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184097,
					["Quest"] = 1246,
					["Level"] = 29,
				}, -- [655]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567184370,
					["Quest"] = 1246,
					["Level"] = 29,
				}, -- [656]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184371,
					["Quest"] = 1447,
					["Level"] = 29,
				}, -- [657]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567184439,
					["Quest"] = 1447,
					["Level"] = 29,
				}, -- [658]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184440,
					["Quest"] = 1247,
					["Level"] = 29,
				}, -- [659]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184480,
					["Quest"] = 388,
					["Level"] = 29,
				}, -- [660]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567184588,
					["Quest"] = 1247,
					["Level"] = 29,
				}, -- [661]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184591,
					["Quest"] = 1248,
					["Level"] = 29,
				}, -- [662]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567184673,
					["Quest"] = 269,
					["Level"] = 29,
				}, -- [663]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184676,
					["Quest"] = 270,
					["Level"] = 29,
				}, -- [664]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 29,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567184776,
					["Quest"] = 387,
					["Level"] = 29,
				}, -- [665]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 25,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 25,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 25,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 25,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567185426,
					["Quest"] = 377,
					["Level"] = 29,
				}, -- [666]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 29,
					["Quest"] = 391,
					["Timestamp"] = 1567188867,
				}, -- [667]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 29,
					["Quest"] = 392,
					["Timestamp"] = 1567188869,
				}, -- [668]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 29,
					["Quest"] = 387,
					["Timestamp"] = 1567188869,
				}, -- [669]
				{
					["Timestamp"] = 1567188869,
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Level",
					["NewLevel"] = 30,
				}, -- [670]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 388,
					["Timestamp"] = 1567189013,
				}, -- [671]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 392,
					["Timestamp"] = 1567189089,
				}, -- [672]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 30,
					["Quest"] = 393,
					["Timestamp"] = 1567189090,
				}, -- [673]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 30,
					["Quest"] = 399,
					["Timestamp"] = 1567189092,
				}, -- [674]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 30,
					["Quest"] = 399,
					["Timestamp"] = 1567189101,
				}, -- [675]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 393,
					["Timestamp"] = 1567189233,
				}, -- [676]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 30,
					["Quest"] = 350,
					["Timestamp"] = 1567189233,
				}, -- [677]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 350,
					["Timestamp"] = 1567189311,
				}, -- [678]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 30,
					["Quest"] = 2745,
					["Timestamp"] = 1567189312,
				}, -- [679]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Andewin",
							["Level"] = 26,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 30,
					["Quest"] = 1718,
					["Timestamp"] = 1567189403,
				}, -- [680]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 386,
					["Timestamp"] = 1567189702,
				}, -- [681]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 30,
					["Quest"] = 377,
					["Timestamp"] = 1567189854,
				}, -- [682]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 690,
					["Timestamp"] = 1567195843,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [683]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 2745,
					["Timestamp"] = 1567195977,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [684]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 2746,
					["Timestamp"] = 1567195978,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [685]
				{
					["Party"] = {
					},
					["Level"] = 30,
					["Quest"] = 270,
					["Timestamp"] = 1567196548,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [686]
				{
					["Party"] = {
					},
					["Level"] = 30,
					["Quest"] = 321,
					["Timestamp"] = 1567196548,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [687]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1248,
					["Timestamp"] = 1567196643,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [688]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1249,
					["Timestamp"] = 1567196649,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [689]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1249,
					["Timestamp"] = 1567196708,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [690]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1249,
					["Timestamp"] = 1567196822,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [691]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Cirilla",
							["Level"] = 29,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Cirilla",
							["Level"] = 29,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 1249,
					["Timestamp"] = 1567196882,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [692]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Cirilla",
							["Level"] = 29,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Cirilla",
							["Level"] = 29,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 1250,
					["Timestamp"] = 1567196890,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [693]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1250,
					["Timestamp"] = 1567196895,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [694]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 1264,
					["Timestamp"] = 1567196895,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [695]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 321,
					["Timestamp"] = 1567196954,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [696]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 324,
					["Timestamp"] = 1567196955,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [697]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 324,
					["Timestamp"] = 1567197457,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [698]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 322,
					["Timestamp"] = 1567197457,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [699]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 631,
					["Timestamp"] = 1567197828,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [700]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 631,
					["Timestamp"] = 1567197910,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [701]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 632,
					["Timestamp"] = 1567197910,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [702]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 632,
					["Timestamp"] = 1567197966,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [703]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 633,
					["Timestamp"] = 1567197966,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [704]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 633,
					["Timestamp"] = 1567198208,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [705]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 634,
					["Timestamp"] = 1567198209,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [706]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 647,
					["Timestamp"] = 1567198307,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [707]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 637,
					["Timestamp"] = 1567198413,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [708]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 634,
					["Timestamp"] = 1567198632,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [709]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 681,
					["Timestamp"] = 1567198632,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [710]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 690,
					["Timestamp"] = 1567198637,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [711]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 538,
					["Timestamp"] = 1567199024,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [712]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 540,
					["Timestamp"] = 1567199025,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [713]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 647,
					["Timestamp"] = 1567199042,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [714]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 536,
					["Timestamp"] = 1567199084,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [715]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 30,
						}, -- [1]
					},
					["Level"] = 30,
					["Quest"] = 555,
					["Timestamp"] = 1567199089,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [716]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 536,
					["Timestamp"] = 1567199517,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [717]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 559,
					["Timestamp"] = 1567199518,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [718]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 559,
					["Timestamp"] = 1567200782,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [719]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 560,
					["Timestamp"] = 1567200783,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [720]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 560,
					["Timestamp"] = 1567200798,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [721]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 561,
					["Timestamp"] = 1567200798,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [722]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 561,
					["Timestamp"] = 1567200811,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [723]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 562,
					["Timestamp"] = 1567200812,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [724]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Timestamp"] = 1567201222,
					["Event"] = "Level",
					["NewLevel"] = 31,
				}, -- [725]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 30,
					["Quest"] = 562,
					["Timestamp"] = 1567201222,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [726]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Envie",
							["Level"] = 31,
						}, -- [2]
					},
					["Level"] = 31,
					["Quest"] = 563,
					["Timestamp"] = 1567201222,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [727]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567202288,
					["Quest"] = 1264,
					["Level"] = 31,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [728]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567202288,
					["Quest"] = 1265,
					["Level"] = 31,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [729]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567202346,
					["Quest"] = 1282,
					["Level"] = 31,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [730]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567202437,
					["Quest"] = 1133,
					["Level"] = 31,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [731]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567202440,
					["Quest"] = 1135,
					["Level"] = 31,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [732]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 31,
					["Quest"] = 1282,
					["Timestamp"] = 1567202541,
				}, -- [733]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 31,
					["Quest"] = 1133,
					["Timestamp"] = 1567202559,
				}, -- [734]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 31,
					["Quest"] = 1265,
					["Timestamp"] = 1567202646,
				}, -- [735]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1266,
					["Timestamp"] = 1567202647,
				}, -- [736]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 31,
					["Quest"] = 1266,
					["Timestamp"] = 1567202825,
				}, -- [737]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1284,
					["Timestamp"] = 1567203036,
				}, -- [738]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1253,
					["Timestamp"] = 1567203054,
				}, -- [739]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1252,
					["Timestamp"] = 1567203059,
				}, -- [740]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1100,
					["Timestamp"] = 1567203326,
				}, -- [741]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 31,
					["Quest"] = 1100,
					["Timestamp"] = 1567203639,
				}, -- [742]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 31,
					["Quest"] = 1101,
					["Timestamp"] = 1567203640,
				}, -- [743]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1179,
					["Timestamp"] = 1567205888,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [744]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1104,
					["Timestamp"] = 1567205894,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [745]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1110,
					["Timestamp"] = 1567205896,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [746]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 681,
					["Timestamp"] = 1567205905,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [747]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1111,
					["Timestamp"] = 1567205907,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [748]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 2923,
					["Timestamp"] = 1567205914,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [749]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 2924,
					["Timestamp"] = 1567205917,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [750]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 2928,
					["Timestamp"] = 1567205920,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [751]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 5762,
					["Timestamp"] = 1567205921,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [752]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1105,
					["Timestamp"] = 1567205925,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [753]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1176,
					["Timestamp"] = 1567205949,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [754]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 303,
					["Timestamp"] = 1567205998,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [755]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 304,
					["Timestamp"] = 1567206000,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [756]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1175,
					["Timestamp"] = 1567206002,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [757]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1110,
					["Timestamp"] = 1567210613,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [758]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1104,
					["Timestamp"] = 1567210619,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [759]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1105,
					["Timestamp"] = 1567210621,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [760]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1107,
					["Timestamp"] = 1567210621,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [761]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1106,
					["Timestamp"] = 1567210622,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [762]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1175,
					["Timestamp"] = 1567210650,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [763]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1176,
					["Timestamp"] = 1567211266,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [764]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1178,
					["Timestamp"] = 1567211267,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [765]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1284,
					["Timestamp"] = 1567211842,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [766]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1253,
					["Timestamp"] = 1567211843,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [767]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1319,
					["Timestamp"] = 1567211844,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [768]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1252,
					["Timestamp"] = 1567211846,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [769]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1259,
					["Timestamp"] = 1567211847,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [770]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1259,
					["Timestamp"] = 1567211853,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [771]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1285,
					["Timestamp"] = 1567211854,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [772]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1285,
					["Timestamp"] = 1567211860,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [773]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1286,
					["Timestamp"] = 1567211861,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [774]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Timestamp"] = 1567211912,
					["Event"] = "Level",
					["NewLevel"] = 32,
				}, -- [775]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 31,
					["Quest"] = 1135,
					["Timestamp"] = 1567211912,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [776]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 32,
					["Quest"] = 1133,
					["Timestamp"] = 1567211913,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [777]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 32,
					["Quest"] = 1319,
					["Timestamp"] = 1567211954,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [778]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 31,
						}, -- [1]
					},
					["Level"] = 32,
					["Quest"] = 1320,
					["Timestamp"] = 1567211955,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [779]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Level"] = 32,
					["Quest"] = 1320,
					["Timestamp"] = 1567212019,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [780]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567212228,
					["Quest"] = 1133,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [781]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567212734,
					["Quest"] = 1718,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [782]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567212735,
					["Quest"] = 1719,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [783]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567212986,
					["Quest"] = 1719,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [784]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567212987,
					["Quest"] = 1791,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [785]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213190,
					["Quest"] = 1178,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [786]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213191,
					["Quest"] = 1180,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [787]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213218,
					["Quest"] = 1111,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [788]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213220,
					["Quest"] = 1112,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [789]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213343,
					["Quest"] = 1180,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [790]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213344,
					["Quest"] = 1181,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [791]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213492,
					["Quest"] = 605,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [792]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213518,
					["Quest"] = 189,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [793]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213532,
					["Quest"] = 198,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [794]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213536,
					["Quest"] = 201,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [795]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213540,
					["Quest"] = 616,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [796]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213546,
					["Quest"] = 1181,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [797]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213547,
					["Quest"] = 1182,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [798]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213549,
					["Quest"] = 616,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [799]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213550,
					["Quest"] = 578,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [800]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213600,
					["Quest"] = 575,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [801]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213670,
					["Quest"] = 1791,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [802]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213679,
					["Quest"] = 555,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [803]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567213705,
					["Quest"] = 1286,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [804]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214098,
					["Quest"] = 203,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [805]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214135,
					["Quest"] = 204,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [806]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214139,
					["Quest"] = 210,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [807]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214212,
					["Quest"] = 198,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [808]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214213,
					["Quest"] = 215,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [809]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214246,
					["Quest"] = 1101,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [810]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214250,
					["Quest"] = 2746,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [811]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214260,
					["Quest"] = 215,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [812]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214260,
					["Quest"] = 200,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [813]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214341,
					["Quest"] = 583,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [814]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214347,
					["Quest"] = 583,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [815]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214348,
					["Quest"] = 5762,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [816]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214348,
					["Quest"] = 194,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [817]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214352,
					["Quest"] = 185,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [818]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["Timestamp"] = 1567214354,
					["Quest"] = 190,
					["Level"] = 32,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [819]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567217767,
					["Quest"] = 185,
					["Level"] = 32,
				}, -- [820]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567217768,
					["Quest"] = 186,
					["Level"] = 32,
				}, -- [821]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567218863,
					["Quest"] = 200,
					["Level"] = 32,
				}, -- [822]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567218864,
					["Quest"] = 328,
					["Level"] = 32,
				}, -- [823]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567221103,
					["Quest"] = 203,
					["Level"] = 32,
				}, -- [824]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567221110,
					["Quest"] = 204,
					["Level"] = 32,
				}, -- [825]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567221110,
					["Quest"] = 574,
					["Level"] = 32,
				}, -- [826]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567221176,
					["Quest"] = 207,
					["Level"] = 32,
				}, -- [827]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567221426,
					["Quest"] = 190,
					["Level"] = 32,
				}, -- [828]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567221427,
					["Quest"] = 191,
					["Level"] = 32,
				}, -- [829]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567222434,
					["Quest"] = 191,
					["Level"] = 32,
				}, -- [830]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567222435,
					["Quest"] = 192,
					["Level"] = 32,
				}, -- [831]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567222436,
					["Quest"] = 186,
					["Level"] = 32,
				}, -- [832]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567222437,
					["Quest"] = 187,
					["Level"] = 32,
				}, -- [833]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567222438,
					["Quest"] = 194,
					["Level"] = 32,
				}, -- [834]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567222438,
					["Quest"] = 195,
					["Level"] = 32,
				}, -- [835]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567223182,
					["Quest"] = 187,
					["Level"] = 32,
				}, -- [836]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 32,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567223183,
					["Quest"] = 188,
					["Level"] = 32,
				}, -- [837]
				{
					["Timestamp"] = 1567224634,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 33,
				}, -- [838]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567227317,
					["Quest"] = 195,
					["Level"] = 33,
				}, -- [839]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567227318,
					["Quest"] = 196,
					["Level"] = 33,
				}, -- [840]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567227320,
					["Quest"] = 188,
					["Level"] = 33,
				}, -- [841]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567227510,
					["Quest"] = 637,
					["Level"] = 33,
				}, -- [842]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567227511,
					["Quest"] = 683,
					["Level"] = 33,
				}, -- [843]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567227642,
					["Quest"] = 683,
					["Level"] = 33,
				}, -- [844]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567227642,
					["Quest"] = 686,
					["Level"] = 33,
				}, -- [845]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567227989,
					["Quest"] = 328,
					["Level"] = 33,
				}, -- [846]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273252,
					["Quest"] = 686,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [847]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273253,
					["Quest"] = 689,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [848]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273519,
					["Quest"] = 196,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [849]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273536,
					["Quest"] = 574,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [850]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273539,
					["Quest"] = 192,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [851]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273549,
					["Quest"] = 207,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [852]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273771,
					["Quest"] = 563,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [853]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273838,
					["Quest"] = 2928,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [854]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273849,
					["Quest"] = 322,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [855]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567273850,
					["Quest"] = 325,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [856]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567274084,
					["Quest"] = 540,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [857]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567274248,
					["Quest"] = 325,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [858]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567274249,
					["Quest"] = 55,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [859]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567274563,
					["Quest"] = 55,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [860]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567275059,
					["Quest"] = 2930,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [861]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567275062,
					["Quest"] = 2929,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [862]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567275066,
					["Quest"] = 2924,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [863]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567275094,
					["Quest"] = 2922,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [864]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["Timestamp"] = 1567275360,
					["Quest"] = 2926,
					["Level"] = 33,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [865]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567280395,
					["Quest"] = 2926,
					["Level"] = 33,
				}, -- [866]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 33,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567280396,
					["Quest"] = 2962,
					["Level"] = 33,
				}, -- [867]
				{
					["Timestamp"] = 1567286895,
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["Event"] = "Level",
					["NewLevel"] = 34,
				}, -- [868]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567286965,
					["Quest"] = 4601,
					["Level"] = 34,
				}, -- [869]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567286971,
					["Quest"] = 4601,
					["Level"] = 34,
				}, -- [870]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567286972,
					["Quest"] = 4605,
					["Level"] = 34,
				}, -- [871]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567287034,
					["Quest"] = 2945,
					["Level"] = 34,
				}, -- [872]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567287052,
					["Quest"] = 2945,
					["Level"] = 34,
				}, -- [873]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567287053,
					["Quest"] = 2947,
					["Level"] = 34,
				}, -- [874]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567287068,
					["Quest"] = 2953,
					["Level"] = 34,
				}, -- [875]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567287084,
					["Quest"] = 2953,
					["Level"] = 34,
				}, -- [876]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [3]
						{
							["Class"] = "Hunter",
							["Name"] = "Cold",
							["Level"] = 36,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567287098,
					["Quest"] = 2953,
					["Level"] = 34,
				}, -- [877]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289122,
					["Quest"] = 2924,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [878]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289125,
					["Quest"] = 2930,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [879]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289128,
					["Quest"] = 2922,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [880]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289164,
					["Quest"] = 2929,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [881]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289348,
					["Quest"] = 2947,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [882]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289348,
					["Quest"] = 2948,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [883]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289536,
					["Quest"] = 2948,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [884]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567289710,
					["Quest"] = 2962,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [885]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567290558,
					["Quest"] = 2928,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [886]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567291134,
					["Quest"] = 564,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [887]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567291183,
					["Quest"] = 500,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [888]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567291236,
					["Quest"] = 505,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [889]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Omernes",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Omernes",
							["Level"] = 31,
						}, -- [2]
					},
					["Timestamp"] = 1567292512,
					["Quest"] = 510,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [890]
				{
					["Party"] = {
						{
							["Class"] = "Druid",
							["Name"] = "Omernes",
							["Level"] = 31,
						}, -- [1]
						{
							["Class"] = "Druid",
							["Name"] = "Omernes",
							["Level"] = 31,
						}, -- [2]
					},
					["Timestamp"] = 1567292513,
					["Quest"] = 511,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [891]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295316,
					["Quest"] = 500,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [892]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295317,
					["Quest"] = 504,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [893]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295326,
					["Quest"] = 511,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [894]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295326,
					["Quest"] = 514,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [895]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295353,
					["Quest"] = 505,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [896]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295354,
					["Quest"] = 510,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [897]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295355,
					["Quest"] = 512,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [898]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295391,
					["Quest"] = 564,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [899]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295715,
					["Quest"] = 512,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [900]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295720,
					["Quest"] = 504,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [901]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295857,
					["Quest"] = 555,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [902]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567295929,
					["Quest"] = 555,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [903]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296298,
					["Quest"] = 1453,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [904]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296309,
					["Quest"] = 514,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [905]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296310,
					["Quest"] = 525,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [906]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296447,
					["Quest"] = 689,
					["Level"] = 34,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [907]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296448,
					["Event"] = "Level",
					["NewLevel"] = 35,
				}, -- [908]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 34,
						}, -- [1]
					},
					["Timestamp"] = 1567296516,
					["Quest"] = 700,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [909]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567296819,
					["Quest"] = 700,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [910]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 35,
					["Quest"] = 1453,
					["Timestamp"] = 1567298978,
				}, -- [911]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 35,
					["Quest"] = 1454,
					["Timestamp"] = 1567298978,
				}, -- [912]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347248,
					["Quest"] = 1437,
					["Level"] = 35,
				}, -- [913]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347253,
					["Quest"] = 1382,
					["Level"] = 35,
				}, -- [914]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347256,
					["Quest"] = 1387,
					["Level"] = 35,
				}, -- [915]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347257,
					["Quest"] = 1385,
					["Level"] = 35,
				}, -- [916]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347264,
					["Quest"] = 1458,
					["Level"] = 35,
				}, -- [917]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567347300,
					["Quest"] = 261,
					["Level"] = 35,
				}, -- [918]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567348178,
					["Quest"] = 1458,
					["Level"] = 35,
				}, -- [919]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567348179,
					["Quest"] = 1459,
					["Level"] = 35,
				}, -- [920]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567348389,
					["Quest"] = 5501,
					["Level"] = 35,
				}, -- [921]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567349546,
					["Quest"] = 1385,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [922]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567350162,
					["Quest"] = 5561,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [923]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567351889,
					["Quest"] = 5561,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [924]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567352324,
					["Quest"] = 5741,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [925]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567352368,
					["Quest"] = 1454,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [926]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567352369,
					["Quest"] = 1455,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [927]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567352949,
					["Quest"] = 1437,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [928]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567352950,
					["Quest"] = 1465,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [929]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567353109,
					["Quest"] = 5501,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [930]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567354180,
					["Quest"] = 1465,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [931]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567354181,
					["Quest"] = 1438,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [932]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567354189,
					["Quest"] = 1387,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [933]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567354257,
					["Quest"] = 1455,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [934]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Timestamp"] = 1567354258,
					["Quest"] = 1456,
					["Level"] = 35,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [935]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 35,
					["Quest"] = 1459,
					["Timestamp"] = 1567359554,
				}, -- [936]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 35,
					["Quest"] = 1466,
					["Timestamp"] = 1567359555,
				}, -- [937]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 35,
					["Quest"] = 1438,
					["Timestamp"] = 1567359979,
				}, -- [938]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 35,
					["Quest"] = 1439,
					["Timestamp"] = 1567359980,
				}, -- [939]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 35,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 35,
					["Quest"] = 1439,
					["Timestamp"] = 1567360203,
				}, -- [940]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 35,
					["Quest"] = 1440,
					["Timestamp"] = 1567360218,
				}, -- [941]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 35,
					["Quest"] = 5741,
					["Timestamp"] = 1567360525,
				}, -- [942]
				{
					["Timestamp"] = 1567360525,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 36,
				}, -- [943]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 6027,
					["Timestamp"] = 1567360526,
				}, -- [944]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 6161,
					["Timestamp"] = 1567360670,
				}, -- [945]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 6161,
					["Timestamp"] = 1567361413,
				}, -- [946]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 6027,
					["Timestamp"] = 1567361989,
				}, -- [947]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 5943,
					["Timestamp"] = 1567363238,
				}, -- [948]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Isotope",
							["Level"] = 33,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 5943,
					["Timestamp"] = 1567363623,
				}, -- [949]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1382,
					["Timestamp"] = 1567363987,
				}, -- [950]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1384,
					["Timestamp"] = 1567363987,
				}, -- [951]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 261,
					["Timestamp"] = 1567367937,
				}, -- [952]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1052,
					["Timestamp"] = 1567367938,
				}, -- [953]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1456,
					["Timestamp"] = 1567368017,
				}, -- [954]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1457,
					["Timestamp"] = 1567368018,
				}, -- [955]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1466,
					["Timestamp"] = 1567368021,
				}, -- [956]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1467,
					["Timestamp"] = 1567368021,
				}, -- [957]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1385,
					["Timestamp"] = 1567368030,
				}, -- [958]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 36,
					["Quest"] = 1385,
					["Timestamp"] = 1567368035,
				}, -- [959]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1440,
					["Timestamp"] = 1567368047,
				}, -- [960]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 36,
					["Quest"] = 1384,
					["Timestamp"] = 1567368104,
				}, -- [961]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1286,
					["Timestamp"] = 1567368505,
				}, -- [962]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1204,
					["Timestamp"] = 1567368568,
				}, -- [963]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1218,
					["Timestamp"] = 1567368792,
				}, -- [964]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1218,
					["Timestamp"] = 1567368793,
				}, -- [965]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1206,
					["Timestamp"] = 1567368794,
				}, -- [966]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1219,
					["Timestamp"] = 1567368799,
				}, -- [967]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1324,
					["Timestamp"] = 1567368903,
				}, -- [968]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1324,
					["Timestamp"] = 1567368940,
				}, -- [969]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1267,
					["Timestamp"] = 1567368942,
				}, -- [970]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1219,
					["Timestamp"] = 1567369195,
				}, -- [971]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1220,
					["Timestamp"] = 1567369195,
				}, -- [972]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1220,
					["Timestamp"] = 1567369313,
				}, -- [973]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1177,
					["Timestamp"] = 1567370812,
				}, -- [974]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Critters",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Critters",
							["Level"] = 35,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1222,
					["Timestamp"] = 1567371398,
				}, -- [975]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 36,
					["Quest"] = 1206,
					["Timestamp"] = 1567371691,
				}, -- [976]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 36,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 36,
					["Quest"] = 1203,
					["Timestamp"] = 1567371692,
				}, -- [977]
				{
					["Timestamp"] = 1567372332,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 37,
				}, -- [978]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1177,
					["Timestamp"] = 1567375400,
				}, -- [979]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1286,
					["Timestamp"] = 1567375522,
				}, -- [980]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 1287,
					["Timestamp"] = 1567375523,
				}, -- [981]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1204,
					["Timestamp"] = 1567375615,
				}, -- [982]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 1258,
					["Timestamp"] = 1567375616,
				}, -- [983]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1222,
					["Timestamp"] = 1567375619,
				}, -- [984]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1287,
					["Timestamp"] = 1567375672,
				}, -- [985]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1112,
					["Timestamp"] = 1567376049,
				}, -- [986]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 1114,
					["Timestamp"] = 1567376065,
				}, -- [987]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1114,
					["Timestamp"] = 1567376077,
				}, -- [988]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 1115,
					["Timestamp"] = 1567376091,
				}, -- [989]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 621,
					["Timestamp"] = 1567376954,
				}, -- [990]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 201,
					["Timestamp"] = 1567376967,
				}, -- [991]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 210,
					["Timestamp"] = 1567376968,
				}, -- [992]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 627,
					["Timestamp"] = 1567376969,
				}, -- [993]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 189,
					["Timestamp"] = 1567376971,
				}, -- [994]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 209,
					["Timestamp"] = 1567376972,
				}, -- [995]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 1115,
					["Timestamp"] = 1567376974,
				}, -- [996]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 1116,
					["Timestamp"] = 1567376974,
				}, -- [997]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 213,
					["Timestamp"] = 1567376978,
				}, -- [998]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 578,
					["Timestamp"] = 1567376987,
				}, -- [999]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 601,
					["Timestamp"] = 1567376988,
				}, -- [1000]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 575,
					["Timestamp"] = 1567377026,
				}, -- [1001]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 577,
					["Timestamp"] = 1567377027,
				}, -- [1002]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 605,
					["Timestamp"] = 1567379393,
				}, -- [1003]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 600,
					["Timestamp"] = 1567379394,
				}, -- [1004]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 574,
					["Timestamp"] = 1567379999,
				}, -- [1005]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 207,
					["Timestamp"] = 1567380008,
				}, -- [1006]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 192,
					["Timestamp"] = 1567380091,
				}, -- [1007]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 37,
					["Quest"] = 1258,
					["Timestamp"] = 1567380126,
				}, -- [1008]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 37,
					["Quest"] = 1203,
					["Timestamp"] = 1567380129,
				}, -- [1009]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 196,
					["Timestamp"] = 1567380130,
				}, -- [1010]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 328,
					["Timestamp"] = 1567380360,
				}, -- [1011]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 328,
					["Timestamp"] = 1567380636,
				}, -- [1012]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 329,
					["Timestamp"] = 1567380636,
				}, -- [1013]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 192,
					["Timestamp"] = 1567383340,
				}, -- [1014]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 193,
					["Timestamp"] = 1567383341,
				}, -- [1015]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 329,
					["Timestamp"] = 1567383464,
				}, -- [1016]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 330,
					["Timestamp"] = 1567383465,
				}, -- [1017]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 574,
					["Timestamp"] = 1567383467,
				}, -- [1018]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 202,
					["Timestamp"] = 1567383468,
				}, -- [1019]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 330,
					["Timestamp"] = 1567383488,
				}, -- [1020]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 37,
					["Quest"] = 331,
					["Timestamp"] = 1567383488,
				}, -- [1021]
				{
					["Timestamp"] = 1567383501,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 38,
				}, -- [1022]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 37,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 37,
					["Quest"] = 331,
					["Timestamp"] = 1567383501,
				}, -- [1023]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 213,
					["Timestamp"] = 1567386296,
				}, -- [1024]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 601,
					["Timestamp"] = 1567386302,
				}, -- [1025]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 38,
					["Quest"] = 602,
					["Timestamp"] = 1567386302,
				}, -- [1026]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 1182,
					["Timestamp"] = 1567386305,
				}, -- [1027]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 38,
					["Quest"] = 1183,
					["Timestamp"] = 1567386306,
				}, -- [1028]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 577,
					["Timestamp"] = 1567386432,
				}, -- [1029]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 38,
					["Quest"] = 628,
					["Timestamp"] = 1567386432,
				}, -- [1030]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 1457,
					["Timestamp"] = 1567387066,
				}, -- [1031]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 38,
					["Quest"] = 1467,
					["Timestamp"] = 1567387077,
				}, -- [1032]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 38,
					["Quest"] = 707,
					["Timestamp"] = 1567387090,
				}, -- [1033]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 38,
					["Quest"] = 1050,
					["Timestamp"] = 1567387116,
				}, -- [1034]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 1052,
					["Timestamp"] = 1567435609,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1035]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 1053,
					["Timestamp"] = 1567435609,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1036]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 525,
					["Timestamp"] = 1567435641,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1037]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 537,
					["Timestamp"] = 1567435642,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1038]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 512,
					["Timestamp"] = 1567435651,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1039]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Demandread",
							["Level"] = 35,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 659,
					["Timestamp"] = 1567435691,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1040]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Frosty",
							["Level"] = 38,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Frosty",
							["Level"] = 38,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Frosty",
							["Level"] = 38,
						}, -- [3]
					},
					["Level"] = 38,
					["Quest"] = 1053,
					["Timestamp"] = 1567443711,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1041]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Level"] = 38,
					["Quest"] = 602,
					["Timestamp"] = 1567444063,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1042]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 38,
						}, -- [1]
					},
					["Level"] = 38,
					["Quest"] = 603,
					["Timestamp"] = 1567444064,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1043]
				{
					["Timestamp"] = 1567444957,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 39,
				}, -- [1044]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567445258,
					["Quest"] = 551,
					["Level"] = 39,
				}, -- [1045]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567445626,
					["Quest"] = 551,
					["Level"] = 39,
				}, -- [1046]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567445627,
					["Quest"] = 554,
					["Level"] = 39,
				}, -- [1047]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567445646,
					["Quest"] = 537,
					["Level"] = 39,
				}, -- [1048]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567445647,
					["Quest"] = 512,
					["Level"] = 39,
				}, -- [1049]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567445669,
					["Quest"] = 504,
					["Level"] = 39,
				}, -- [1050]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567445684,
					["Quest"] = 540,
					["Level"] = 39,
				}, -- [1051]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567447728,
					["Quest"] = 540,
					["Level"] = 39,
				}, -- [1052]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567447729,
					["Quest"] = 542,
					["Level"] = 39,
				}, -- [1053]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567447742,
					["Quest"] = 504,
					["Level"] = 39,
				}, -- [1054]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567450115,
					["Quest"] = 1116,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1055]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567450151,
					["Quest"] = 691,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1056]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567450285,
					["Quest"] = 642,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1057]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567450637,
					["Quest"] = 627,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1058]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567451885,
					["Quest"] = 642,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1059]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567451885,
					["Quest"] = 651,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1060]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567452921,
					["Quest"] = 659,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1061]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567452922,
					["Quest"] = 658,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1062]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567454802,
					["Quest"] = 651,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1063]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567454802,
					["Quest"] = 652,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1064]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567455127,
					["Quest"] = 691,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1065]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567455159,
					["Quest"] = 693,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1066]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Timestamp"] = 1567455173,
					["Quest"] = 684,
					["Level"] = 39,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1067]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 658,
					["Timestamp"] = 1567459280,
				}, -- [1068]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 657,
					["Timestamp"] = 1567459280,
				}, -- [1069]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 657,
					["Timestamp"] = 1567459706,
				}, -- [1070]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 660,
					["Timestamp"] = 1567459713,
				}, -- [1071]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 660,
					["Timestamp"] = 1567459963,
				}, -- [1072]
				{
					["Party"] = {
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [1]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [2]
						{
							["Class"] = "Hunter",
							["Name"] = "Swankypants",
							["Level"] = 36,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 661,
					["Timestamp"] = 1567459963,
				}, -- [1073]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 693,
					["Timestamp"] = 1567460523,
				}, -- [1074]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 694,
					["Timestamp"] = 1567460524,
				}, -- [1075]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 652,
					["Timestamp"] = 1567460963,
				}, -- [1076]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 653,
					["Timestamp"] = 1567460963,
				}, -- [1077]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 39,
					["Quest"] = 694,
					["Timestamp"] = 1567461235,
				}, -- [1078]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 39,
					["Quest"] = 684,
					["Timestamp"] = 1567461237,
				}, -- [1079]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 39,
					["Quest"] = 193,
					["Timestamp"] = 1567461310,
				}, -- [1080]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 663,
					["Timestamp"] = 1567461312,
				}, -- [1081]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 663,
					["Timestamp"] = 1567461320,
				}, -- [1082]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 662,
					["Timestamp"] = 1567461323,
				}, -- [1083]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 664,
					["Timestamp"] = 1567461332,
				}, -- [1084]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 665,
					["Timestamp"] = 1567461354,
				}, -- [1085]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 665,
					["Timestamp"] = 1567461471,
				}, -- [1086]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 666,
					["Timestamp"] = 1567461472,
				}, -- [1087]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 664,
					["Timestamp"] = 1567462891,
				}, -- [1088]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 666,
					["Timestamp"] = 1567462898,
				}, -- [1089]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 39,
					["Quest"] = 668,
					["Timestamp"] = 1567462898,
				}, -- [1090]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 39,
					["Quest"] = 662,
					["Timestamp"] = 1567462919,
				}, -- [1091]
				{
					["Timestamp"] = 1567462919,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 39,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 40,
				}, -- [1092]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 40,
					["Quest"] = 668,
					["Timestamp"] = 1567462942,
				}, -- [1093]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 40,
					["Quest"] = 669,
					["Timestamp"] = 1567462943,
				}, -- [1094]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 40,
					["Quest"] = 661,
					["Timestamp"] = 1567462992,
				}, -- [1095]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 40,
					["Quest"] = 554,
					["Timestamp"] = 1567463468,
				}, -- [1096]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 40,
					["Quest"] = 2398,
					["Timestamp"] = 1567463468,
				}, -- [1097]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 40,
					["Quest"] = 1050,
					["Timestamp"] = 1567463471,
				}, -- [1098]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 40,
					["Quest"] = 2398,
					["Timestamp"] = 1567463482,
				}, -- [1099]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 603,
					["Timestamp"] = 1567465207,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1100]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 610,
					["Timestamp"] = 1567465208,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1101]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 669,
					["Timestamp"] = 1567465217,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1102]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 670,
					["Timestamp"] = 1567465218,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1103]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 670,
					["Timestamp"] = 1567465307,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1104]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 193,
					["Timestamp"] = 1567466592,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1105]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 209,
					["Timestamp"] = 1567471727,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1106]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 670,
					["Timestamp"] = 1567471729,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1107]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 670,
					["Timestamp"] = 1567471737,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1108]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 600,
					["Timestamp"] = 1567471753,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1109]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 196,
					["Timestamp"] = 1567473793,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1110]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 197,
					["Timestamp"] = 1567473794,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1111]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 193,
					["Timestamp"] = 1567473796,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1112]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 338,
					["Timestamp"] = 1567473808,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1113]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 339,
					["Timestamp"] = 1567473817,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1114]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 339,
					["Timestamp"] = 1567473821,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1115]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 340,
					["Timestamp"] = 1567473821,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1116]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 341,
					["Timestamp"] = 1567473822,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1117]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 340,
					["Timestamp"] = 1567473823,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1118]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 341,
					["Timestamp"] = 1567473824,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1119]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 342,
					["Timestamp"] = 1567473825,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1120]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 628,
					["Timestamp"] = 1567475048,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1121]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 1107,
					["Timestamp"] = 1567475722,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1122]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 1183,
					["Timestamp"] = 1567476096,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1123]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 1186,
					["Timestamp"] = 1567476097,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1124]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 1186,
					["Timestamp"] = 1567476100,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1125]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 1187,
					["Timestamp"] = 1567476101,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1126]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 653,
					["Timestamp"] = 1567476232,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1127]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 687,
					["Timestamp"] = 1567476237,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1128]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 542,
					["Timestamp"] = 1567476607,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1129]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 40,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 207,
					["Timestamp"] = 1567477492,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1130]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 205,
					["Timestamp"] = 1567477493,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1131]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Timestamp"] = 1567477497,
					["Event"] = "Level",
					["NewLevel"] = 41,
				}, -- [1132]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 40,
					["Quest"] = 202,
					["Timestamp"] = 1567477497,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1133]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 197,
					["Timestamp"] = 1567477561,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1134]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 208,
					["Timestamp"] = 1567477562,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1135]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 342,
					["Timestamp"] = 1567477569,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1136]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 338,
					["Timestamp"] = 1567477584,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1137]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 1395,
					["Timestamp"] = 1567477862,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1138]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 1395,
					["Timestamp"] = 1567478134,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1139]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2500,
					["Timestamp"] = 1567478676,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1140]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 707,
					["Timestamp"] = 1567478815,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1141]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 738,
					["Timestamp"] = 1567478816,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1142]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 706,
					["Timestamp"] = 1567479173,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1143]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 718,
					["Timestamp"] = 1567479175,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1144]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 719,
					["Timestamp"] = 1567479178,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1145]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 720,
					["Timestamp"] = 1567479227,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1146]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 719,
					["Timestamp"] = 1567479686,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1147]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 720,
					["Timestamp"] = 1567479686,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1148]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 721,
					["Timestamp"] = 1567479687,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1149]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 718,
					["Timestamp"] = 1567479694,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1150]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 733,
					["Timestamp"] = 1567479696,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1151]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 721,
					["Timestamp"] = 1567480369,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1152]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 722,
					["Timestamp"] = 1567480370,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1153]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 722,
					["Timestamp"] = 1567480878,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1154]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 723,
					["Timestamp"] = 1567480879,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1155]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 706,
					["Timestamp"] = 1567481073,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1156]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2198,
					["Timestamp"] = 1567482692,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1157]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 1106,
					["Timestamp"] = 1567482804,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1158]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 1108,
					["Timestamp"] = 1567482805,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1159]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2418,
					["Timestamp"] = 1567482807,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1160]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 705,
					["Timestamp"] = 1567482808,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1161]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 703,
					["Timestamp"] = 1567482815,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1162]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 710,
					["Timestamp"] = 1567482868,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1163]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 713,
					["Timestamp"] = 1567482870,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1164]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2198,
					["Timestamp"] = 1567483020,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1165]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2199,
					["Timestamp"] = 1567483021,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1166]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2199,
					["Timestamp"] = 1567483152,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1167]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Level"] = 41,
					["Quest"] = 2200,
					["Timestamp"] = 1567483153,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1168]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 713,
					["Timestamp"] = 1567523969,
				}, -- [1169]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 714,
					["Timestamp"] = 1567523970,
				}, -- [1170]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 714,
					["Timestamp"] = 1567523972,
				}, -- [1171]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 715,
					["Timestamp"] = 1567523976,
				}, -- [1172]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 715,
					["Timestamp"] = 1567523978,
				}, -- [1173]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 710,
					["Timestamp"] = 1567526486,
				}, -- [1174]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 711,
					["Timestamp"] = 1567526487,
				}, -- [1175]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 711,
					["Timestamp"] = 1567526607,
				}, -- [1176]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 712,
					["Timestamp"] = 1567526608,
				}, -- [1177]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 703,
					["Timestamp"] = 1567526662,
				}, -- [1178]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 687,
					["Timestamp"] = 1567526868,
				}, -- [1179]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 692,
					["Timestamp"] = 1567526869,
				}, -- [1180]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 709,
					["Timestamp"] = 1567526880,
				}, -- [1181]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 738,
					["Timestamp"] = 1567526919,
				}, -- [1182]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 739,
					["Timestamp"] = 1567526920,
				}, -- [1183]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 41,
					["Quest"] = 1108,
					["Timestamp"] = 1567528359,
				}, -- [1184]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 1137,
					["Timestamp"] = 1567528408,
				}, -- [1185]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 41,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 41,
					["Quest"] = 732,
					["Timestamp"] = 1567528478,
				}, -- [1186]
				{
					["Timestamp"] = 1567528811,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 42,
				}, -- [1187]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 712,
					["Timestamp"] = 1567530489,
				}, -- [1188]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 734,
					["Timestamp"] = 1567530489,
				}, -- [1189]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 734,
					["Timestamp"] = 1567530491,
				}, -- [1190]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 777,
					["Timestamp"] = 1567530492,
				}, -- [1191]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 716,
					["Timestamp"] = 1567530494,
				}, -- [1192]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 716,
					["Timestamp"] = 1567530495,
				}, -- [1193]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 777,
					["Timestamp"] = 1567530498,
				}, -- [1194]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 778,
					["Timestamp"] = 1567530499,
				}, -- [1195]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 778,
					["Timestamp"] = 1567530726,
				}, -- [1196]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 723,
					["Timestamp"] = 1567530851,
				}, -- [1197]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 724,
					["Timestamp"] = 1567530852,
				}, -- [1198]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 733,
					["Timestamp"] = 1567530867,
				}, -- [1199]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 706,
					["Timestamp"] = 1567530867,
				}, -- [1200]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 706,
					["Timestamp"] = 1567530904,
				}, -- [1201]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 732,
					["Timestamp"] = 1567530905,
				}, -- [1202]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 717,
					["Timestamp"] = 1567530906,
				}, -- [1203]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 717,
					["Timestamp"] = 1567530946,
				}, -- [1204]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 2398,
					["Timestamp"] = 1567531079,
				}, -- [1205]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 724,
					["Timestamp"] = 1567531084,
				}, -- [1206]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 725,
					["Timestamp"] = 1567531085,
				}, -- [1207]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 725,
					["Timestamp"] = 1567531090,
				}, -- [1208]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 726,
					["Timestamp"] = 1567531091,
				}, -- [1209]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 726,
					["Timestamp"] = 1567531121,
				}, -- [1210]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 762,
					["Timestamp"] = 1567531122,
				}, -- [1211]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 1360,
					["Timestamp"] = 1567531132,
				}, -- [1212]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 2500,
					["Timestamp"] = 1567531401,
				}, -- [1213]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 17,
					["Timestamp"] = 1567531402,
				}, -- [1214]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 739,
					["Timestamp"] = 1567531523,
				}, -- [1215]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 704,
					["Timestamp"] = 1567531523,
				}, -- [1216]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 692,
					["Timestamp"] = 1567531948,
				}, -- [1217]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 656,
					["Timestamp"] = 1567531949,
				}, -- [1218]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 762,
					["Timestamp"] = 1567532737,
				}, -- [1219]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 1139,
					["Timestamp"] = 1567532737,
				}, -- [1220]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 670,
					["Timestamp"] = 1567533261,
				}, -- [1221]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 617,
					["Timestamp"] = 1567533280,
				}, -- [1222]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 580,
					["Timestamp"] = 1567533298,
				}, -- [1223]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 606,
					["Timestamp"] = 1567533451,
				}, -- [1224]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 1139,
					["Timestamp"] = 1567533483,
				}, -- [1225]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 17,
					["Timestamp"] = 1567533489,
				}, -- [1226]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 2872,
					["Timestamp"] = 1567533496,
				}, -- [1227]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 8551,
					["Timestamp"] = 1567533534,
				}, -- [1228]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 8551,
					["Timestamp"] = 1567533545,
				}, -- [1229]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 595,
					["Timestamp"] = 1567533584,
				}, -- [1230]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 595,
					["Timestamp"] = 1567533688,
				}, -- [1231]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 597,
					["Timestamp"] = 1567533688,
				}, -- [1232]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 597,
					["Timestamp"] = 1567534018,
				}, -- [1233]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 599,
					["Timestamp"] = 1567534019,
				}, -- [1234]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 610,
					["Timestamp"] = 1567534038,
				}, -- [1235]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 611,
					["Timestamp"] = 1567534039,
				}, -- [1236]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 599,
					["Timestamp"] = 1567534045,
				}, -- [1237]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 604,
					["Timestamp"] = 1567534046,
				}, -- [1238]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 580,
					["Timestamp"] = 1567534063,
				}, -- [1239]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 587,
					["Timestamp"] = 1567534063,
				}, -- [1240]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 42,
					["Quest"] = 2872,
					["Timestamp"] = 1567534103,
				}, -- [1241]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 42,
					["Quest"] = 576,
					["Timestamp"] = 1567534106,
				}, -- [1242]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 208,
					["Timestamp"] = 1567536416,
				}, -- [1243]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 42,
					["Quest"] = 611,
					["Timestamp"] = 1567536471,
				}, -- [1244]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Level"] = 42,
					["Quest"] = 606,
					["Timestamp"] = 1567543296,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1245]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Level"] = 42,
					["Quest"] = 607,
					["Timestamp"] = 1567543297,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1246]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Level"] = 42,
					["Quest"] = 607,
					["Timestamp"] = 1567543345,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1247]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 42,
						}, -- [1]
					},
					["Level"] = 42,
					["Quest"] = 609,
					["Timestamp"] = 1567543346,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1248]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Superwaffles",
							["Level"] = 43,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Superwaffles",
							["Level"] = 43,
						}, -- [2]
					},
					["Timestamp"] = 1567548365,
					["Event"] = "Level",
					["NewLevel"] = 43,
				}, -- [1249]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 621,
					["Timestamp"] = 1567549477,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1250]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 604,
					["Timestamp"] = 1567549499,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1251]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 608,
					["Timestamp"] = 1567549500,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1252]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 609,
					["Timestamp"] = 1567549508,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1253]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 613,
					["Timestamp"] = 1567549522,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1254]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 617,
					["Timestamp"] = 1567549534,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1255]
				{
					["Party"] = {
					},
					["Level"] = 43,
					["Quest"] = 623,
					["Timestamp"] = 1567549535,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1256]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567610621,
					["Quest"] = 17,
					["Level"] = 43,
				}, -- [1257]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567610625,
					["Quest"] = 1139,
					["Level"] = 43,
				}, -- [1258]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567613037,
					["Quest"] = 2200,
					["Level"] = 43,
				}, -- [1259]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567613038,
					["Quest"] = 2201,
					["Level"] = 43,
				}, -- [1260]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567613332,
					["Quest"] = 705,
					["Level"] = 43,
				}, -- [1261]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567615825,
					["Quest"] = 2398,
					["Level"] = 43,
				}, -- [1262]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 41,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567615826,
					["Quest"] = 2240,
					["Level"] = 43,
				}, -- [1263]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567620990,
					["Quest"] = 2278,
					["Level"] = 43,
				}, -- [1264]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567621048,
					["Quest"] = 2278,
					["Level"] = 43,
				}, -- [1265]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Premier",
							["Level"] = 42,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567621049,
					["Quest"] = 2279,
					["Level"] = 43,
				}, -- [1266]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622143,
					["Quest"] = 709,
					["Level"] = 43,
				}, -- [1267]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567622143,
					["Quest"] = 727,
					["Level"] = 43,
				}, -- [1268]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567622177,
					["Quest"] = 2418,
					["Level"] = 43,
				}, -- [1269]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622501,
					["Quest"] = 704,
					["Level"] = 43,
				}, -- [1270]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622625,
					["Quest"] = 17,
					["Level"] = 43,
				}, -- [1271]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622802,
					["Quest"] = 2279,
					["Level"] = 43,
				}, -- [1272]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567622803,
					["Quest"] = 2439,
					["Level"] = 43,
				}, -- [1273]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 43,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622813,
					["Quest"] = 2240,
					["Level"] = 43,
				}, -- [1274]
				{
					["Timestamp"] = 1567622818,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 44,
				}, -- [1275]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622818,
					["Quest"] = 1139,
					["Level"] = 43,
				}, -- [1276]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622823,
					["Quest"] = 1360,
					["Level"] = 44,
				}, -- [1277]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622859,
					["Quest"] = 727,
					["Level"] = 44,
				}, -- [1278]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567622860,
					["Quest"] = 735,
					["Level"] = 44,
				}, -- [1279]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622900,
					["Quest"] = 2201,
					["Level"] = 44,
				}, -- [1280]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567622901,
					["Quest"] = 2204,
					["Level"] = 44,
				}, -- [1281]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567622914,
					["Quest"] = 2204,
					["Level"] = 44,
				}, -- [1282]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567622963,
					["Quest"] = 2439,
					["Level"] = 44,
				}, -- [1283]
				{
					["Party"] = {
					},
					["Timestamp"] = 1567626330,
					["Quest"] = 580,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1284]
				{
					["Party"] = {
					},
					["Timestamp"] = 1567626390,
					["Quest"] = 348,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1285]
				{
					["Party"] = {
					},
					["Timestamp"] = 1567626398,
					["Quest"] = 2872,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1286]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567626589,
					["Quest"] = 8551,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1287]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567626836,
					["Quest"] = 735,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1288]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567629390,
					["Quest"] = 205,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1289]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567629390,
					["Quest"] = 206,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1290]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567630398,
					["Quest"] = 206,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1291]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567630471,
					["Quest"] = 613,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1292]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567630514,
					["Quest"] = 576,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1293]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632674,
					["Quest"] = 624,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1294]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632680,
					["Quest"] = 8551,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1295]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632716,
					["Quest"] = 348,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1296]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632740,
					["Quest"] = 587,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1297]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632744,
					["Quest"] = 2864,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1298]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567632752,
					["Quest"] = 608,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1299]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567633481,
					["Quest"] = 694,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1300]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567633486,
					["Quest"] = 684,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1301]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567633489,
					["Quest"] = 685,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1302]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634607,
					["Quest"] = 684,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1303]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634611,
					["Quest"] = 685,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1304]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634612,
					["Quest"] = 681,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1305]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634615,
					["Quest"] = 694,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1306]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634615,
					["Quest"] = 695,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1307]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634618,
					["Quest"] = 695,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1308]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634619,
					["Quest"] = 696,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1309]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634625,
					["Quest"] = 681,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1310]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634672,
					["Quest"] = 696,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1311]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634886,
					["Quest"] = 670,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1312]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567634892,
					["Quest"] = 667,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1313]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567635036,
					["Quest"] = 667,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1314]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567635095,
					["Quest"] = 1116,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1315]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567635541,
					["Quest"] = 624,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1316]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Timestamp"] = 1567635542,
					["Quest"] = 625,
					["Level"] = 44,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1317]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2861,
					["Timestamp"] = 1567638865,
				}, -- [1318]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1363,
					["Timestamp"] = 1567638917,
				}, -- [1319]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 1363,
					["Timestamp"] = 1567638922,
				}, -- [1320]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 1116,
					["Timestamp"] = 1567639080,
				}, -- [1321]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1117,
					["Timestamp"] = 1567639113,
				}, -- [1322]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 623,
					["Timestamp"] = 1567639555,
				}, -- [1323]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 2861,
					["Timestamp"] = 1567639975,
				}, -- [1324]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2846,
					["Timestamp"] = 1567639976,
				}, -- [1325]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 625,
					["Timestamp"] = 1567640156,
				}, -- [1326]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 626,
					["Timestamp"] = 1567640157,
				}, -- [1327]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1707,
					["Timestamp"] = 1567640710,
				}, -- [1328]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1690,
					["Timestamp"] = 1567640716,
				}, -- [1329]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2781,
					["Timestamp"] = 1567640768,
				}, -- [1330]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2875,
					["Timestamp"] = 1567640769,
				}, -- [1331]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 2864,
					["Timestamp"] = 1567640779,
				}, -- [1332]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2865,
					["Timestamp"] = 1567640780,
				}, -- [1333]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 992,
					["Timestamp"] = 1567640791,
				}, -- [1334]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 1117,
					["Timestamp"] = 1567640905,
				}, -- [1335]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1118,
					["Timestamp"] = 1567640905,
				}, -- [1336]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 2770,
					["Timestamp"] = 1567640917,
				}, -- [1337]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 1187,
					["Timestamp"] = 1567640931,
				}, -- [1338]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 44,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 44,
					["Quest"] = 1188,
					["Timestamp"] = 1567640933,
				}, -- [1339]
				{
					["Timestamp"] = 1567640949,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 45,
				}, -- [1340]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 44,
					["Quest"] = 1137,
					["Timestamp"] = 1567640949,
				}, -- [1341]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 45,
					["Quest"] = 1190,
					["Timestamp"] = 1567640963,
				}, -- [1342]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 45,
					["Quest"] = 1191,
					["Timestamp"] = 1567641023,
				}, -- [1343]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 45,
					["Quest"] = 1190,
					["Timestamp"] = 1567641083,
				}, -- [1344]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 45,
					["Quest"] = 1194,
					["Timestamp"] = 1567641083,
				}, -- [1345]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 45,
					["Quest"] = 1194,
					["Timestamp"] = 1567641108,
				}, -- [1346]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1188,
					["Timestamp"] = 1567647638,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1347]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1189,
					["Timestamp"] = 1567647638,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1348]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 8365,
					["Timestamp"] = 1567647905,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1349]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 3520,
					["Timestamp"] = 1567647909,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1350]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 8366,
					["Timestamp"] = 1567647931,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1351]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2872,
					["Timestamp"] = 1567647933,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1352]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2873,
					["Timestamp"] = 1567647933,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1353]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1707,
					["Timestamp"] = 1567648576,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1354]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1690,
					["Timestamp"] = 1567648578,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1355]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1691,
					["Timestamp"] = 1567648579,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1356]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2768,
					["Timestamp"] = 1567648582,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1357]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2781,
					["Timestamp"] = 1567652316,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1358]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 1691,
					["Timestamp"] = 1567652317,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1359]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 8365,
					["Timestamp"] = 1567652444,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1360]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2875,
					["Timestamp"] = 1567652455,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1361]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 8366,
					["Timestamp"] = 1567652461,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1362]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2873,
					["Timestamp"] = 1567652463,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1363]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 2874,
					["Timestamp"] = 1567652464,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1364]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 992,
					["Timestamp"] = 1567652977,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1365]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["Level"] = 45,
					["Quest"] = 82,
					["Timestamp"] = 1567652978,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1366]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696366,
					["Quest"] = 2821,
					["Level"] = 45,
				}, -- [1367]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696394,
					["Quest"] = 2866,
					["Level"] = 45,
				}, -- [1368]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696395,
					["Quest"] = 4124,
					["Level"] = 45,
				}, -- [1369]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696428,
					["Quest"] = 2982,
					["Level"] = 45,
				}, -- [1370]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696429,
					["Quest"] = 2939,
					["Level"] = 45,
				}, -- [1371]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567696441,
					["Quest"] = 4124,
					["Level"] = 45,
				}, -- [1372]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696442,
					["Quest"] = 4125,
					["Level"] = 45,
				}, -- [1373]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567696540,
					["Quest"] = 2866,
					["Level"] = 45,
				}, -- [1374]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696541,
					["Quest"] = 2867,
					["Level"] = 45,
				}, -- [1375]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567696596,
					["Quest"] = 2867,
					["Level"] = 45,
				}, -- [1376]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696597,
					["Quest"] = 3130,
					["Level"] = 45,
				}, -- [1377]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567696602,
					["Quest"] = 3130,
					["Level"] = 45,
				}, -- [1378]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567696603,
					["Quest"] = 2869,
					["Level"] = 45,
				}, -- [1379]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567697596,
					["Quest"] = 2869,
					["Level"] = 45,
				}, -- [1380]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567697597,
					["Quest"] = 2870,
					["Level"] = 45,
				}, -- [1381]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567698758,
					["Quest"] = 2870,
					["Level"] = 45,
				}, -- [1382]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567698759,
					["Quest"] = 2871,
					["Level"] = 45,
				}, -- [1383]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567698779,
					["Quest"] = 2871,
					["Level"] = 45,
				}, -- [1384]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567699369,
					["Quest"] = 4125,
					["Level"] = 45,
				}, -- [1385]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567699370,
					["Quest"] = 4127,
					["Level"] = 45,
				}, -- [1386]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567699490,
					["Quest"] = 4127,
					["Level"] = 45,
				}, -- [1387]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567699491,
					["Quest"] = 4129,
					["Level"] = 45,
				}, -- [1388]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567699537,
					["Quest"] = 4129,
					["Level"] = 45,
				}, -- [1389]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567699553,
					["Quest"] = 4130,
					["Level"] = 45,
				}, -- [1390]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567699585,
					["Quest"] = 4130,
					["Level"] = 45,
				}, -- [1391]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 45,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567699586,
					["Quest"] = 4131,
					["Level"] = 45,
				}, -- [1392]
				{
					["Timestamp"] = 1567702582,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 46,
				}, -- [1393]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567702971,
					["Quest"] = 2969,
					["Level"] = 46,
				}, -- [1394]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567703078,
					["Quest"] = 2969,
					["Level"] = 46,
				}, -- [1395]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567703084,
					["Quest"] = 2970,
					["Level"] = 46,
				}, -- [1396]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567703890,
					["Quest"] = 2970,
					["Level"] = 46,
				}, -- [1397]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567703890,
					["Quest"] = 2972,
					["Level"] = 46,
				}, -- [1398]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704015,
					["Quest"] = 4131,
					["Level"] = 46,
				}, -- [1399]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704016,
					["Quest"] = 4135,
					["Level"] = 46,
				}, -- [1400]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704064,
					["Quest"] = 4281,
					["Level"] = 46,
				}, -- [1401]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704239,
					["Quest"] = 4135,
					["Level"] = 46,
				}, -- [1402]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704240,
					["Quest"] = 4265,
					["Level"] = 46,
				}, -- [1403]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704364,
					["Quest"] = 2821,
					["Level"] = 46,
				}, -- [1404]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704365,
					["Quest"] = 7733,
					["Level"] = 46,
				}, -- [1405]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704411,
					["Quest"] = 2982,
					["Level"] = 46,
				}, -- [1406]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704411,
					["Quest"] = 3445,
					["Level"] = 46,
				}, -- [1407]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704419,
					["Quest"] = 4265,
					["Level"] = 46,
				}, -- [1408]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704419,
					["Quest"] = 4266,
					["Level"] = 46,
				}, -- [1409]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704449,
					["Quest"] = 4266,
					["Level"] = 46,
				}, -- [1410]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Poot",
							["Level"] = 45,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567704450,
					["Quest"] = 4267,
					["Level"] = 46,
				}, -- [1411]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567704660,
					["Quest"] = 4281,
					["Level"] = 46,
				}, -- [1412]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567705439,
					["Quest"] = 3661,
					["Level"] = 46,
				}, -- [1413]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567705449,
					["Quest"] = 2939,
					["Level"] = 46,
				}, -- [1414]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567705465,
					["Quest"] = 2940,
					["Level"] = 46,
				}, -- [1415]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567705471,
					["Quest"] = 2940,
					["Level"] = 46,
				}, -- [1416]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567705472,
					["Quest"] = 2941,
					["Level"] = 46,
				}, -- [1417]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567705570,
					["Quest"] = 2972,
					["Level"] = 46,
				}, -- [1418]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567705581,
					["Quest"] = 4267,
					["Level"] = 46,
				}, -- [1419]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567706152,
					["Quest"] = 82,
					["Level"] = 46,
				}, -- [1420]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567706183,
					["Quest"] = 2768,
					["Level"] = 46,
				}, -- [1421]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567706189,
					["Quest"] = 2865,
					["Level"] = 46,
				}, -- [1422]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567706645,
					["Quest"] = 2988,
					["Level"] = 46,
				}, -- [1423]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567706688,
					["Quest"] = 2877,
					["Level"] = 46,
				}, -- [1424]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567706690,
					["Quest"] = 2880,
					["Level"] = 46,
				}, -- [1425]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567706723,
					["Quest"] = 656,
					["Level"] = 46,
				}, -- [1426]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567707674,
					["Quest"] = 2880,
					["Level"] = 46,
				}, -- [1427]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567707743,
					["Quest"] = 2988,
					["Level"] = 46,
				}, -- [1428]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567707744,
					["Quest"] = 2989,
					["Level"] = 46,
				}, -- [1429]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567710384,
					["Quest"] = 626,
					["Level"] = 46,
				}, -- [1430]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567710768,
					["Quest"] = 2877,
					["Level"] = 46,
				}, -- [1431]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567710824,
					["Quest"] = 2989,
					["Level"] = 46,
				}, -- [1432]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567710825,
					["Quest"] = 2990,
					["Level"] = 46,
				}, -- [1433]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567711017,
					["Quest"] = 485,
					["Level"] = 46,
				}, -- [1434]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567711025,
					["Quest"] = 485,
					["Level"] = 46,
				}, -- [1435]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 4449,
					["Timestamp"] = 1567717322,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1436]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3367,
					["Timestamp"] = 1567717424,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1437]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3367,
					["Timestamp"] = 1567717885,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1438]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3368,
					["Timestamp"] = 1567717885,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1439]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 4449,
					["Timestamp"] = 1567718094,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1440]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 4450,
					["Timestamp"] = 1567718095,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1441]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3181,
					["Timestamp"] = 1567718340,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1442]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3441,
					["Timestamp"] = 1567718681,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1443]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3441,
					["Timestamp"] = 1567718697,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1444]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3442,
					["Timestamp"] = 1567718698,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1445]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7701,
					["Timestamp"] = 1567718754,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1446]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7728,
					["Timestamp"] = 1567718755,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1447]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7729,
					["Timestamp"] = 1567718757,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1448]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7723,
					["Timestamp"] = 1567718793,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1449]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 1189,
					["Timestamp"] = 1567718864,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1450]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3181,
					["Timestamp"] = 1567719064,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1451]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3182,
					["Timestamp"] = 1567719065,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1452]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3182,
					["Timestamp"] = 1567719287,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1453]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3368,
					["Timestamp"] = 1567719288,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1454]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3371,
					["Timestamp"] = 1567719289,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1455]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3201,
					["Timestamp"] = 1567719294,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1456]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 3201,
					["Timestamp"] = 1567719507,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1457]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7724,
					["Timestamp"] = 1567719906,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1458]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7727,
					["Timestamp"] = 1567719907,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1459]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 2846,
					["Timestamp"] = 1567719922,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1460]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 46,
						}, -- [1]
					},
					["Level"] = 46,
					["Quest"] = 7722,
					["Timestamp"] = 1567719926,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1461]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Timestamp"] = 1567720684,
					["Event"] = "Level",
					["NewLevel"] = 47,
				}, -- [1462]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 3442,
					["Timestamp"] = 1567723433,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1463]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 3443,
					["Timestamp"] = 1567723434,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1464]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 3443,
					["Timestamp"] = 1567724776,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1465]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 3452,
					["Timestamp"] = 1567724777,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1466]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 7724,
					["Timestamp"] = 1567724817,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1467]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 7723,
					["Timestamp"] = 1567724818,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1468]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["Level"] = 47,
					["Quest"] = 7729,
					["Timestamp"] = 1567724822,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1469]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567725971,
					["Quest"] = 4451,
					["Level"] = 47,
				}, -- [1470]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567726464,
					["Quest"] = 7728,
					["Level"] = 47,
				}, -- [1471]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567727364,
					["Quest"] = 3371,
					["Level"] = 47,
				}, -- [1472]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567727368,
					["Quest"] = 3372,
					["Level"] = 47,
				}, -- [1473]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567727732,
					["Quest"] = 7701,
					["Level"] = 47,
				}, -- [1474]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567727736,
					["Quest"] = 7727,
					["Level"] = 47,
				}, -- [1475]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567727738,
					["Quest"] = 7722,
					["Level"] = 47,
				}, -- [1476]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567727868,
					["Quest"] = 3372,
					["Level"] = 47,
				}, -- [1477]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567728351,
					["Quest"] = 3452,
					["Level"] = 47,
				}, -- [1478]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567728352,
					["Quest"] = 3453,
					["Level"] = 47,
				}, -- [1479]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567728378,
					["Quest"] = 3453,
					["Level"] = 47,
				}, -- [1480]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567728379,
					["Quest"] = 3454,
					["Level"] = 47,
				}, -- [1481]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567728415,
					["Quest"] = 3454,
					["Level"] = 47,
				}, -- [1482]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567728418,
					["Quest"] = 3462,
					["Level"] = 47,
				}, -- [1483]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567728423,
					["Quest"] = 3462,
					["Level"] = 47,
				}, -- [1484]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567728424,
					["Quest"] = 3463,
					["Level"] = 47,
				}, -- [1485]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567729012,
					["Quest"] = 3463,
					["Level"] = 47,
				}, -- [1486]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567729038,
					["Quest"] = 3481,
					["Level"] = 47,
				}, -- [1487]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567729050,
					["Quest"] = 3481,
					["Level"] = 47,
				}, -- [1488]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567729566,
					["Quest"] = 4451,
					["Level"] = 47,
				}, -- [1489]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567729979,
					["Quest"] = 3448,
					["Level"] = 47,
				}, -- [1490]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567729997,
					["Quest"] = 2963,
					["Level"] = 47,
				}, -- [1491]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730021,
					["Quest"] = 2963,
					["Level"] = 47,
				}, -- [1492]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730022,
					["Quest"] = 2946,
					["Level"] = 47,
				}, -- [1493]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730074,
					["Quest"] = 3448,
					["Level"] = 47,
				}, -- [1494]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730075,
					["Quest"] = 3449,
					["Level"] = 47,
				}, -- [1495]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730078,
					["Quest"] = 3450,
					["Level"] = 47,
				}, -- [1496]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730134,
					["Quest"] = 3790,
					["Level"] = 47,
				}, -- [1497]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730327,
					["Quest"] = 3450,
					["Level"] = 47,
				}, -- [1498]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730327,
					["Quest"] = 3451,
					["Level"] = 47,
				}, -- [1499]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730328,
					["Quest"] = 3451,
					["Level"] = 47,
				}, -- [1500]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730900,
					["Quest"] = 2874,
					["Level"] = 47,
				}, -- [1501]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567730961,
					["Quest"] = 580,
					["Level"] = 47,
				}, -- [1502]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567730978,
					["Quest"] = 627,
					["Level"] = 47,
				}, -- [1503]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567730987,
					["Quest"] = 627,
					["Level"] = 47,
				}, -- [1504]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567731018,
					["Quest"] = 1118,
					["Level"] = 47,
				}, -- [1505]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567731455,
					["Quest"] = 2990,
					["Level"] = 47,
				}, -- [1506]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567731455,
					["Quest"] = 2991,
					["Level"] = 47,
				}, -- [1507]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567732064,
					["Quest"] = 2601,
					["Level"] = 47,
				}, -- [1508]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567732065,
					["Quest"] = 2603,
					["Level"] = 47,
				}, -- [1509]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567732066,
					["Quest"] = 2581,
					["Level"] = 47,
				}, -- [1510]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567732067,
					["Quest"] = 2583,
					["Level"] = 47,
				}, -- [1511]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567732069,
					["Quest"] = 2585,
					["Level"] = 47,
				}, -- [1512]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 47,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567733742,
					["Quest"] = 2521,
					["Level"] = 47,
				}, -- [1513]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567733748,
					["Quest"] = 3501,
					["Level"] = 47,
				}, -- [1514]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567733753,
					["Quest"] = 3501,
					["Level"] = 47,
				}, -- [1515]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567733754,
					["Quest"] = 3502,
					["Level"] = 47,
				}, -- [1516]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567733977,
					["Quest"] = 2581,
					["Level"] = 47,
				}, -- [1517]
				{
					["Timestamp"] = 1567733977,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 48,
				}, -- [1518]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567733978,
					["Quest"] = 2582,
					["Level"] = 48,
				}, -- [1519]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567734406,
					["Quest"] = 2582,
					["Level"] = 48,
				}, -- [1520]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567735556,
					["Quest"] = 2601,
					["Level"] = 48,
				}, -- [1521]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567735559,
					["Quest"] = 2603,
					["Level"] = 48,
				}, -- [1522]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567735647,
					["Quest"] = 2521,
					["Level"] = 48,
				}, -- [1523]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567736164,
					["Quest"] = 3502,
					["Level"] = 48,
				}, -- [1524]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567736165,
					["Quest"] = 2521,
					["Level"] = 48,
				}, -- [1525]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567736172,
					["Quest"] = 3502,
					["Level"] = 48,
				}, -- [1526]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567736176,
					["Quest"] = 3502,
					["Level"] = 48,
				}, -- [1527]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567736182,
					["Quest"] = 2521,
					["Level"] = 48,
				}, -- [1528]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567738123,
					["Quest"] = 2846,
					["Level"] = 48,
				}, -- [1529]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567738142,
					["Quest"] = 2583,
					["Level"] = 48,
				}, -- [1530]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567738146,
					["Quest"] = 2585,
					["Level"] = 48,
				}, -- [1531]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567738169,
					["Quest"] = 2601,
					["Level"] = 48,
				}, -- [1532]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567738336,
					["Quest"] = 3502,
					["Level"] = 48,
				}, -- [1533]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567738340,
					["Quest"] = 3502,
					["Level"] = 48,
				}, -- [1534]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567738392,
					["Quest"] = 2601,
					["Level"] = 48,
				}, -- [1535]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742369,
					["Quest"] = 4450,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1536]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742375,
					["Quest"] = 3042,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1537]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742397,
					["Quest"] = 2768,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1538]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742415,
					["Quest"] = 2941,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1539]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742430,
					["Quest"] = 2944,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1540]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742456,
					["Quest"] = 2605,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1541]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742478,
					["Quest"] = 2865,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1542]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742517,
					["Quest"] = 82,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1543]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742530,
					["Quest"] = 3362,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1544]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742555,
					["Quest"] = 4504,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1545]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742568,
					["Quest"] = 3022,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1546]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742587,
					["Quest"] = 2741,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1547]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742602,
					["Quest"] = 2750,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1548]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742722,
					["Quest"] = 5863,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1549]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742765,
					["Quest"] = 3022,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1550]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742817,
					["Quest"] = 4504,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1551]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742936,
					["Quest"] = 3520,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1552]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567742937,
					["Quest"] = 3527,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1553]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567744028,
					["Quest"] = 2876,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1554]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567744834,
					["Quest"] = 2882,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1555]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Timestamp"] = 1567744976,
					["Quest"] = 2876,
					["Level"] = 48,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1556]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 48,
					["Quest"] = 2768,
					["Timestamp"] = 1567804386,
				}, -- [1557]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 48,
					["Quest"] = 3527,
					["Timestamp"] = 1567804518,
				}, -- [1558]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 48,
					["Quest"] = 4787,
					["Timestamp"] = 1567804522,
				}, -- [1559]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 48,
					["Quest"] = 1118,
					["Timestamp"] = 1567804706,
				}, -- [1560]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 48,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 48,
					["Quest"] = 2770,
					["Timestamp"] = 1567804710,
				}, -- [1561]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 48,
					["Quest"] = 1118,
					["Timestamp"] = 1567805423,
				}, -- [1562]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 48,
					["Quest"] = 1119,
					["Timestamp"] = 1567805552,
				}, -- [1563]
				{
					["Timestamp"] = 1567806414,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 49,
				}, -- [1564]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 48,
					["Quest"] = 2846,
					["Timestamp"] = 1567806414,
				}, -- [1565]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 49,
					["Quest"] = 1119,
					["Timestamp"] = 1567806610,
				}, -- [1566]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 49,
					["Quest"] = 1121,
					["Timestamp"] = 1567806675,
				}, -- [1567]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 49,
					["Quest"] = 1121,
					["Timestamp"] = 1567806687,
				}, -- [1568]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 49,
					["Quest"] = 1122,
					["Timestamp"] = 1567806720,
				}, -- [1569]
				{
					["Party"] = {
					},
					["Level"] = 49,
					["Quest"] = 3161,
					["Timestamp"] = 1567819371,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1570]
				{
					["Party"] = {
					},
					["Level"] = 49,
					["Quest"] = 3445,
					["Timestamp"] = 1567819371,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1571]
				{
					["Party"] = {
					},
					["Level"] = 49,
					["Quest"] = 3444,
					["Timestamp"] = 1567819372,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1572]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 49,
					["Quest"] = 2946,
					["Timestamp"] = 1567903106,
				}, -- [1573]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 49,
					["Quest"] = 2954,
					["Timestamp"] = 1567903106,
				}, -- [1574]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 49,
					["Quest"] = 2954,
					["Timestamp"] = 1567903156,
				}, -- [1575]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 49,
					["Quest"] = 2977,
					["Timestamp"] = 1567903157,
				}, -- [1576]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908188,
					["Quest"] = 3161,
					["Level"] = 49,
				}, -- [1577]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908346,
					["Quest"] = 2605,
					["Level"] = 49,
				}, -- [1578]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567908346,
					["Quest"] = 2606,
					["Level"] = 49,
				}, -- [1579]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908371,
					["Quest"] = 5863,
					["Level"] = 49,
				}, -- [1580]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908392,
					["Quest"] = 3362,
					["Level"] = 49,
				}, -- [1581]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567908392,
					["Quest"] = 4504,
					["Level"] = 49,
				}, -- [1582]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908418,
					["Quest"] = 2606,
					["Level"] = 49,
				}, -- [1583]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567908419,
					["Quest"] = 2641,
					["Level"] = 49,
				}, -- [1584]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567908488,
					["Quest"] = 82,
					["Level"] = 49,
				}, -- [1585]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567908516,
					["Quest"] = 10,
					["Level"] = 49,
				}, -- [1586]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567909837,
					["Quest"] = 10,
					["Level"] = 49,
				}, -- [1587]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567909838,
					["Quest"] = 110,
					["Level"] = 49,
				}, -- [1588]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567909846,
					["Quest"] = 110,
					["Level"] = 49,
				}, -- [1589]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567909847,
					["Quest"] = 113,
					["Level"] = 49,
				}, -- [1590]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567909915,
					["Quest"] = 113,
					["Level"] = 49,
				}, -- [1591]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567909915,
					["Quest"] = 162,
					["Level"] = 49,
				}, -- [1592]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567911086,
					["Quest"] = 7003,
					["Level"] = 49,
				}, -- [1593]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567911087,
					["Quest"] = 7721,
					["Level"] = 49,
				}, -- [1594]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567914799,
					["Quest"] = 7003,
					["Level"] = 49,
				}, -- [1595]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567914800,
					["Quest"] = 7721,
					["Level"] = 49,
				}, -- [1596]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567914801,
					["Quest"] = 7725,
					["Level"] = 49,
				}, -- [1597]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567914803,
					["Quest"] = 7726,
					["Level"] = 49,
				}, -- [1598]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567915607,
					["Quest"] = 7725,
					["Level"] = 49,
				}, -- [1599]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567916501,
					["Quest"] = 7733,
					["Level"] = 49,
				}, -- [1600]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567916874,
					["Quest"] = 7726,
					["Level"] = 49,
				}, -- [1601]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567917073,
					["Quest"] = 3022,
					["Level"] = 49,
				}, -- [1602]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567917990,
					["Quest"] = 3022,
					["Level"] = 49,
				}, -- [1603]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567917991,
					["Quest"] = 3661,
					["Level"] = 49,
				}, -- [1604]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 49,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567918079,
					["Quest"] = 162,
					["Level"] = 49,
				}, -- [1605]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567918207,
					["Quest"] = 3790,
					["Level"] = 49,
				}, -- [1606]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567918208,
					["Quest"] = 3764,
					["Level"] = 49,
				}, -- [1607]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567919249,
					["Quest"] = 4101,
					["Level"] = 49,
				}, -- [1608]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1567919260,
					["Quest"] = 4101,
					["Level"] = 49,
				}, -- [1609]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567919279,
					["Quest"] = 5155,
					["Level"] = 49,
				}, -- [1610]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567919282,
					["Quest"] = 5156,
					["Level"] = 49,
				}, -- [1611]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567919288,
					["Quest"] = 4421,
					["Level"] = 49,
				}, -- [1612]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567919329,
					["Quest"] = 8460,
					["Level"] = 49,
				}, -- [1613]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567920789,
					["Quest"] = 8460,
					["Level"] = 49,
				}, -- [1614]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1567920790,
					["Quest"] = 8462,
					["Level"] = 49,
				}, -- [1615]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567921429,
					["Quest"] = 8466,
					["Level"] = 49,
				}, -- [1616]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Bhadgar",
							["Level"] = 30,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1567921432,
					["Quest"] = 8466,
					["Level"] = 49,
				}, -- [1617]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567957973,
					["Event"] = "Level",
					["NewLevel"] = 50,
				}, -- [1618]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567959793,
					["Quest"] = 5155,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1619]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567959794,
					["Quest"] = 5157,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1620]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567959798,
					["Quest"] = 4421,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1621]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567959799,
					["Quest"] = 4906,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1622]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567960658,
					["Quest"] = 5157,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1623]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567960659,
					["Quest"] = 5158,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1624]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567960901,
					["Quest"] = 4493,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1625]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567961361,
					["Quest"] = 5091,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1626]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 5156,
					["Timestamp"] = 1567962613,
				}, -- [1627]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 8462,
					["Timestamp"] = 1567962631,
				}, -- [1628]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 4906,
					["Timestamp"] = 1567962635,
				}, -- [1629]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5535,
					["Timestamp"] = 1567962700,
				}, -- [1630]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5536,
					["Timestamp"] = 1567962705,
				}, -- [1631]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5535,
					["Timestamp"] = 1567964153,
				}, -- [1632]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5536,
					["Timestamp"] = 1567964153,
				}, -- [1633]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 3503,
					["Timestamp"] = 1567965014,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1634]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 3601,
					["Timestamp"] = 1567965579,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1635]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 3601,
					["Timestamp"] = 1567966620,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1636]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 5534,
					["Timestamp"] = 1567966621,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1637]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567969074,
					["Quest"] = 5534,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1638]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567970591,
					["Quest"] = 3449,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1639]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567970592,
					["Quest"] = 3461,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1640]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567971400,
					["Quest"] = 1446,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1641]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567972152,
					["Quest"] = 5091,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1642]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567972153,
					["Quest"] = 5092,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1643]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567972169,
					["Quest"] = 5401,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1644]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567973022,
					["Quest"] = 5092,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1645]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567973023,
					["Quest"] = 5215,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1646]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567973027,
					["Quest"] = 5097,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1647]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567973046,
					["Quest"] = 5215,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1648]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567973047,
					["Quest"] = 5216,
					["Level"] = 50,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1649]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 5097,
					["Timestamp"] = 1567973862,
				}, -- [1650]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5021,
					["Timestamp"] = 1567974519,
				}, -- [1651]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5021,
					["Timestamp"] = 1567974957,
				}, -- [1652]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5022,
					["Timestamp"] = 1567974958,
				}, -- [1653]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5216,
					["Timestamp"] = 1567975479,
				}, -- [1654]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5217,
					["Timestamp"] = 1567975479,
				}, -- [1655]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5217,
					["Timestamp"] = 1567975781,
				}, -- [1656]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5219,
					["Timestamp"] = 1567975782,
				}, -- [1657]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5402,
					["Timestamp"] = 1567975807,
				}, -- [1658]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 4512,
					["Timestamp"] = 1567976214,
				}, -- [1659]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2977,
					["Timestamp"] = 1567976237,
				}, -- [1660]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2964,
					["Timestamp"] = 1567976238,
				}, -- [1661]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2964,
					["Timestamp"] = 1567976259,
				}, -- [1662]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 3461,
					["Timestamp"] = 1567976325,
				}, -- [1663]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5022,
					["Timestamp"] = 1567976754,
				}, -- [1664]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5048,
					["Timestamp"] = 1567976755,
				}, -- [1665]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 5219,
					["Timestamp"] = 1567976865,
				}, -- [1666]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 5048,
					["Timestamp"] = 1567977035,
				}, -- [1667]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 5050,
					["Timestamp"] = 1567977035,
				}, -- [1668]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2783,
					["Timestamp"] = 1567977374,
				}, -- [1669]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2991,
					["Timestamp"] = 1567977379,
				}, -- [1670]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2992,
					["Timestamp"] = 1567977380,
				}, -- [1671]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2992,
					["Timestamp"] = 1567977391,
				}, -- [1672]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2993,
					["Timestamp"] = 1567977392,
				}, -- [1673]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 4128,
					["Timestamp"] = 1567977471,
				}, -- [1674]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2783,
					["Timestamp"] = 1567977531,
				}, -- [1675]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2801,
					["Timestamp"] = 1567977532,
				}, -- [1676]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 50,
					["Quest"] = 2801,
					["Timestamp"] = 1567977572,
				}, -- [1677]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 2681,
					["Timestamp"] = 1567977573,
				}, -- [1678]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 2681,
					["Timestamp"] = 1567977606,
				}, -- [1679]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 122,
					["Timestamp"] = 1567977900,
				}, -- [1680]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 50,
					["Quest"] = 122,
					["Timestamp"] = 1567977909,
				}, -- [1681]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 3823,
					["Timestamp"] = 1567978073,
				}, -- [1682]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 4283,
					["Timestamp"] = 1567978077,
				}, -- [1683]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 50,
					["Quest"] = 4182,
					["Timestamp"] = 1567978104,
				}, -- [1684]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 5050,
					["Timestamp"] = 1567980457,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1685]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 2865,
					["Timestamp"] = 1567980487,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1686]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 3042,
					["Timestamp"] = 1567980490,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1687]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4726,
					["Timestamp"] = 1567980491,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1688]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4123,
					["Timestamp"] = 1567980492,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1689]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4296,
					["Timestamp"] = 1567980542,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1690]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4123,
					["Timestamp"] = 1567980558,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1691]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4296,
					["Timestamp"] = 1567980663,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1692]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4726,
					["Timestamp"] = 1567983702,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1693]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 4808,
					["Timestamp"] = 1567983703,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1694]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Timestamp"] = 1567984036,
					["Event"] = "Level",
					["NewLevel"] = 51,
				}, -- [1695]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 50,
						}, -- [1]
					},
					["Level"] = 50,
					["Quest"] = 3823,
					["Timestamp"] = 1567984036,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1696]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3824,
					["Timestamp"] = 1567984055,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1697]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3824,
					["Timestamp"] = 1567986353,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1698]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3825,
					["Timestamp"] = 1567986354,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1699]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4182,
					["Timestamp"] = 1567986373,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1700]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4183,
					["Timestamp"] = 1567986374,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1701]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3825,
					["Timestamp"] = 1567986780,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1702]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4286,
					["Timestamp"] = 1567986781,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1703]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4183,
					["Timestamp"] = 1567986998,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1704]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4184,
					["Timestamp"] = 1567986999,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1705]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568041818,
					["Quest"] = 4184,
					["Level"] = 51,
				}, -- [1706]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568041827,
					["Quest"] = 4185,
					["Level"] = 51,
				}, -- [1707]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568041839,
					["Quest"] = 4185,
					["Level"] = 51,
				}, -- [1708]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568041840,
					["Quest"] = 4186,
					["Level"] = 51,
				}, -- [1709]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568042069,
					["Quest"] = 4186,
					["Level"] = 51,
				}, -- [1710]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568042070,
					["Quest"] = 4223,
					["Level"] = 51,
				}, -- [1711]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568042180,
					["Quest"] = 4223,
					["Level"] = 51,
				}, -- [1712]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568042181,
					["Quest"] = 4224,
					["Level"] = 51,
				}, -- [1713]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568042227,
					["Quest"] = 4286,
					["Level"] = 51,
				}, -- [1714]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568042491,
					["Quest"] = 4224,
					["Level"] = 51,
				}, -- [1715]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568042581,
					["Quest"] = 2993,
					["Level"] = 51,
				}, -- [1716]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568042582,
					["Quest"] = 2994,
					["Level"] = 51,
				}, -- [1717]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568044428,
					["Quest"] = 2994,
					["Level"] = 51,
				}, -- [1718]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568045124,
					["Quest"] = 1122,
					["Level"] = 51,
				}, -- [1719]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568045542,
					["Quest"] = 594,
					["Level"] = 51,
				}, -- [1720]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568045594,
					["Quest"] = 594,
					["Level"] = 51,
				}, -- [1721]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568045595,
					["Quest"] = 630,
					["Level"] = 51,
				}, -- [1722]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568045731,
					["Quest"] = 630,
					["Level"] = 51,
				}, -- [1723]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568046308,
					["Quest"] = 5158,
					["Level"] = 51,
				}, -- [1724]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568046355,
					["Quest"] = 5159,
					["Level"] = 51,
				}, -- [1725]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568046426,
					["Quest"] = 4502,
					["Level"] = 51,
				}, -- [1726]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568046620,
					["Quest"] = 6624,
					["Level"] = 51,
				}, -- [1727]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568046765,
					["Quest"] = 6624,
					["Level"] = 51,
				}, -- [1728]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2641,
					["Timestamp"] = 1568050150,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1729]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4493,
					["Timestamp"] = 1568050153,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1730]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4496,
					["Timestamp"] = 1568050154,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1731]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2661,
					["Timestamp"] = 1568050156,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1732]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2661,
					["Timestamp"] = 1568050170,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1733]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2662,
					["Timestamp"] = 1568050170,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1734]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2662,
					["Timestamp"] = 1568050186,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1735]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4787,
					["Timestamp"] = 1568050353,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1736]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3528,
					["Timestamp"] = 1568050354,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1737]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3444,
					["Timestamp"] = 1568050522,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1738]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3446,
					["Timestamp"] = 1568050525,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1739]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 3447,
					["Timestamp"] = 1568050530,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1740]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2882,
					["Timestamp"] = 1568050925,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1741]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4289,
					["Timestamp"] = 1568051965,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1742]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4290,
					["Timestamp"] = 1568051968,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1743]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4503,
					["Timestamp"] = 1568052503,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1744]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4501,
					["Timestamp"] = 1568052517,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1745]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 5159,
					["Timestamp"] = 1568053658,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1746]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4808,
					["Timestamp"] = 1568055338,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1747]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2944,
					["Timestamp"] = 1568055859,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1748]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 2943,
					["Timestamp"] = 1568055863,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1749]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4512,
					["Timestamp"] = 1568056670,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1750]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Level"] = 51,
					["Quest"] = 4513,
					["Timestamp"] = 1568056705,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1751]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061324,
					["Quest"] = 3881,
					["Level"] = 51,
				}, -- [1752]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061328,
					["Quest"] = 3882,
					["Level"] = 51,
				}, -- [1753]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061359,
					["Quest"] = 3883,
					["Level"] = 51,
				}, -- [1754]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061417,
					["Quest"] = 4141,
					["Level"] = 51,
				}, -- [1755]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568061430,
					["Quest"] = 4283,
					["Level"] = 51,
				}, -- [1756]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061450,
					["Quest"] = 4243,
					["Level"] = 51,
				}, -- [1757]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568061461,
					["Quest"] = 4243,
					["Level"] = 51,
				}, -- [1758]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061590,
					["Quest"] = 3884,
					["Level"] = 51,
				}, -- [1759]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568061597,
					["Quest"] = 3884,
					["Level"] = 51,
				}, -- [1760]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568061745,
					["Quest"] = 3884,
					["Level"] = 51,
				}, -- [1761]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568062588,
					["Quest"] = 1446,
					["Level"] = 51,
				}, -- [1762]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568062590,
					["Quest"] = 3844,
					["Level"] = 51,
				}, -- [1763]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568062594,
					["Quest"] = 3844,
					["Level"] = 51,
				}, -- [1764]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568062595,
					["Quest"] = 3845,
					["Level"] = 51,
				}, -- [1765]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568062646,
					["Quest"] = 4290,
					["Level"] = 51,
				}, -- [1766]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568062647,
					["Quest"] = 4291,
					["Level"] = 51,
				}, -- [1767]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568063084,
					["Quest"] = 4291,
					["Level"] = 51,
				}, -- [1768]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568063085,
					["Quest"] = 4292,
					["Level"] = 51,
				}, -- [1769]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568065491,
					["Quest"] = 4128,
					["Level"] = 51,
				}, -- [1770]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568065544,
					["Quest"] = 4243,
					["Level"] = 51,
				}, -- [1771]
				{
					["Timestamp"] = 1568065564,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 52,
				}, -- [1772]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 51,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568065564,
					["Quest"] = 3884,
					["Level"] = 51,
				}, -- [1773]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568065581,
					["Quest"] = 3845,
					["Level"] = 52,
				}, -- [1774]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568065582,
					["Quest"] = 3908,
					["Level"] = 52,
				}, -- [1775]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568065631,
					["Quest"] = 4284,
					["Level"] = 52,
				}, -- [1776]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568065635,
					["Quest"] = 4284,
					["Level"] = 52,
				}, -- [1777]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568065636,
					["Quest"] = 4285,
					["Level"] = 52,
				}, -- [1778]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568065711,
					["Quest"] = 3908,
					["Level"] = 52,
				}, -- [1779]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568065719,
					["Quest"] = 4287,
					["Level"] = 52,
				}, -- [1780]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568066559,
					["Quest"] = 4243,
					["Level"] = 52,
				}, -- [1781]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568066560,
					["Quest"] = 4244,
					["Level"] = 52,
				}, -- [1782]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568066562,
					["Quest"] = 4244,
					["Level"] = 52,
				}, -- [1783]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568066562,
					["Quest"] = 4245,
					["Level"] = 52,
				}, -- [1784]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568066716,
					["Quest"] = 4245,
					["Level"] = 52,
				}, -- [1785]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568066838,
					["Quest"] = 4245,
					["Level"] = 52,
				}, -- [1786]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568067182,
					["Quest"] = 4245,
					["Level"] = 52,
				}, -- [1787]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568069615,
					["Quest"] = 4141,
					["Level"] = 52,
				}, -- [1788]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568069616,
					["Quest"] = 4142,
					["Level"] = 52,
				}, -- [1789]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568069669,
					["Quest"] = 4285,
					["Level"] = 52,
				}, -- [1790]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568069670,
					["Quest"] = 4288,
					["Level"] = 52,
				}, -- [1791]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568070210,
					["Quest"] = 2943,
					["Level"] = 52,
				}, -- [1792]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568070221,
					["Quest"] = 2879,
					["Level"] = 52,
				}, -- [1793]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568070532,
					["Quest"] = 4142,
					["Level"] = 52,
				}, -- [1794]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568070539,
					["Quest"] = 4143,
					["Level"] = 52,
				}, -- [1795]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568070548,
					["Quest"] = 2879,
					["Level"] = 52,
				}, -- [1796]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568070611,
					["Quest"] = 4504,
					["Level"] = 52,
				}, -- [1797]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568070611,
					["Quest"] = 2865,
					["Level"] = 52,
				}, -- [1798]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568070617,
					["Quest"] = 2865,
					["Level"] = 52,
				}, -- [1799]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568070751,
					["Quest"] = 4492,
					["Level"] = 52,
				}, -- [1800]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568071593,
					["Quest"] = 974,
					["Level"] = 52,
				}, -- [1801]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568072968,
					["Quest"] = 4492,
					["Level"] = 52,
				}, -- [1802]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568072975,
					["Quest"] = 4491,
					["Level"] = 52,
				}, -- [1803]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073421,
					["Quest"] = 5150,
					["Level"] = 52,
				}, -- [1804]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073430,
					["Quest"] = 3882,
					["Level"] = 52,
				}, -- [1805]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073434,
					["Quest"] = 3881,
					["Level"] = 52,
				}, -- [1806]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073454,
					["Quest"] = 4491,
					["Level"] = 52,
				}, -- [1807]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073478,
					["Quest"] = 4503,
					["Level"] = 52,
				}, -- [1808]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073804,
					["Quest"] = 4289,
					["Level"] = 52,
				}, -- [1809]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568073815,
					["Quest"] = 4292,
					["Level"] = 52,
				}, -- [1810]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568073815,
					["Quest"] = 4301,
					["Level"] = 52,
				}, -- [1811]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074687,
					["Quest"] = 4496,
					["Level"] = 52,
				}, -- [1812]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568074688,
					["Quest"] = 4507,
					["Level"] = 52,
				}, -- [1813]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074835,
					["Quest"] = 3883,
					["Level"] = 52,
				}, -- [1814]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074850,
					["Quest"] = 4501,
					["Level"] = 52,
				}, -- [1815]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568074864,
					["Quest"] = 3908,
					["Level"] = 52,
				}, -- [1816]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074913,
					["Quest"] = 4287,
					["Level"] = 52,
				}, -- [1817]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074913,
					["Quest"] = 4288,
					["Level"] = 52,
				}, -- [1818]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568074914,
					["Quest"] = 4321,
					["Level"] = 52,
				}, -- [1819]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568074916,
					["Quest"] = 4321,
					["Level"] = 52,
				}, -- [1820]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568075662,
					["Quest"] = 4301,
					["Level"] = 52,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1821]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568076246,
					["Quest"] = 974,
					["Level"] = 52,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1822]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568076246,
					["Quest"] = 980,
					["Level"] = 52,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1823]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568076569,
					["Event"] = "Level",
					["NewLevel"] = 53,
				}, -- [1824]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568076569,
					["Quest"] = 4507,
					["Level"] = 52,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1825]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568076570,
					["Quest"] = 4508,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1826]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568077602,
					["Quest"] = 978,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1827]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568077609,
					["Quest"] = 5250,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1828]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568077692,
					["Quest"] = 4508,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1829]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568077701,
					["Quest"] = 4510,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1830]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 52,
						}, -- [1]
					},
					["Timestamp"] = 1568077778,
					["Quest"] = 4510,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1831]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568077857,
					["Quest"] = 3764,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1832]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568077920,
					["Quest"] = 3781,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1833]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568077940,
					["Quest"] = 3781,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1834]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568077943,
					["Quest"] = 3785,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1835]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568078630,
					["Quest"] = 4101,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1836]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568078663,
					["Quest"] = 8462,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1837]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568078675,
					["Quest"] = 5165,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1838]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568078680,
					["Quest"] = 4906,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1839]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568078689,
					["Quest"] = 5156,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1840]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568079561,
					["Quest"] = 5202,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1841]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568079758,
					["Quest"] = 5202,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1842]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568079781,
					["Quest"] = 5203,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1843]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568081519,
					["Quest"] = 939,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1844]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568083924,
					["Quest"] = 8462,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1845]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568083925,
					["Quest"] = 8461,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1846]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084097,
					["Quest"] = 8470,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1847]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084774,
					["Quest"] = 8461,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1848]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084775,
					["Quest"] = 8465,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1849]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084869,
					["Quest"] = 8465,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1850]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084870,
					["Quest"] = 8464,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1851]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084898,
					["Quest"] = 8464,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1852]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084934,
					["Quest"] = 980,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1853]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084935,
					["Quest"] = 4842,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1854]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568084938,
					["Quest"] = 3908,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1855]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085028,
					["Quest"] = 3909,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1856]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085035,
					["Quest"] = 5082,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1857]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085483,
					["Quest"] = 5250,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1858]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085484,
					["Quest"] = 5244,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1859]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085491,
					["Quest"] = 5244,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1860]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085493,
					["Quest"] = 5245,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1861]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085497,
					["Quest"] = 4861,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1862]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085675,
					["Quest"] = 3785,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1863]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085678,
					["Quest"] = 2879,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1864]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085705,
					["Quest"] = 8470,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1865]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568085741,
					["Quest"] = 5082,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1866]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086292,
					["Quest"] = 2844,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1867]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086456,
					["Quest"] = 2844,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1868]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086463,
					["Quest"] = 2845,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1869]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086757,
					["Quest"] = 2879,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1870]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086757,
					["Quest"] = 2942,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1871]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086883,
					["Quest"] = 2845,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1872]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568086954,
					["Quest"] = 4041,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1873]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568087289,
					["Quest"] = 2942,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1874]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088534,
					["Quest"] = 4101,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1875]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088590,
					["Quest"] = 5165,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1876]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088591,
					["Quest"] = 5242,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1877]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088594,
					["Quest"] = 5203,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1878]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088595,
					["Quest"] = 5204,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1879]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088600,
					["Quest"] = 4906,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1880]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088601,
					["Quest"] = 939,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1881]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088601,
					["Quest"] = 4441,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1882]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568088608,
					["Quest"] = 5156,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1883]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568089706,
					["Quest"] = 5204,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1884]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568089713,
					["Quest"] = 5385,
					["Level"] = 53,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1885]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 3783,
					["Timestamp"] = 1568137763,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1886]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 6603,
					["Timestamp"] = 1568137768,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1887]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4809,
					["Timestamp"] = 1568137780,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1888]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 6028,
					["Timestamp"] = 1568137790,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1889]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 6030,
					["Timestamp"] = 1568137791,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1890]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4861,
					["Timestamp"] = 1568140209,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1891]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4863,
					["Timestamp"] = 1568140210,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1892]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4863,
					["Timestamp"] = 1568140292,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1893]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4864,
					["Timestamp"] = 1568140293,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1894]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 3783,
					["Timestamp"] = 1568140807,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1895]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 977,
					["Timestamp"] = 1568140812,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1896]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 4864,
					["Timestamp"] = 1568141074,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1897]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 53,
					["Quest"] = 3909,
					["Timestamp"] = 1568142016,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1898]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Timestamp"] = 1568142016,
					["Event"] = "Level",
					["NewLevel"] = 54,
				}, -- [1899]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 3912,
					["Timestamp"] = 1568142021,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1900]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 53,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 4842,
					["Timestamp"] = 1568142024,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1901]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 6603,
					["Timestamp"] = 1568142027,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1902]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5082,
					["Timestamp"] = 1568142030,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1903]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 8464,
					["Timestamp"] = 1568142733,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1904]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5083,
					["Timestamp"] = 1568142783,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1905]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5082,
					["Timestamp"] = 1568143145,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1906]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5083,
					["Timestamp"] = 1568143146,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1907]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5084,
					["Timestamp"] = 1568143147,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1908]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568146112,
					["Quest"] = 978,
					["Level"] = 54,
				}, -- [1909]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568146113,
					["Quest"] = 979,
					["Level"] = 54,
				}, -- [1910]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568150427,
					["Quest"] = 3785,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1911]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568150432,
					["Quest"] = 3785,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1912]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568151546,
					["Quest"] = 5885,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1913]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568151549,
					["Quest"] = 5882,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1914]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568151553,
					["Quest"] = 4103,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1915]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568151602,
					["Quest"] = 5242,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1916]
				{
					["Party"] = {
					},
					["Timestamp"] = 1568151614,
					["Quest"] = 5385,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1917]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568153834,
					["Quest"] = 4502,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1918]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154100,
					["Quest"] = 7070,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1919]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154517,
					["Quest"] = 7065,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1920]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154611,
					["Quest"] = 7041,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1921]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154777,
					["Quest"] = 977,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1922]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154793,
					["Quest"] = 6028,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1923]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154796,
					["Quest"] = 6030,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [1924]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568154805,
					["Quest"] = 7028,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1925]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568155005,
					["Quest"] = 7067,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1926]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [4]
					},
					["Timestamp"] = 1568157287,
					["Quest"] = 7044,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1927]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [4]
					},
					["Timestamp"] = 1568161301,
					["Quest"] = 7044,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1928]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [4]
					},
					["Timestamp"] = 1568161302,
					["Quest"] = 7046,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1929]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [4]
					},
					["Timestamp"] = 1568161357,
					["Quest"] = 7046,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [1930]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Thesmarthobo",
							["Level"] = 50,
						}, -- [4]
					},
					["Timestamp"] = 1568162645,
					["Quest"] = 7066,
					["Level"] = 54,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [1931]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 54,
					["Quest"] = 7070,
					["Timestamp"] = 1568165029,
				}, -- [1932]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 7067,
					["Timestamp"] = 1568165279,
				}, -- [1933]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 7028,
					["Timestamp"] = 1568166027,
				}, -- [1934]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 7041,
					["Timestamp"] = 1568166147,
				}, -- [1935]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 7065,
					["Timestamp"] = 1568166184,
				}, -- [1936]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 5084,
					["Timestamp"] = 1568166994,
				}, -- [1937]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 54,
					["Quest"] = 5085,
					["Timestamp"] = 1568166995,
				}, -- [1938]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 7066,
					["Timestamp"] = 1568167312,
				}, -- [1939]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 54,
					["Quest"] = 1258,
					["Timestamp"] = 1568168371,
				}, -- [1940]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 54,
					["Quest"] = 1258,
					["Timestamp"] = 1568168378,
				}, -- [1941]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 54,
					["Quest"] = 4513,
					["Timestamp"] = 1568169442,
				}, -- [1942]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 54,
					["Quest"] = 3702,
					["Timestamp"] = 1568169514,
				}, -- [1943]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 6028,
					["Timestamp"] = 1568170423,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1944]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 6030,
					["Timestamp"] = 1568170426,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1945]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 977,
					["Timestamp"] = 1568170574,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1946]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5085,
					["Timestamp"] = 1568171268,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1947]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5086,
					["Timestamp"] = 1568171269,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1948]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 4809,
					["Timestamp"] = 1568173041,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1949]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 4810,
					["Timestamp"] = 1568173048,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1950]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 977,
					["Timestamp"] = 1568173103,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [1951]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 1446,
					["Timestamp"] = 1568173637,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1952]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 8464,
					["Timestamp"] = 1568173760,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1953]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Timestamp"] = 1568173831,
					["Event"] = "Level",
					["NewLevel"] = 55,
				}, -- [1954]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 54,
					["Quest"] = 5086,
					["Timestamp"] = 1568173831,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1955]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 54,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 5087,
					["Timestamp"] = 1568173832,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1956]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 5087,
					["Timestamp"] = 1568173950,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1957]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 5121,
					["Timestamp"] = 1568174019,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1958]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 1019,
					["Timestamp"] = 1568174874,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1959]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 3702,
					["Timestamp"] = 1568174939,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [1960]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Level"] = 55,
					["Quest"] = 3701,
					["Timestamp"] = 1568174939,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [1961]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 55,
					["Quest"] = 4283,
					["Timestamp"] = 1568215826,
				}, -- [1962]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 55,
					["Quest"] = 4022,
					["Timestamp"] = 1568215974,
				}, -- [1963]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 55,
					["Quest"] = 4022,
					["Timestamp"] = 1568216172,
				}, -- [1964]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 55,
					["Quest"] = 4024,
					["Timestamp"] = 1568216180,
				}, -- [1965]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568216968,
					["Quest"] = 4810,
					["Level"] = 55,
				}, -- [1966]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568217028,
					["Quest"] = 4296,
					["Level"] = 55,
				}, -- [1967]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568218156,
					["Quest"] = 4296,
					["Level"] = 55,
				}, -- [1968]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568218306,
					["Quest"] = 4283,
					["Level"] = 55,
				}, -- [1969]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568218398,
					["Quest"] = 3701,
					["Level"] = 55,
				}, -- [1970]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568218867,
					["Quest"] = 5219,
					["Level"] = 55,
				}, -- [1971]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568218885,
					["Quest"] = 6028,
					["Level"] = 55,
				}, -- [1972]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568218890,
					["Quest"] = 5097,
					["Level"] = 55,
				}, -- [1973]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568218905,
					["Quest"] = 5903,
					["Level"] = 55,
				}, -- [1974]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568218982,
					["Quest"] = 5142,
					["Level"] = 55,
				}, -- [1975]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568219485,
					["Quest"] = 4971,
					["Level"] = 55,
				}, -- [1976]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568220322,
					["Quest"] = 4984,
					["Level"] = 55,
				}, -- [1977]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568220965,
					["Quest"] = 5058,
					["Level"] = 55,
				}, -- [1978]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568221178,
					["Quest"] = 5059,
					["Level"] = 55,
				}, -- [1979]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568221470,
					["Quest"] = 5060,
					["Level"] = 55,
				}, -- [1980]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568221770,
					["Quest"] = 5219,
					["Level"] = 55,
				}, -- [1981]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568221771,
					["Quest"] = 5220,
					["Level"] = 55,
				}, -- [1982]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568222954,
					["Quest"] = 4984,
					["Level"] = 55,
				}, -- [1983]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568222955,
					["Quest"] = 4985,
					["Level"] = 55,
				}, -- [1984]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568223135,
					["Quest"] = 5220,
					["Level"] = 55,
				}, -- [1985]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568223140,
					["Quest"] = 5222,
					["Level"] = 55,
				}, -- [1986]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568223144,
					["Quest"] = 5097,
					["Level"] = 55,
				}, -- [1987]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568223148,
					["Quest"] = 5533,
					["Level"] = 55,
				}, -- [1988]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568223151,
					["Quest"] = 5533,
					["Level"] = 55,
				}, -- [1989]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568223152,
					["Quest"] = 5537,
					["Level"] = 55,
				}, -- [1990]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568223955,
					["Quest"] = 5222,
					["Level"] = 55,
				}, -- [1991]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568223956,
					["Quest"] = 5223,
					["Level"] = 55,
				}, -- [1992]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568224755,
					["Quest"] = 4985,
					["Level"] = 55,
				}, -- [1993]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568224756,
					["Quest"] = 4986,
					["Level"] = 55,
				}, -- [1994]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568225021,
					["Quest"] = 5542,
					["Level"] = 55,
				}, -- [1995]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568225038,
					["Quest"] = 1019,
					["Level"] = 55,
				}, -- [1996]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568225046,
					["Quest"] = 4024,
					["Level"] = 55,
				}, -- [1997]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568225049,
					["Quest"] = 5543,
					["Level"] = 55,
				}, -- [1998]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568225050,
					["Quest"] = 5544,
					["Level"] = 55,
				}, -- [1999]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568226359,
					["Quest"] = 5142,
					["Level"] = 55,
				}, -- [2000]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568226360,
					["Quest"] = 5149,
					["Level"] = 55,
				}, -- [2001]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568226586,
					["Quest"] = 5149,
					["Level"] = 55,
				}, -- [2002]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568226587,
					["Quest"] = 5152,
					["Level"] = 55,
				}, -- [2003]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568226602,
					["Quest"] = 1446,
					["Level"] = 55,
				}, -- [2004]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568226609,
					["Quest"] = 5241,
					["Level"] = 55,
				}, -- [2005]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568228145,
					["Quest"] = 6030,
					["Level"] = 55,
				}, -- [2006]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568228150,
					["Quest"] = 5241,
					["Level"] = 55,
				}, -- [2007]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568228300,
					["Quest"] = 6021,
					["Level"] = 55,
				}, -- [2008]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568228497,
					["Quest"] = 5223,
					["Level"] = 55,
				}, -- [2009]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568228502,
					["Quest"] = 5225,
					["Level"] = 55,
				}, -- [2010]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568228668,
					["Quest"] = 5152,
					["Level"] = 55,
				}, -- [2011]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568228669,
					["Quest"] = 5153,
					["Level"] = 55,
				}, -- [2012]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568229134,
					["Quest"] = 5153,
					["Level"] = 55,
				}, -- [2013]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568229135,
					["Quest"] = 5154,
					["Level"] = 55,
				}, -- [2014]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568229141,
					["Quest"] = 4971,
					["Level"] = 55,
				}, -- [2015]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568229142,
					["Quest"] = 4972,
					["Level"] = 55,
				}, -- [2016]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568230618,
					["Quest"] = 211,
					["Level"] = 55,
				}, -- [2017]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568231556,
					["Quest"] = 5154,
					["Level"] = 55,
				}, -- [2018]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568231557,
					["Quest"] = 5210,
					["Level"] = 55,
				}, -- [2019]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568231558,
					["Quest"] = 4972,
					["Level"] = 55,
				}, -- [2020]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568231558,
					["Quest"] = 4973,
					["Level"] = 55,
				}, -- [2021]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568231621,
					["Quest"] = 4973,
					["Level"] = 55,
				}, -- [2022]
				{
					["Timestamp"] = 1568231902,
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 55,
						}, -- [1]
					},
					["Event"] = "Level",
					["NewLevel"] = 56,
				}, -- [2023]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568232460,
					["Quest"] = 5225,
					["Level"] = 56,
				}, -- [2024]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568232461,
					["Quest"] = 5226,
					["Level"] = 56,
				}, -- [2025]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568233437,
					["Quest"] = 6024,
					["Level"] = 56,
				}, -- [2026]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568233937,
					["Quest"] = 6021,
					["Level"] = 56,
				}, -- [2027]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234000,
					["Quest"] = 5210,
					["Level"] = 56,
				}, -- [2028]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234011,
					["Quest"] = 5510,
					["Level"] = 56,
				}, -- [2029]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234259,
					["Quest"] = 5226,
					["Level"] = 56,
				}, -- [2030]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234269,
					["Quest"] = 211,
					["Level"] = 56,
				}, -- [2031]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234289,
					["Quest"] = 5237,
					["Level"] = 56,
				}, -- [2032]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568234295,
					["Quest"] = 5537,
					["Level"] = 56,
				}, -- [2033]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568234296,
					["Quest"] = 5538,
					["Level"] = 56,
				}, -- [2034]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568234877,
					["Quest"] = 5050,
					["Level"] = 56,
				}, -- [2035]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568235224,
					["Quest"] = 1015,
					["Level"] = 56,
				}, -- [2036]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568236311,
					["Quest"] = 5538,
					["Level"] = 56,
				}, -- [2037]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568236313,
					["Quest"] = 5801,
					["Level"] = 56,
				}, -- [2038]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568236381,
					["Quest"] = 3912,
					["Level"] = 56,
				}, -- [2039]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568236382,
					["Quest"] = 3913,
					["Level"] = 56,
				}, -- [2040]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568236392,
					["Quest"] = 3913,
					["Level"] = 56,
				}, -- [2041]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568236392,
					["Quest"] = 3914,
					["Level"] = 56,
				}, -- [2042]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568236545,
					["Quest"] = 3914,
					["Level"] = 56,
				}, -- [2043]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568236549,
					["Quest"] = 3941,
					["Level"] = 56,
				}, -- [2044]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568236645,
					["Quest"] = 3941,
					["Level"] = 56,
				}, -- [2045]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568236667,
					["Quest"] = 3942,
					["Level"] = 56,
				}, -- [2046]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568237452,
					["Quest"] = 4986,
					["Level"] = 56,
				}, -- [2047]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568237471,
					["Quest"] = 1015,
					["Level"] = 56,
				}, -- [2048]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568237473,
					["Quest"] = 6761,
					["Level"] = 56,
				}, -- [2049]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568237511,
					["Quest"] = 6761,
					["Level"] = 56,
				}, -- [2050]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568237515,
					["Quest"] = 6762,
					["Level"] = 56,
				}, -- [2051]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568238451,
					["Quest"] = 3942,
					["Level"] = 56,
				}, -- [2052]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568238452,
					["Quest"] = 4084,
					["Level"] = 56,
				}, -- [2053]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568238453,
					["Quest"] = 4441,
					["Level"] = 56,
				}, -- [2054]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568238471,
					["Quest"] = 4442,
					["Level"] = 56,
				}, -- [2055]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568238473,
					["Quest"] = 4442,
					["Level"] = 56,
				}, -- [2056]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568240357,
					["Quest"] = 4261,
					["Level"] = 56,
				}, -- [2057]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241145,
					["Quest"] = 4084,
					["Level"] = 56,
				}, -- [2058]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568241146,
					["Quest"] = 4005,
					["Level"] = 56,
				}, -- [2059]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241203,
					["Quest"] = 4106,
					["Level"] = 56,
				}, -- [2060]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241206,
					["Quest"] = 4106,
					["Level"] = 56,
				}, -- [2061]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241213,
					["Quest"] = 4106,
					["Level"] = 56,
				}, -- [2062]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241215,
					["Quest"] = 4106,
					["Level"] = 56,
				}, -- [2063]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241218,
					["Quest"] = 4106,
					["Level"] = 56,
				}, -- [2064]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568241500,
					["Quest"] = 4261,
					["Level"] = 56,
				}, -- [2065]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568241501,
					["Quest"] = 1011,
					["Level"] = 56,
				}, -- [2066]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1568241518,
					["Quest"] = 1011,
					["Level"] = 56,
				}, -- [2067]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568252178,
					["Quest"] = 6762,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2068]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568252179,
					["Quest"] = 1124,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2069]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568252465,
					["Quest"] = 977,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2070]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568252585,
					["Quest"] = 979,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2071]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568252591,
					["Quest"] = 4901,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2072]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568254721,
					["Quest"] = 977,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2073]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568254722,
					["Quest"] = 5163,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2074]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568255215,
					["Quest"] = 4901,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2075]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568255216,
					["Quest"] = 4902,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2076]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568255309,
					["Quest"] = 4902,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2077]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568256112,
					["Quest"] = 6182,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2078]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568256409,
					["Quest"] = 6182,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2079]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568256410,
					["Quest"] = 6183,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2080]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568256412,
					["Quest"] = 6183,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2081]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568256413,
					["Quest"] = 6184,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2082]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257210,
					["Quest"] = 5181,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2083]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257245,
					["Quest"] = 5281,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2084]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257447,
					["Quest"] = 5801,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2085]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257448,
					["Quest"] = 5803,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2086]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257456,
					["Quest"] = 6184,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2087]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568257457,
					["Quest"] = 6185,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2088]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568258925,
					["Quest"] = 5245,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2089]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568260042,
					["Quest"] = 5281,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2090]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568260055,
					["Quest"] = 6164,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2091]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568260314,
					["Quest"] = 6164,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2092]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568261015,
					["Quest"] = 5542,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2093]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568261015,
					["Quest"] = 5543,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2094]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568261016,
					["Quest"] = 5544,
					["Level"] = 56,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2095]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568261016,
					["Event"] = "Level",
					["NewLevel"] = 57,
				}, -- [2096]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 56,
						}, -- [1]
					},
					["Timestamp"] = 1568261017,
					["Quest"] = 5742,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2097]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568261056,
					["Quest"] = 5742,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2098]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568261057,
					["Quest"] = 5781,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2099]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568261382,
					["Quest"] = 6024,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2100]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568261646,
					["Quest"] = 5781,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2101]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568261646,
					["Quest"] = 5845,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2102]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262438,
					["Quest"] = 5181,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2103]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262447,
					["Quest"] = 5168,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2104]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262460,
					["Quest"] = 5168,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [2105]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262635,
					["Quest"] = 6185,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2106]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262636,
					["Quest"] = 6186,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2107]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262641,
					["Quest"] = 5903,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2108]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568262645,
					["Quest"] = 5904,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2109]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568315381,
					["Quest"] = 5050,
					["Level"] = 57,
				}, -- [2110]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568315385,
					["Quest"] = 5051,
					["Level"] = 57,
				}, -- [2111]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568315547,
					["Quest"] = 5051,
					["Level"] = 57,
				}, -- [2112]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568315764,
					["Quest"] = 5904,
					["Level"] = 57,
				}, -- [2113]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568315764,
					["Quest"] = 6389,
					["Level"] = 57,
				}, -- [2114]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568315819,
					["Quest"] = 6004,
					["Level"] = 57,
				}, -- [2115]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568316654,
					["Quest"] = 6004,
					["Level"] = 57,
				}, -- [2116]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568316655,
					["Quest"] = 6023,
					["Level"] = 57,
				}, -- [2117]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568317154,
					["Quest"] = 6023,
					["Level"] = 57,
				}, -- [2118]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568317161,
					["Quest"] = 6025,
					["Level"] = 57,
				}, -- [2119]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568317552,
					["Quest"] = 6025,
					["Level"] = 57,
				}, -- [2120]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568317827,
					["Quest"] = 5845,
					["Level"] = 57,
				}, -- [2121]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568317828,
					["Quest"] = 5846,
					["Level"] = 57,
				}, -- [2122]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568318079,
					["Quest"] = 5846,
					["Level"] = 57,
				}, -- [2123]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Greenbar",
							["Level"] = 51,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Greenbar",
							["Level"] = 51,
						}, -- [2]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568318241,
					["Quest"] = 6389,
					["Level"] = 57,
				}, -- [2124]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568318875,
					["Quest"] = 4128,
					["Level"] = 57,
				}, -- [2125]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568319254,
					["Quest"] = 1446,
					["Level"] = 57,
				}, -- [2126]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568322700,
					["Quest"] = 3446,
					["Level"] = 57,
				}, -- [2127]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 52,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568322827,
					["Quest"] = 3447,
					["Level"] = 57,
				}, -- [2128]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568326163,
					["Quest"] = 3373,
					["Level"] = 57,
				}, -- [2129]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Despaira",
							["Level"] = 53,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568326167,
					["Quest"] = 3373,
					["Level"] = 57,
				}, -- [2130]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568327173,
					["Quest"] = 3528,
					["Level"] = 57,
				}, -- [2131]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568327783,
					["Quest"] = 4143,
					["Level"] = 57,
				}, -- [2132]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568327843,
					["Quest"] = 4005,
					["Level"] = 57,
				}, -- [2133]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568327847,
					["Quest"] = 3961,
					["Level"] = 57,
				}, -- [2134]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568327894,
					["Quest"] = 3961,
					["Level"] = 57,
				}, -- [2135]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568327900,
					["Quest"] = 3962,
					["Level"] = 57,
				}, -- [2136]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568329691,
					["Quest"] = 3962,
					["Level"] = 57,
				}, -- [2137]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568329702,
					["Quest"] = 4144,
					["Level"] = 57,
				}, -- [2138]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568331034,
					["Quest"] = 1446,
					["Level"] = 57,
				}, -- [2139]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568331487,
					["Quest"] = 4341,
					["Level"] = 57,
				}, -- [2140]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568331886,
					["Quest"] = 4128,
					["Level"] = 57,
				}, -- [2141]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568331889,
					["Quest"] = 4126,
					["Level"] = 57,
				}, -- [2142]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568332441,
					["Quest"] = 4286,
					["Level"] = 57,
				}, -- [2143]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568332444,
					["Quest"] = 4241,
					["Level"] = 57,
				}, -- [2144]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568332459,
					["Quest"] = 4764,
					["Level"] = 57,
				}, -- [2145]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568332465,
					["Quest"] = 4262,
					["Level"] = 57,
				}, -- [2146]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568332562,
					["Quest"] = 4024,
					["Level"] = 57,
				}, -- [2147]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333190,
					["Quest"] = 4123,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2148]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333193,
					["Quest"] = 4866,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2149]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333220,
					["Quest"] = 4764,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [2150]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333223,
					["Quest"] = 4866,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [2151]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333232,
					["Quest"] = 4136,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2152]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333551,
					["Quest"] = 7848,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2153]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 57,
						}, -- [1]
					},
					["Timestamp"] = 1568333880,
					["Quest"] = 3801,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2154]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [4]
					},
					["Timestamp"] = 1568334604,
					["Quest"] = 3801,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2155]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 54,
						}, -- [4]
					},
					["Timestamp"] = 1568334608,
					["Quest"] = 3802,
					["Level"] = 57,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2156]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568335359,
					["Event"] = "Level",
					["NewLevel"] = 58,
				}, -- [2157]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568338636,
					["Quest"] = 4241,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2158]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568338641,
					["Quest"] = 4242,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2159]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568340989,
					["Quest"] = 4201,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2160]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568343141,
					["Quest"] = 3802,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2161]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [3]
						{
							["Class"] = "Mage",
							["Name"] = "Channel",
							["Level"] = 55,
						}, -- [4]
					},
					["Timestamp"] = 1568344983,
					["Quest"] = 7848,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2162]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568346614,
					["Quest"] = 4341,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2163]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568346618,
					["Quest"] = 4342,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2164]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568346634,
					["Quest"] = 4342,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2165]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568346637,
					["Quest"] = 4361,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2166]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347072,
					["Quest"] = 4123,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2167]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347088,
					["Quest"] = 4136,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2168]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347221,
					["Quest"] = 4024,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2169]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347342,
					["Quest"] = 4286,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2170]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347353,
					["Quest"] = 4242,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2171]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347364,
					["Quest"] = 4262,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2172]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347375,
					["Quest"] = 4263,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2173]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347596,
					["Quest"] = 4361,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2174]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347604,
					["Quest"] = 4362,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2175]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347659,
					["Quest"] = 8149,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2176]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347748,
					["Quest"] = 4126,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2177]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347748,
					["Quest"] = 384,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2178]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568347755,
					["Quest"] = 384,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Abandon",
				}, -- [2179]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568348552,
					["Quest"] = 5803,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2180]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568348566,
					["Quest"] = 5505,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2181]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568348778,
					["Quest"] = 5168,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2182]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568348780,
					["Quest"] = 5211,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2183]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568351059,
					["Quest"] = 5211,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2184]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568353292,
					["Quest"] = 5168,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2185]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 58,
						}, -- [1]
					},
					["Timestamp"] = 1568353293,
					["Quest"] = 5206,
					["Level"] = 58,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2186]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["Level"] = 58,
					["Quest"] = 4264,
					["Timestamp"] = 1568394786,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2187]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["Timestamp"] = 1568395266,
					["Event"] = "Level",
					["NewLevel"] = 59,
				}, -- [2188]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["Level"] = 59,
					["Quest"] = 4264,
					["Timestamp"] = 1568396192,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2189]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["Level"] = 59,
					["Quest"] = 4282,
					["Timestamp"] = 1568396194,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2190]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568399475,
					["Quest"] = 4282,
					["Level"] = 59,
				}, -- [2191]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568399518,
					["Quest"] = 4322,
					["Level"] = 59,
				}, -- [2192]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568403110,
					["Quest"] = 4295,
					["Level"] = 59,
				}, -- [2193]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568403112,
					["Quest"] = 4295,
					["Level"] = 59,
				}, -- [2194]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568403114,
					["Quest"] = 4295,
					["Level"] = 59,
				}, -- [2195]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568403115,
					["Quest"] = 4295,
					["Level"] = 59,
				}, -- [2196]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568403116,
					["Quest"] = 4295,
					["Level"] = 59,
				}, -- [2197]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568406957,
					["Quest"] = 4362,
					["Level"] = 59,
				}, -- [2198]
				{
					["Party"] = {
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Paladin",
							["Name"] = "Durenas",
							["Level"] = 59,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568406961,
					["Quest"] = 4363,
					["Level"] = 59,
				}, -- [2199]
				{
					["Party"] = {
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568407094,
					["Quest"] = 4363,
					["Level"] = 59,
				}, -- [2200]
				{
					["Party"] = {
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568407313,
					["Quest"] = 4322,
					["Level"] = 59,
				}, -- [2201]
				{
					["Party"] = {
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568407313,
					["Quest"] = 6402,
					["Level"] = 59,
				}, -- [2202]
				{
					["Party"] = {
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568407331,
					["Quest"] = 4263,
					["Level"] = 59,
				}, -- [2203]
				{
					["Party"] = {
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568407606,
					["Quest"] = 4766,
					["Level"] = 59,
				}, -- [2204]
				{
					["Party"] = {
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568407659,
					["Quest"] = 6186,
					["Level"] = 59,
				}, -- [2205]
				{
					["Party"] = {
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1568407668,
					["Quest"] = 6187,
					["Level"] = 59,
				}, -- [2206]
				{
					["Party"] = {
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1568408103,
					["Quest"] = 8149,
					["Level"] = 59,
				}, -- [2207]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568411602,
					["Quest"] = 6402,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2208]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568411606,
					["Quest"] = 6403,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2209]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568412406,
					["Quest"] = 6403,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2210]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568412410,
					["Quest"] = 6501,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2211]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568414433,
					["Quest"] = 7792,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2212]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568414438,
					["Quest"] = 7798,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2213]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568414441,
					["Quest"] = 7799,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2214]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568417820,
					["Quest"] = 7802,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2215]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568417823,
					["Quest"] = 7804,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2216]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568417826,
					["Quest"] = 7803,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2217]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568417828,
					["Quest"] = 7805,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2218]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568418562,
					["Quest"] = 5163,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2219]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568418882,
					["Quest"] = 5123,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2220]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568419308,
					["Quest"] = 5121,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2221]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568419309,
					["Quest"] = 5123,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2222]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568419310,
					["Quest"] = 5128,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2223]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568419436,
					["Quest"] = 8469,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2224]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568420043,
					["Quest"] = 5128,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2225]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568421508,
					["Quest"] = 6501,
					["Level"] = 59,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2226]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568421508,
					["Event"] = "Level",
					["NewLevel"] = 60,
				}, -- [2227]
				{
					["Party"] = {
						{
							["Class"] = "Priest",
							["Name"] = "Galassa",
							["Level"] = 59,
						}, -- [1]
					},
					["Timestamp"] = 1568421509,
					["Quest"] = 6502,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2228]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 4907,
					["Timestamp"] = 1568423912,
				}, -- [2229]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 969,
					["Timestamp"] = 1568423940,
				}, -- [2230]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 60,
					["Quest"] = 969,
					["Timestamp"] = 1568423952,
				}, -- [2231]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 5206,
					["Timestamp"] = 1568466919,
				}, -- [2232]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5941,
					["Timestamp"] = 1568466922,
				}, -- [2233]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 5941,
					["Timestamp"] = 1568467206,
				}, -- [2234]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5721,
					["Timestamp"] = 1568467214,
				}, -- [2235]
				{
					["Party"] = {
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5848,
					["Timestamp"] = 1568467515,
				}, -- [2236]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5214,
					["Timestamp"] = 1568486128,
				}, -- [2237]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5212,
					["Timestamp"] = 1568486129,
				}, -- [2238]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5251,
					["Timestamp"] = 1568486131,
				}, -- [2239]
				{
					["Party"] = {
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [1]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [2]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "Warlock",
							["Name"] = "Svestialon",
							["Level"] = 59,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5243,
					["Timestamp"] = 1568486134,
				}, -- [2240]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5251,
					["Timestamp"] = 1568498477,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2241]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5214,
					["Timestamp"] = 1568498494,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2242]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5529,
					["Timestamp"] = 1568498546,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2243]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5848,
					["Timestamp"] = 1568499040,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2244]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5861,
					["Timestamp"] = 1568499051,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2245]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5861,
					["Timestamp"] = 1568499367,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2246]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5862,
					["Timestamp"] = 1568499379,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2247]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5862,
					["Timestamp"] = 1568499737,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2248]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5944,
					["Timestamp"] = 1568499828,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [2249]
				{
					["Party"] = {
					},
					["Level"] = 60,
					["Quest"] = 5944,
					["Timestamp"] = 1568500859,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [2250]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [3]
					},
					["Timestamp"] = 1568557867,
					["Quest"] = 5262,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2251]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [3]
					},
					["Timestamp"] = 1568558371,
					["Quest"] = 5262,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2252]
				{
					["Party"] = {
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [1]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [2]
						{
							["Class"] = "Mage",
							["Name"] = "Æther",
							["Level"] = 58,
						}, -- [3]
					},
					["Timestamp"] = 1568558375,
					["Quest"] = 5263,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [2253]
				{
					["Party"] = {
						{
							["Class"] = "Warrior",
							["Name"] = "Imperion",
							["Level"] = 58,
						}, -- [1]
						{
							["Class"] = "Warrior",
							["Name"] = "Imperion",
							["Level"] = 58,
						}, -- [2]
						{
							["Class"] = "Warrior",
							["Name"] = "Imperion",
							["Level"] = 58,
						}, -- [3]
						{
							["Class"] = "Warrior",
							["Name"] = "Imperion",
							["Level"] = 58,
						}, -- [4]
					},
					["Timestamp"] = 1568565346,
					["Quest"] = 5125,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [2254]
			},
			["complete"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				true, -- [5]
				nil, -- [6]
				true, -- [7]
				nil, -- [8]
				nil, -- [9]
				true, -- [10]
				nil, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				nil, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				nil, -- [31]
				nil, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				nil, -- [36]
				true, -- [37]
				nil, -- [38]
				true, -- [39]
				true, -- [40]
				nil, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				true, -- [45]
				nil, -- [46]
				true, -- [47]
				nil, -- [48]
				nil, -- [49]
				nil, -- [50]
				nil, -- [51]
				true, -- [52]
				nil, -- [53]
				true, -- [54]
				true, -- [55]
				true, -- [56]
				true, -- [57]
				true, -- [58]
				nil, -- [59]
				true, -- [60]
				true, -- [61]
				true, -- [62]
				nil, -- [63]
				nil, -- [64]
				true, -- [65]
				true, -- [66]
				true, -- [67]
				true, -- [68]
				true, -- [69]
				true, -- [70]
				true, -- [71]
				true, -- [72]
				nil, -- [73]
				true, -- [74]
				true, -- [75]
				true, -- [76]
				nil, -- [77]
				true, -- [78]
				true, -- [79]
				true, -- [80]
				nil, -- [81]
				true, -- [82]
				nil, -- [83]
				true, -- [84]
				true, -- [85]
				true, -- [86]
				true, -- [87]
				true, -- [88]
				nil, -- [89]
				nil, -- [90]
				true, -- [91]
				nil, -- [92]
				true, -- [93]
				nil, -- [94]
				true, -- [95]
				nil, -- [96]
				true, -- [97]
				true, -- [98]
				nil, -- [99]
				nil, -- [100]
				true, -- [101]
				nil, -- [102]
				nil, -- [103]
				nil, -- [104]
				nil, -- [105]
				true, -- [106]
				true, -- [107]
				nil, -- [108]
				true, -- [109]
				true, -- [110]
				true, -- [111]
				nil, -- [112]
				true, -- [113]
				nil, -- [114]
				true, -- [115]
				nil, -- [116]
				nil, -- [117]
				true, -- [118]
				true, -- [119]
				true, -- [120]
				true, -- [121]
				nil, -- [122]
				nil, -- [123]
				nil, -- [124]
				true, -- [125]
				nil, -- [126]
				true, -- [127]
				true, -- [128]
				true, -- [129]
				true, -- [130]
				true, -- [131]
				true, -- [132]
				true, -- [133]
				true, -- [134]
				true, -- [135]
				nil, -- [136]
				nil, -- [137]
				nil, -- [138]
				nil, -- [139]
				nil, -- [140]
				true, -- [141]
				true, -- [142]
				true, -- [143]
				true, -- [144]
				true, -- [145]
				true, -- [146]
				nil, -- [147]
				true, -- [148]
				true, -- [149]
				true, -- [150]
				nil, -- [151]
				nil, -- [152]
				nil, -- [153]
				true, -- [154]
				true, -- [155]
				true, -- [156]
				true, -- [157]
				true, -- [158]
				true, -- [159]
				true, -- [160]
				nil, -- [161]
				true, -- [162]
				true, -- [163]
				true, -- [164]
				true, -- [165]
				true, -- [166]
				nil, -- [167]
				nil, -- [168]
				nil, -- [169]
				nil, -- [170]
				nil, -- [171]
				nil, -- [172]
				true, -- [173]
				true, -- [174]
				true, -- [175]
				true, -- [176]
				true, -- [177]
				nil, -- [178]
				nil, -- [179]
				true, -- [180]
				true, -- [181]
				nil, -- [182]
				nil, -- [183]
				nil, -- [184]
				true, -- [185]
				true, -- [186]
				true, -- [187]
				true, -- [188]
				true, -- [189]
				true, -- [190]
				true, -- [191]
				true, -- [192]
				true, -- [193]
				true, -- [194]
				true, -- [195]
				true, -- [196]
				true, -- [197]
				true, -- [198]
				true, -- [199]
				true, -- [200]
				true, -- [201]
				true, -- [202]
				true, -- [203]
				true, -- [204]
				true, -- [205]
				true, -- [206]
				true, -- [207]
				true, -- [208]
				true, -- [209]
				true, -- [210]
				true, -- [211]
				nil, -- [212]
				true, -- [213]
				true, -- [214]
				true, -- [215]
				nil, -- [216]
				true, -- [217]
				nil, -- [218]
				nil, -- [219]
				nil, -- [220]
				true, -- [221]
				true, -- [222]
				true, -- [223]
				true, -- [224]
				true, -- [225]
				true, -- [226]
				true, -- [227]
				true, -- [228]
				true, -- [229]
				true, -- [230]
				true, -- [231]
				nil, -- [232]
				nil, -- [233]
				nil, -- [234]
				nil, -- [235]
				nil, -- [236]
				true, -- [237]
				nil, -- [238]
				true, -- [239]
				true, -- [240]
				nil, -- [241]
				nil, -- [242]
				nil, -- [243]
				true, -- [244]
				true, -- [245]
				[250] = true,
				[251] = true,
				[252] = true,
				[253] = true,
				[1019] = true,
				[510] = true,
				[1020] = true,
				[2040] = true,
				[2041] = true,
				[511] = true,
				[4084] = true,
				[1023] = true,
				[512] = true,
				[257] = true,
				[514] = true,
				[258] = true,
				[1033] = true,
				[4128] = true,
				[5155] = true,
				[4136] = true,
				[5163] = true,
				[4144] = true,
				[261] = true,
				[262] = true,
				[1047] = true,
				[4184] = true,
				[525] = true,
				[263] = true,
				[5219] = true,
				[1052] = true,
				[1053] = true,
				[1054] = true,
				[265] = true,
				[5251] = true,
				[2118] = true,
				[531] = true,
				[266] = true,
				[4244] = true,
				[7321] = true,
				[267] = true,
				[4264] = true,
				[2138] = true,
				[536] = true,
				[537] = true,
				[269] = true,
				[538] = true,
				[4296] = true,
				[270] = true,
				[540] = true,
				[2158] = true,
				[271] = true,
				[542] = true,
				[3201] = true,
				[6402] = true,
				[1097] = true,
				[275] = true,
				[2198] = true,
				[2200] = true,
				[276] = true,
				[1104] = true,
				[1105] = true,
				[1106] = true,
				[1107] = true,
				[1108] = true,
				[555] = true,
				[1110] = true,
				[1111] = true,
				[1112] = true,
				[1114] = true,
				[1115] = true,
				[1116] = true,
				[1117] = true,
				[1118] = true,
				[1119] = true,
				[2240] = true,
				[1122] = true,
				[562] = true,
				[563] = true,
				[4496] = true,
				[564] = true,
				[4504] = true,
				[4508] = true,
				[4512] = true,
				[5543] = true,
				[284] = true,
				[1135] = true,
				[1137] = true,
				[1138] = true,
				[1139] = true,
				[2278] = true,
				[286] = true,
				[574] = true,
				[575] = true,
				[288] = true,
				[576] = true,
				[577] = true,
				[289] = true,
				[578] = true,
				[290] = true,
				[580] = true,
				[7701] = true,
				[583] = true,
				[292] = true,
				[7729] = true,
				[7733] = true,
				[293] = true,
				[587] = true,
				[294] = true,
				[3371] = true,
				[1176] = true,
				[1177] = true,
				[1178] = true,
				[1179] = true,
				[1180] = true,
				[1181] = true,
				[1182] = true,
				[1183] = true,
				[4728] = true,
				[4732] = true,
				[297] = true,
				[1187] = true,
				[1188] = true,
				[595] = true,
				[1190] = true,
				[597] = true,
				[1194] = true,
				[599] = true,
				[1198] = true,
				[600] = true,
				[2398] = true,
				[601] = true,
				[301] = true,
				[602] = true,
				[1204] = true,
				[603] = true,
				[302] = true,
				[604] = true,
				[605] = true,
				[3441] = true,
				[3443] = true,
				[3445] = true,
				[3447] = true,
				[3449] = true,
				[608] = true,
				[3453] = true,
				[609] = true,
				[305] = true,
				[1219] = true,
				[3461] = true,
				[611] = true,
				[306] = true,
				[613] = true,
				[307] = true,
				[614] = true,
				[3481] = true,
				[616] = true,
				[5943] = true,
				[617] = true,
				[309] = true,
				[3501] = true,
				[1241] = true,
				[1242] = true,
				[1243] = true,
				[1244] = true,
				[1245] = true,
				[1246] = true,
				[1247] = true,
				[1248] = true,
				[1249] = true,
				[1250] = true,
				[626] = true,
				[1252] = true,
				[3527] = true,
				[314] = true,
				[628] = true,
				[7066] = true,
				[1259] = true,
				[631] = true,
				[632] = true,
				[1264] = true,
				[1265] = true,
				[1266] = true,
				[1267] = true,
				[8149] = true,
				[637] = true,
				[1274] = true,
				[1275] = true,
				[1282] = true,
				[642] = true,
				[1284] = true,
				[1285] = true,
				[1286] = true,
				[1287] = true,
				[4125] = true,
				[3601] = true,
				[5156] = true,
				[6183] = true,
				[647] = true,
				[324] = true,
				[325] = true,
				[651] = true,
				[652] = true,
				[2606] = true,
				[653] = true,
				[5216] = true,
				[5220] = true,
				[328] = true,
				[657] = true,
				[329] = true,
				[658] = true,
				[659] = true,
				[330] = true,
				[1319] = true,
				[1320] = true,
				[661] = true,
				[331] = true,
				[662] = true,
				[1324] = true,
				[663] = true,
				[664] = true,
				[4281] = true,
				[665] = true,
				[4289] = true,
				[666] = true,
				[2662] = true,
				[667] = true,
				[668] = true,
				[669] = true,
				[1338] = true,
				[1339] = true,
				[3701] = true,
				[4341] = true,
				[337] = true,
				[6403] = true,
				[4361] = true,
				[338] = true,
				[339] = true,
				[340] = true,
				[1360] = true,
				[341] = true,
				[1363] = true,
				[683] = true,
				[342] = true,
				[684] = true,
				[4441] = true,
				[685] = true,
				[4449] = true,
				[686] = true,
				[3765] = true,
				[687] = true,
				[689] = true,
				[690] = true,
				[3781] = true,
				[3783] = true,
				[1382] = true,
				[692] = true,
				[3789] = true,
				[2768] = true,
				[2770] = true,
				[694] = true,
				[5544] = true,
				[695] = true,
				[348] = true,
				[1395] = true,
				[6603] = true,
				[350] = true,
				[700] = true,
				[3823] = true,
				[3825] = true,
				[703] = true,
				[704] = true,
				[4601] = true,
				[705] = true,
				[353] = true,
				[3845] = true,
				[707] = true,
				[709] = true,
				[710] = true,
				[711] = true,
				[712] = true,
				[2846] = true,
				[713] = true,
				[714] = true,
				[4681] = true,
				[715] = true,
				[3881] = true,
				[716] = true,
				[2864] = true,
				[2866] = true,
				[718] = true,
				[2870] = true,
				[1437] = true,
				[2874] = true,
				[1439] = true,
				[1440] = true,
				[721] = true,
				[3905] = true,
				[722] = true,
				[3909] = true,
				[723] = true,
				[1446] = true,
				[724] = true,
				[4761] = true,
				[725] = true,
				[726] = true,
				[727] = true,
				[1454] = true,
				[1455] = true,
				[1456] = true,
				[729] = true,
				[1458] = true,
				[730] = true,
				[3941] = true,
				[731] = true,
				[2922] = true,
				[732] = true,
				[2926] = true,
				[1465] = true,
				[1466] = true,
				[1467] = true,
				[3961] = true,
				[2940] = true,
				[2942] = true,
				[2944] = true,
				[2946] = true,
				[738] = true,
				[2952] = true,
				[2954] = true,
				[741] = true,
				[2962] = true,
				[2964] = true,
				[2970] = true,
				[2972] = true,
				[5944] = true,
				[373] = true,
				[2982] = true,
				[2988] = true,
				[2990] = true,
				[2992] = true,
				[2994] = true,
				[6004] = true,
				[4985] = true,
				[377] = true,
				[6024] = true,
				[6028] = true,
				[3022] = true,
				[5021] = true,
				[762] = true,
				[5085] = true,
				[5097] = true,
				[385] = true,
				[5125] = true,
				[386] = true,
				[6164] = true,
				[4126] = true,
				[387] = true,
				[5157] = true,
				[6184] = true,
				[4142] = true,
				[388] = true,
				[3100] = true,
				[777] = true,
				[389] = true,
				[778] = true,
				[4182] = true,
				[4186] = true,
				[391] = true,
				[5225] = true,
				[783] = true,
				[3130] = true,
				[5237] = true,
				[5241] = true,
				[5245] = true,
				[393] = true,
				[8460] = true,
				[4242] = true,
				[5281] = true,
				[4262] = true,
				[4266] = true,
				[2139] = true,
				[4282] = true,
				[4286] = true,
				[4290] = true,
				[5321] = true,
				[3182] = true,
				[4322] = true,
				[4342] = true,
				[401] = true,
				[4362] = true,
				[5401] = true,
				[5405] = true,
				[2199] = true,
				[2201] = true,
				[8551] = true,
				[8465] = true,
				[8464] = true,
				[4442] = true,
				[3764] = true,
				[4450] = true,
				[5882] = true,
				[8366] = true,
				[6021] = true,
				[1200] = true,
				[7805] = true,
				[7804] = true,
				[5501] = true,
				[5505] = true,
				[5904] = true,
				[7802] = true,
				[7799] = true,
				[7798] = true,
				[1639] = true,
				[7792] = true,
				[4510] = true,
				[5537] = true,
				[299] = true,
				[5545] = true,
				[7727] = true,
				[7724] = true,
				[4811] = true,
				[5561] = true,
				[7722] = true,
				[7721] = true,
				[606] = true,
				[2279] = true,
				[7067] = true,
				[733] = true,
				[4809] = true,
				[7046] = true,
				[7044] = true,
				[5601] = true,
				[7041] = true,
				[7029] = true,
				[5158] = true,
				[416] = true,
				[7003] = true,
				[4602] = true,
				[4606] = true,
				[417] = true,
				[6762] = true,
				[6761] = true,
				[6624] = true,
				[418] = true,
				[6501] = true,
				[4183] = true,
				[6186] = true,
				[419] = true,
				[6185] = true,
				[6182] = true,
				[7723] = true,
				[1678] = true,
				[720] = true,
				[6027] = true,
				[5153] = true,
				[3362] = true,
				[1683] = true,
				[1684] = true,
				[3368] = true,
				[1686] = true,
				[6023] = true,
				[8365] = true,
				[4513] = true,
				[1690] = true,
				[1691] = true,
				[1692] = true,
				[1693] = true,
				[4722] = true,
				[4726] = true,
				[4730] = true,
				[7803] = true,
				[5903] = true,
				[5534] = true,
				[8461] = true,
				[5863] = true,
				[2876] = true,
				[5781] = true,
				[4762] = true,
				[5861] = true,
				[5848] = true,
				[1707] = true,
				[5801] = true,
				[5846] = true,
				[5845] = true,
				[5803] = true,
				[2948] = true,
				[5742] = true,
				[5741] = true,
				[5542] = true,
				[4810] = true,
				[634] = true,
				[1718] = true,
				[1719] = true,
				[5536] = true,
				[5535] = true,
				[3442] = true,
				[3444] = true,
				[3446] = true,
				[3448] = true,
				[432] = true,
				[3452] = true,
				[3454] = true,
				[5885] = true,
				[433] = true,
				[5533] = true,
				[2439] = true,
				[5503] = true,
				[5385] = true,
				[3844] = true,
				[4493] = true,
				[5249] = true,
				[5244] = true,
				[4902] = true,
				[4906] = true,
				[4501] = true,
				[436] = true,
				[5941] = true,
				[5223] = true,
				[4605] = true,
				[5217] = true,
				[5215] = true,
				[4725] = true,
				[5211] = true,
				[4727] = true,
				[5206] = true,
				[5204] = true,
				[5203] = true,
				[5202] = true,
				[5181] = true,
				[5168] = true,
				[5165] = true,
				[5159] = true,
				[7028] = true,
				[4986] = true,
				[3520] = true,
				[5154] = true,
				[3524] = true,
				[6025] = true,
				[3528] = true,
				[5152] = true,
				[5149] = true,
				[7064] = true,
				[5022] = true,
				[5128] = true,
				[5123] = true,
				[2519] = true,
				[5121] = true,
				[5092] = true,
				[5091] = true,
				[5050] = true,
				[1001] = true,
				[5058] = true,
				[5087] = true,
				[5066] = true,
				[5060] = true,
				[5084] = true,
				[5083] = true,
				[5082] = true,
				[5086] = true,
				[5090] = true,
				[5048] = true,
				[4984] = true,
				[4972] = true,
				[4971] = true,
				[4901] = true,
				[4864] = true,
				[4863] = true,
				[4861] = true,
				[4842] = true,
				[4813] = true,
				[4812] = true,
				[6161] = true,
				[5142] = true,
				[4123] = true,
				[4127] = true,
				[4131] = true,
				[2581] = true,
				[2583] = true,
				[2585] = true,
				[4808] = true,
				[273] = true,
				[1218] = true,
				[4740] = true,
				[453] = true,
				[4733] = true,
				[4731] = true,
				[2601] = true,
				[454] = true,
				[2605] = true,
				[5210] = true,
				[5214] = true,
				[4723] = true,
				[5222] = true,
				[5226] = true,
				[4507] = true,
				[4503] = true,
				[4502] = true,
				[5242] = true,
				[4223] = true,
				[5250] = true,
				[4492] = true,
				[8462] = true,
				[5262] = true,
				[4243] = true,
				[4421] = true,
				[4130] = true,
				[2641] = true,
				[4321] = true,
				[4263] = true,
				[4267] = true,
				[4301] = true,
				[4292] = true,
				[4288] = true,
				[4283] = true,
				[4287] = true,
				[4291] = true,
				[2661] = true,
				[4285] = true,
				[4284] = true,
				[4265] = true,
				[4261] = true,
				[4245] = true,
				[4241] = true,
				[463] = true,
				[4224] = true,
				[3702] = true,
				[4185] = true,
				[464] = true,
				[6389] = true,
				[4143] = true,
				[4141] = true,
				[465] = true,
				[4135] = true,
				[4363] = true,
				[4129] = true,
				[4124] = true,
				[4101] = true,
				[4024] = true,
				[1175] = true,
				[4005] = true,
				[3962] = true,
				[2178] = true,
				[2869] = true,
				[3913] = true,
				[3912] = true,
				[3908] = true,
				[3904] = true,
				[469] = true,
				[3903] = true,
				[3884] = true,
				[939] = true,
				[470] = true,
				[3883] = true,
				[268] = true,
				[630] = true,
				[4451] = true,
				[2741] = true,
				[3824] = true,
				[2745] = true,
				[472] = true,
				[944] = true,
				[739] = true,
				[945] = true,
				[3801] = true,
				[633] = true,
				[4491] = true,
				[947] = true,
				[474] = true,
				[948] = true,
				[3790] = true,
				[949] = true,
				[5538] = true,
				[950] = true,
				[3785] = true,
				[1438] = true,
				[3802] = true,
				[2781] = true,
				[2783] = true,
				[953] = true,
				[3763] = true,
				[954] = true,
				[1220] = true,
				[955] = true,
				[277] = true,
				[956] = true,
				[321] = true,
				[2801] = true,
				[3463] = true,
				[958] = true,
				[3462] = true,
				[322] = true,
				[323] = true,
				[3451] = true,
				[3450] = true,
				[392] = true,
				[281] = true,
				[2821] = true,
				[3367] = true,
				[963] = true,
				[1050] = true,
				[3181] = true,
				[3161] = true,
				[965] = true,
				[1447] = true,
				[966] = true,
				[296] = true,
				[967] = true,
				[7728] = true,
				[2845] = true,
				[2038] = true,
				[660] = true,
				[295] = true,
				[3661] = true,
				[1100] = true,
				[971] = true,
				[3882] = true,
				[2861] = true,
				[1186] = true,
				[942] = true,
				[2867] = true,
				[974] = true,
				[2871] = true,
				[2873] = true,
				[2875] = true,
				[2877] = true,
				[2879] = true,
				[977] = true,
				[5762] = true,
				[978] = true,
				[670] = true,
				[979] = true,
				[3914] = true,
				[980] = true,
				[4763] = true,
				[554] = true,
				[2941] = true,
				[982] = true,
				[7848] = true,
				[983] = true,
				[4787] = true,
				[984] = true,
				[2872] = true,
				[985] = true,
				[2930] = true,
				[986] = true,
				[3942] = true,
				[2928] = true,
				[2924] = true,
				[2925] = true,
				[2880] = true,
				[2929] = true,
				[1387] = true,
				[5862] = true,
				[551] = true,
				[991] = true,
				[2939] = true,
				[992] = true,
				[2943] = true,
				[2945] = true,
				[2947] = true,
				[279] = true,
				[2951] = true,
				[559] = true,
				[943] = true,
				[560] = true,
				[561] = true,
				[1121] = true,
				[2963] = true,
				[1457] = true,
				[691] = true,
				[2969] = true,
				[500] = true,
				[2844] = true,
				[693] = true,
				[2977] = true,
				[285] = true,
				[1002] = true,
				[2500] = true,
				[1003] = true,
				[957] = true,
				[2989] = true,
				[2991] = true,
				[2993] = true,
				[1459] = true,
				[1453] = true,
				[4022] = true,
				[1007] = true,
				[504] = true,
				[1008] = true,
				[3373] = true,
				[1009] = true,
				[505] = true,
				[1010] = true,
				[719] = true,
				[6030] = true,
				[594] = true,
				[298] = true,
				[7065] = true,
				[7069] = true,
				[734] = true,
				[607] = true,
				[610] = true,
				[1015] = true,
				[1206] = true,
				[1222] = true,
				[5051] = true,
				[621] = true,
				[623] = true,
				[624] = true,
				[625] = true,
				[1253] = true,
			},
		},
	},
	["profileKeys"] = {
		["Flidro - Pagle"] = "Default",
		["Flidro - Stalagg"] = "Default",
		["Flidrobank - Pagle"] = "Default",
		["Wahaha - Pagle"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["minimap"] = {
				["minimapPos"] = 234.275087128724,
				["hide"] = true,
			},
		},
	},
}
