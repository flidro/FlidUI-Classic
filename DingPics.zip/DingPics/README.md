# DingPics

World of Warcraft add-on to automatically screenshot when you level up.

By default the screenshot is triggered 300ms after the PLAYER_LEVEL_UP event for optimal view of the yellow animation. You can adjust this in DingPics.lua if you want.

## Install

Download the folder and extract in `BattleNet\World of Warcraft\_classic_\Interface\AddOns`. Make sure the folder is called `DingPics` and not `DingPics-master`.
